var hl=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var uh=hl((Ee,Ae)=>{(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))o(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const u of s.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&o(u)}).observe(document,{childList:!0,subtree:!0});function n(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function o(i){if(i.ep)return;i.ep=!0;const s=n(i);fetch(i.href,s)}})();/**
* @vue/shared v3.5.10
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**//*! #__NO_SIDE_EFFECTS__ */function Lo(e){const t=Object.create(null);for(const n of e.split(","))t[n]=1;return n=>n in t}const K={},It=[],Be=()=>{},bl=()=>!1,Hn=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&(e.charCodeAt(2)>122||e.charCodeAt(2)<97),Vo=e=>e.startsWith("onUpdate:"),le=Object.assign,No=(e,t)=>{const n=e.indexOf(t);n>-1&&e.splice(n,1)},yl=Object.prototype.hasOwnProperty,V=(e,t)=>yl.call(e,t),P=Array.isArray,Mt=e=>mn(e)==="[object Map]",Lt=e=>mn(e)==="[object Set]",Ai=e=>mn(e)==="[object Date]",D=e=>typeof e=="function",te=e=>typeof e=="string",Ve=e=>typeof e=="symbol",Q=e=>e!==null&&typeof e=="object",Dr=e=>(Q(e)||D(e))&&D(e.then)&&D(e.catch),Rr=Object.prototype.toString,mn=e=>Rr.call(e),xl=e=>mn(e).slice(8,-1),jr=e=>mn(e)==="[object Object]",Ho=e=>te(e)&&e!=="NaN"&&e[0]!=="-"&&""+parseInt(e,10)===e,Qt=Lo(",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"),zn=e=>{const t=Object.create(null);return n=>t[n]||(t[n]=e(n))},wl=/-(\w)/g,Pe=zn(e=>e.replace(wl,(t,n)=>n?n.toUpperCase():"")),Tl=/\B([A-Z])/g,Tt=zn(e=>e.replace(Tl,"-$1").toLowerCase()),Wn=zn(e=>e.charAt(0).toUpperCase()+e.slice(1)),so=zn(e=>e?`on${Wn(e)}`:""),st=(e,t)=>!Object.is(e,t),In=(e,...t)=>{for(let n=0;n<e.length;n++)e[n](...t)},Ur=(e,t,n,o=!1)=>{Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:o,value:n})},Rn=e=>{const t=parseFloat(e);return isNaN(t)?e:t};let _i;const Br=()=>_i||(_i=typeof globalThis<"u"?globalThis:typeof self<"u"?self:typeof window<"u"?window:typeof global<"u"?global:{});function zo(e){if(P(e)){const t={};for(let n=0;n<e.length;n++){const o=e[n],i=te(o)?El(o):zo(o);if(i)for(const s in i)t[s]=i[s]}return t}else if(te(e)||Q(e))return e}const Cl=/;(?![^(]*\))/g,$l=/:([^]+)/,Sl=/\/\*[^]*?\*\//g;function El(e){const t={};return e.replace(Sl,"").split(Cl).forEach(n=>{if(n){const o=n.split($l);o.length>1&&(t[o[0].trim()]=o[1].trim())}}),t}function Wo(e){let t="";if(te(e))t=e;else if(P(e))for(let n=0;n<e.length;n++){const o=Wo(e[n]);o&&(t+=o+" ")}else if(Q(e))for(const n in e)e[n]&&(t+=n+" ");return t.trim()}const Al="itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly",_l=Lo(Al);function Lr(e){return!!e||e===""}function Ol(e,t){if(e.length!==t.length)return!1;let n=!0;for(let o=0;n&&o<e.length;o++)n=gn(e[o],t[o]);return n}function gn(e,t){if(e===t)return!0;let n=Ai(e),o=Ai(t);if(n||o)return n&&o?e.getTime()===t.getTime():!1;if(n=Ve(e),o=Ve(t),n||o)return e===t;if(n=P(e),o=P(t),n||o)return n&&o?Ol(e,t):!1;if(n=Q(e),o=Q(t),n||o){if(!n||!o)return!1;const i=Object.keys(e).length,s=Object.keys(t).length;if(i!==s)return!1;for(const u in e){const r=e.hasOwnProperty(u),c=t.hasOwnProperty(u);if(r&&!c||!r&&c||!gn(e[u],t[u]))return!1}}return String(e)===String(t)}function Ko(e,t){return e.findIndex(n=>gn(n,t))}const Vr=e=>!!(e&&e.__v_isRef===!0),se=e=>te(e)?e:e==null?"":P(e)||Q(e)&&(e.toString===Rr||!D(e.toString))?Vr(e)?se(e.value):JSON.stringify(e,Nr,2):String(e),Nr=(e,t)=>Vr(t)?Nr(e,t.value):Mt(t)?{[`Map(${t.size})`]:[...t.entries()].reduce((n,[o,i],s)=>(n[lo(o,s)+" =>"]=i,n),{})}:Lt(t)?{[`Set(${t.size})`]:[...t.values()].map(n=>lo(n))}:Ve(t)?lo(t):Q(t)&&!P(t)&&!jr(t)?String(t):t,lo=(e,t="")=>{var n;return Ve(e)?`Symbol(${(n=e.description)!=null?n:t})`:e};/**
* @vue/reactivity v3.5.10
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Te;class Pl{constructor(t=!1){this.detached=t,this._active=!0,this.effects=[],this.cleanups=[],this._isPaused=!1,this.parent=Te,!t&&Te&&(this.index=(Te.scopes||(Te.scopes=[])).push(this)-1)}get active(){return this._active}pause(){if(this._active){this._isPaused=!0;let t,n;if(this.scopes)for(t=0,n=this.scopes.length;t<n;t++)this.scopes[t].pause();for(t=0,n=this.effects.length;t<n;t++)this.effects[t].pause()}}resume(){if(this._active&&this._isPaused){this._isPaused=!1;let t,n;if(this.scopes)for(t=0,n=this.scopes.length;t<n;t++)this.scopes[t].resume();for(t=0,n=this.effects.length;t<n;t++)this.effects[t].resume()}}run(t){if(this._active){const n=Te;try{return Te=this,t()}finally{Te=n}}}on(){Te=this}off(){Te=this.parent}stop(t){if(this._active){let n,o;for(n=0,o=this.effects.length;n<o;n++)this.effects[n].stop();for(n=0,o=this.cleanups.length;n<o;n++)this.cleanups[n]();if(this.scopes)for(n=0,o=this.scopes.length;n<o;n++)this.scopes[n].stop(!0);if(!this.detached&&this.parent&&!t){const i=this.parent.scopes.pop();i&&i!==this&&(this.parent.scopes[this.index]=i,i.index=this.index)}this.parent=void 0,this._active=!1}}}function Il(){return Te}let X;const ao=new WeakSet;class Hr{constructor(t){this.fn=t,this.deps=void 0,this.depsTail=void 0,this.flags=5,this.next=void 0,this.cleanup=void 0,this.scheduler=void 0,Te&&Te.active&&Te.effects.push(this)}pause(){this.flags|=64}resume(){this.flags&64&&(this.flags&=-65,ao.has(this)&&(ao.delete(this),this.trigger()))}notify(){this.flags&2&&!(this.flags&32)||this.flags&8||Wr(this)}run(){if(!(this.flags&1))return this.fn();this.flags|=2,Oi(this),Kr(this);const t=X,n=Me;X=this,Me=!0;try{return this.fn()}finally{Gr(this),X=t,Me=n,this.flags&=-3}}stop(){if(this.flags&1){for(let t=this.deps;t;t=t.nextDep)Yo(t);this.deps=this.depsTail=void 0,Oi(this),this.onStop&&this.onStop(),this.flags&=-2}}trigger(){this.flags&64?ao.add(this):this.scheduler?this.scheduler():this.runIfDirty()}runIfDirty(){yo(this)&&this.run()}get dirty(){return yo(this)}}let zr=0,Pt;function Wr(e){e.flags|=8,e.next=Pt,Pt=e}function Go(){zr++}function qo(){if(--zr>0)return;let e;for(;Pt;){let t=Pt,n;for(;t;)t.flags&1||(t.flags&=-9),t=t.next;for(t=Pt,Pt=void 0;t;){if(n=t.next,t.next=void 0,t.flags&=-9,t.flags&1)try{t.trigger()}catch(o){e||(e=o)}t=n}}if(e)throw e}function Kr(e){for(let t=e.deps;t;t=t.nextDep)t.version=-1,t.prevActiveLink=t.dep.activeLink,t.dep.activeLink=t}function Gr(e){let t,n=e.depsTail,o=n;for(;o;){const i=o.prevDep;o.version===-1?(o===n&&(n=i),Yo(o),Ml(o)):t=o,o.dep.activeLink=o.prevActiveLink,o.prevActiveLink=void 0,o=i}e.deps=t,e.depsTail=n}function yo(e){for(let t=e.deps;t;t=t.nextDep)if(t.dep.version!==t.version||t.dep.computed&&(qr(t.dep.computed)||t.dep.version!==t.version))return!0;return!!e._dirty}function qr(e){if(e.flags&4&&!(e.flags&16)||(e.flags&=-17,e.globalVersion===rn))return;e.globalVersion=rn;const t=e.dep;if(e.flags|=2,t.version>0&&!e.isSSR&&e.deps&&!yo(e)){e.flags&=-3;return}const n=X,o=Me;X=e,Me=!0;try{Kr(e);const i=e.fn(e._value);(t.version===0||st(i,e._value))&&(e._value=i,t.version++)}catch(i){throw t.version++,i}finally{X=n,Me=o,Gr(e),e.flags&=-3}}function Yo(e,t=!1){const{dep:n,prevSub:o,nextSub:i}=e;if(o&&(o.nextSub=i,e.prevSub=void 0),i&&(i.prevSub=o,e.nextSub=void 0),n.subs===e&&(n.subs=o),!n.subs&&n.computed){n.computed.flags&=-5;for(let s=n.computed.deps;s;s=s.nextDep)Yo(s,!0)}!t&&!--n.sc&&n.map&&n.map.delete(n.key)}function Ml(e){const{prevDep:t,nextDep:n}=e;t&&(t.nextDep=n,e.prevDep=void 0),n&&(n.prevDep=t,e.nextDep=void 0)}let Me=!0;const Yr=[];function lt(){Yr.push(Me),Me=!1}function at(){const e=Yr.pop();Me=e===void 0?!0:e}function Oi(e){const{cleanup:t}=e;if(e.cleanup=void 0,t){const n=X;X=void 0;try{t()}finally{X=n}}}let rn=0;class Fl{constructor(t,n){this.sub=t,this.dep=n,this.version=n.version,this.nextDep=this.prevDep=this.nextSub=this.prevSub=this.prevActiveLink=void 0}}class Jo{constructor(t){this.computed=t,this.version=0,this.activeLink=void 0,this.subs=void 0,this.target=void 0,this.map=void 0,this.key=void 0,this.sc=0}track(t){if(!X||!Me||X===this.computed)return;let n=this.activeLink;if(n===void 0||n.sub!==X)n=this.activeLink=new Fl(X,this),X.deps?(n.prevDep=X.depsTail,X.depsTail.nextDep=n,X.depsTail=n):X.deps=X.depsTail=n,Jr(n);else if(n.version===-1&&(n.version=this.version,n.nextDep)){const o=n.nextDep;o.prevDep=n.prevDep,n.prevDep&&(n.prevDep.nextDep=o),n.prevDep=X.depsTail,n.nextDep=void 0,X.depsTail.nextDep=n,X.depsTail=n,X.deps===n&&(X.deps=o)}return n}trigger(t){this.version++,rn++,this.notify(t)}notify(t){Go();try{for(let n=this.subs;n;n=n.prevSub)n.sub.notify()&&n.sub.dep.notify()}finally{qo()}}}function Jr(e){if(e.dep.sc++,e.sub.flags&4){const t=e.dep.computed;if(t&&!e.dep.subs){t.flags|=20;for(let o=t.deps;o;o=o.nextDep)Jr(o)}const n=e.dep.subs;n!==e&&(e.prevSub=n,n&&(n.nextSub=e)),e.dep.subs=e}}const xo=new WeakMap,vt=Symbol(""),wo=Symbol(""),sn=Symbol("");function fe(e,t,n){if(Me&&X){let o=xo.get(e);o||xo.set(e,o=new Map);let i=o.get(n);i||(o.set(n,i=new Jo),i.target=e,i.map=o,i.key=n),i.track()}}function Ye(e,t,n,o,i,s){const u=xo.get(e);if(!u){rn++;return}const r=c=>{c&&c.trigger()};if(Go(),t==="clear")u.forEach(r);else{const c=P(e),a=c&&Ho(n);if(c&&n==="length"){const d=Number(o);u.forEach((m,v)=>{(v==="length"||v===sn||!Ve(v)&&v>=d)&&r(m)})}else switch(n!==void 0&&r(u.get(n)),a&&r(u.get(sn)),t){case"add":c?a&&r(u.get("length")):(r(u.get(vt)),Mt(e)&&r(u.get(wo)));break;case"delete":c||(r(u.get(vt)),Mt(e)&&r(u.get(wo)));break;case"set":Mt(e)&&r(u.get(vt));break}}qo()}function _t(e){const t=H(e);return t===e?t:(fe(t,"iterate",sn),Oe(e)?t:t.map(ue))}function Kn(e){return fe(e=H(e),"iterate",sn),e}const kl={__proto__:null,[Symbol.iterator](){return uo(this,Symbol.iterator,ue)},concat(...e){return _t(this).concat(...e.map(t=>P(t)?_t(t):t))},entries(){return uo(this,"entries",e=>(e[1]=ue(e[1]),e))},every(e,t){return We(this,"every",e,t,void 0,arguments)},filter(e,t){return We(this,"filter",e,t,n=>n.map(ue),arguments)},find(e,t){return We(this,"find",e,t,ue,arguments)},findIndex(e,t){return We(this,"findIndex",e,t,void 0,arguments)},findLast(e,t){return We(this,"findLast",e,t,ue,arguments)},findLastIndex(e,t){return We(this,"findLastIndex",e,t,void 0,arguments)},forEach(e,t){return We(this,"forEach",e,t,void 0,arguments)},includes(...e){return co(this,"includes",e)},indexOf(...e){return co(this,"indexOf",e)},join(e){return _t(this).join(e)},lastIndexOf(...e){return co(this,"lastIndexOf",e)},map(e,t){return We(this,"map",e,t,void 0,arguments)},pop(){return Gt(this,"pop")},push(...e){return Gt(this,"push",e)},reduce(e,...t){return Pi(this,"reduce",e,t)},reduceRight(e,...t){return Pi(this,"reduceRight",e,t)},shift(){return Gt(this,"shift")},some(e,t){return We(this,"some",e,t,void 0,arguments)},splice(...e){return Gt(this,"splice",e)},toReversed(){return _t(this).toReversed()},toSorted(e){return _t(this).toSorted(e)},toSpliced(...e){return _t(this).toSpliced(...e)},unshift(...e){return Gt(this,"unshift",e)},values(){return uo(this,"values",ue)}};function uo(e,t,n){const o=Kn(e),i=o[t]();return o!==e&&!Oe(e)&&(i._next=i.next,i.next=()=>{const s=i._next();return s.value&&(s.value=n(s.value)),s}),i}const Dl=Array.prototype;function We(e,t,n,o,i,s){const u=Kn(e),r=u!==e&&!Oe(e),c=u[t];if(c!==Dl[t]){const m=c.apply(e,s);return r?ue(m):m}let a=n;u!==e&&(r?a=function(m,v){return n.call(this,ue(m),v,e)}:n.length>2&&(a=function(m,v){return n.call(this,m,v,e)}));const d=c.call(u,a,o);return r&&i?i(d):d}function Pi(e,t,n,o){const i=Kn(e);let s=n;return i!==e&&(Oe(e)?n.length>3&&(s=function(u,r,c){return n.call(this,u,r,c,e)}):s=function(u,r,c){return n.call(this,u,ue(r),c,e)}),i[t](s,...o)}function co(e,t,n){const o=H(e);fe(o,"iterate",sn);const i=o[t](...n);return(i===-1||i===!1)&&ti(n[0])?(n[0]=H(n[0]),o[t](...n)):i}function Gt(e,t,n=[]){lt(),Go();const o=H(e)[t].apply(e,n);return qo(),at(),o}const Rl=Lo("__proto__,__v_isRef,__isVue"),Xr=new Set(Object.getOwnPropertyNames(Symbol).filter(e=>e!=="arguments"&&e!=="caller").map(e=>Symbol[e]).filter(Ve));function jl(e){Ve(e)||(e=String(e));const t=H(this);return fe(t,"has",e),t.hasOwnProperty(e)}class Qr{constructor(t=!1,n=!1){this._isReadonly=t,this._isShallow=n}get(t,n,o){const i=this._isReadonly,s=this._isShallow;if(n==="__v_isReactive")return!i;if(n==="__v_isReadonly")return i;if(n==="__v_isShallow")return s;if(n==="__v_raw")return o===(i?s?Jl:ns:s?ts:es).get(t)||Object.getPrototypeOf(t)===Object.getPrototypeOf(o)?t:void 0;const u=P(t);if(!i){let c;if(u&&(c=kl[n]))return c;if(n==="hasOwnProperty")return jl}const r=Reflect.get(t,n,ce(t)?t:o);return(Ve(n)?Xr.has(n):Rl(n))||(i||fe(t,"get",n),s)?r:ce(r)?u&&Ho(n)?r:r.value:Q(r)?i?os(r):Zo(r):r}}class Zr extends Qr{constructor(t=!1){super(!1,t)}set(t,n,o,i){let s=t[n];if(!this._isShallow){const c=ht(s);if(!Oe(o)&&!ht(o)&&(s=H(s),o=H(o)),!P(t)&&ce(s)&&!ce(o))return c?!1:(s.value=o,!0)}const u=P(t)&&Ho(n)?Number(n)<t.length:V(t,n),r=Reflect.set(t,n,o,ce(t)?t:i);return t===H(i)&&(u?st(o,s)&&Ye(t,"set",n,o):Ye(t,"add",n,o)),r}deleteProperty(t,n){const o=V(t,n);t[n];const i=Reflect.deleteProperty(t,n);return i&&o&&Ye(t,"delete",n,void 0),i}has(t,n){const o=Reflect.has(t,n);return(!Ve(n)||!Xr.has(n))&&fe(t,"has",n),o}ownKeys(t){return fe(t,"iterate",P(t)?"length":vt),Reflect.ownKeys(t)}}class Ul extends Qr{constructor(t=!1){super(!0,t)}set(t,n){return!0}deleteProperty(t,n){return!0}}const Bl=new Zr,Ll=new Ul,Vl=new Zr(!0),Xo=e=>e,Gn=e=>Reflect.getPrototypeOf(e);function Sn(e,t,n=!1,o=!1){e=e.__v_raw;const i=H(e),s=H(t);n||(st(t,s)&&fe(i,"get",t),fe(i,"get",s));const{has:u}=Gn(i),r=o?Xo:n?ni:ue;if(u.call(i,t))return r(e.get(t));if(u.call(i,s))return r(e.get(s));e!==i&&e.get(t)}function En(e,t=!1){const n=this.__v_raw,o=H(n),i=H(e);return t||(st(e,i)&&fe(o,"has",e),fe(o,"has",i)),e===i?n.has(e):n.has(e)||n.has(i)}function An(e,t=!1){return e=e.__v_raw,!t&&fe(H(e),"iterate",vt),Reflect.get(e,"size",e)}function Ii(e,t=!1){!t&&!Oe(e)&&!ht(e)&&(e=H(e));const n=H(this);return Gn(n).has.call(n,e)||(n.add(e),Ye(n,"add",e,e)),this}function Mi(e,t,n=!1){!n&&!Oe(t)&&!ht(t)&&(t=H(t));const o=H(this),{has:i,get:s}=Gn(o);let u=i.call(o,e);u||(e=H(e),u=i.call(o,e));const r=s.call(o,e);return o.set(e,t),u?st(t,r)&&Ye(o,"set",e,t):Ye(o,"add",e,t),this}function Fi(e){const t=H(this),{has:n,get:o}=Gn(t);let i=n.call(t,e);i||(e=H(e),i=n.call(t,e)),o&&o.call(t,e);const s=t.delete(e);return i&&Ye(t,"delete",e,void 0),s}function ki(){const e=H(this),t=e.size!==0,n=e.clear();return t&&Ye(e,"clear",void 0,void 0),n}function _n(e,t){return function(o,i){const s=this,u=s.__v_raw,r=H(u),c=t?Xo:e?ni:ue;return!e&&fe(r,"iterate",vt),u.forEach((a,d)=>o.call(i,c(a),c(d),s))}}function On(e,t,n){return function(...o){const i=this.__v_raw,s=H(i),u=Mt(s),r=e==="entries"||e===Symbol.iterator&&u,c=e==="keys"&&u,a=i[e](...o),d=n?Xo:t?ni:ue;return!t&&fe(s,"iterate",c?wo:vt),{next(){const{value:m,done:v}=a.next();return v?{value:m,done:v}:{value:r?[d(m[0]),d(m[1])]:d(m),done:v}},[Symbol.iterator](){return this}}}}function nt(e){return function(...t){return e==="delete"?!1:e==="clear"?void 0:this}}function Nl(){const e={get(s){return Sn(this,s)},get size(){return An(this)},has:En,add:Ii,set:Mi,delete:Fi,clear:ki,forEach:_n(!1,!1)},t={get(s){return Sn(this,s,!1,!0)},get size(){return An(this)},has:En,add(s){return Ii.call(this,s,!0)},set(s,u){return Mi.call(this,s,u,!0)},delete:Fi,clear:ki,forEach:_n(!1,!0)},n={get(s){return Sn(this,s,!0)},get size(){return An(this,!0)},has(s){return En.call(this,s,!0)},add:nt("add"),set:nt("set"),delete:nt("delete"),clear:nt("clear"),forEach:_n(!0,!1)},o={get(s){return Sn(this,s,!0,!0)},get size(){return An(this,!0)},has(s){return En.call(this,s,!0)},add:nt("add"),set:nt("set"),delete:nt("delete"),clear:nt("clear"),forEach:_n(!0,!0)};return["keys","values","entries",Symbol.iterator].forEach(s=>{e[s]=On(s,!1,!1),n[s]=On(s,!0,!1),t[s]=On(s,!1,!0),o[s]=On(s,!0,!0)}),[e,n,t,o]}const[Hl,zl,Wl,Kl]=Nl();function Qo(e,t){const n=t?e?Kl:Wl:e?zl:Hl;return(o,i,s)=>i==="__v_isReactive"?!e:i==="__v_isReadonly"?e:i==="__v_raw"?o:Reflect.get(V(n,i)&&i in o?n:o,i,s)}const Gl={get:Qo(!1,!1)},ql={get:Qo(!1,!0)},Yl={get:Qo(!0,!1)},es=new WeakMap,ts=new WeakMap,ns=new WeakMap,Jl=new WeakMap;function Xl(e){switch(e){case"Object":case"Array":return 1;case"Map":case"Set":case"WeakMap":case"WeakSet":return 2;default:return 0}}function Ql(e){return e.__v_skip||!Object.isExtensible(e)?0:Xl(xl(e))}function Zo(e){return ht(e)?e:ei(e,!1,Bl,Gl,es)}function Zl(e){return ei(e,!1,Vl,ql,ts)}function os(e){return ei(e,!0,Ll,Yl,ns)}function ei(e,t,n,o,i){if(!Q(e)||e.__v_raw&&!(t&&e.__v_isReactive))return e;const s=i.get(e);if(s)return s;const u=Ql(e);if(u===0)return e;const r=new Proxy(e,u===2?o:n);return i.set(e,r),r}function Ft(e){return ht(e)?Ft(e.__v_raw):!!(e&&e.__v_isReactive)}function ht(e){return!!(e&&e.__v_isReadonly)}function Oe(e){return!!(e&&e.__v_isShallow)}function ti(e){return e?!!e.__v_raw:!1}function H(e){const t=e&&e.__v_raw;return t?H(t):e}function To(e){return!V(e,"__v_skip")&&Object.isExtensible(e)&&Ur(e,"__v_skip",!0),e}const ue=e=>Q(e)?Zo(e):e,ni=e=>Q(e)?os(e):e;function ce(e){return e?e.__v_isRef===!0:!1}function He(e){return ea(e,!1)}function ea(e,t){return ce(e)?e:new ta(e,t)}class ta{constructor(t,n){this.dep=new Jo,this.__v_isRef=!0,this.__v_isShallow=!1,this._rawValue=n?t:H(t),this._value=n?t:ue(t),this.__v_isShallow=n}get value(){return this.dep.track(),this._value}set value(t){const n=this._rawValue,o=this.__v_isShallow||Oe(t)||ht(t);t=o?t:H(t),st(t,n)&&(this._rawValue=t,this._value=o?t:ue(t),this.dep.trigger())}}function Co(e){return ce(e)?e.value:e}const na={get:(e,t,n)=>t==="__v_raw"?e:Co(Reflect.get(e,t,n)),set:(e,t,n,o)=>{const i=e[t];return ce(i)&&!ce(n)?(i.value=n,!0):Reflect.set(e,t,n,o)}};function is(e){return Ft(e)?e:new Proxy(e,na)}class oa{constructor(t,n,o){this.fn=t,this.setter=n,this._value=void 0,this.dep=new Jo(this),this.__v_isRef=!0,this.deps=void 0,this.depsTail=void 0,this.flags=16,this.globalVersion=rn-1,this.next=void 0,this.effect=this,this.__v_isReadonly=!n,this.isSSR=o}notify(){if(this.flags|=16,!(this.flags&8)&&X!==this)return Wr(this),!0}get value(){const t=this.dep.track();return qr(this),t&&(t.version=this.dep.version),this._value}set value(t){this.setter&&this.setter(t)}}function ia(e,t,n=!1){let o,i;return D(e)?o=e:(o=e.get,i=e.set),new oa(o,i,n)}const Pn={},jn=new WeakMap;let gt;function ra(e,t=!1,n=gt){if(n){let o=jn.get(n);o||jn.set(n,o=[]),o.push(e)}}function sa(e,t,n=K){const{immediate:o,deep:i,once:s,scheduler:u,augmentJob:r,call:c}=n,a=M=>i?M:Oe(M)||i===!1||i===0?qe(M,1):qe(M);let d,m,v,E,R=!1,T=!1;if(ce(e)?(m=()=>e.value,R=Oe(e)):Ft(e)?(m=()=>a(e),R=!0):P(e)?(T=!0,R=e.some(M=>Ft(M)||Oe(M)),m=()=>e.map(M=>{if(ce(M))return M.value;if(Ft(M))return a(M);if(D(M))return c?c(M,2):M()})):D(e)?t?m=c?()=>c(e,2):e:m=()=>{if(v){lt();try{v()}finally{at()}}const M=gt;gt=d;try{return c?c(e,3,[E]):e(E)}finally{gt=M}}:m=Be,t&&i){const M=m,oe=i===!0?1/0:i;m=()=>qe(M(),oe)}const j=Il(),k=()=>{d.stop(),j&&No(j.effects,d)};if(s&&t){const M=t;t=(...oe)=>{M(...oe),k()}}let L=T?new Array(e.length).fill(Pn):Pn;const G=M=>{if(!(!(d.flags&1)||!d.dirty&&!M))if(t){const oe=d.run();if(i||R||(T?oe.some((et,Fe)=>st(et,L[Fe])):st(oe,L))){v&&v();const et=gt;gt=d;try{const Fe=[oe,L===Pn?void 0:T&&L[0]===Pn?[]:L,E];c?c(t,3,Fe):t(...Fe),L=oe}finally{gt=et}}}else d.run()};return r&&r(G),d=new Hr(m),d.scheduler=u?()=>u(G,!1):G,E=M=>ra(M,!1,d),v=d.onStop=()=>{const M=jn.get(d);if(M){if(c)c(M,4);else for(const oe of M)oe();jn.delete(d)}},t?o?G(!0):L=d.run():u?u(G.bind(null,!0),!0):d.run(),k.pause=d.pause.bind(d),k.resume=d.resume.bind(d),k.stop=k,k}function qe(e,t=1/0,n){if(t<=0||!Q(e)||e.__v_skip||(n=n||new Set,n.has(e)))return e;if(n.add(e),t--,ce(e))qe(e.value,t,n);else if(P(e))for(let o=0;o<e.length;o++)qe(e[o],t,n);else if(Lt(e)||Mt(e))e.forEach(o=>{qe(o,t,n)});else if(jr(e)){for(const o in e)qe(e[o],t,n);for(const o of Object.getOwnPropertySymbols(e))Object.prototype.propertyIsEnumerable.call(e,o)&&qe(e[o],t,n)}return e}/**
* @vue/runtime-core v3.5.10
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/function vn(e,t,n,o){try{return o?e(...o):e()}catch(i){qn(i,t,n)}}function Ne(e,t,n,o){if(D(e)){const i=vn(e,t,n,o);return i&&Dr(i)&&i.catch(s=>{qn(s,t,n)}),i}if(P(e)){const i=[];for(let s=0;s<e.length;s++)i.push(Ne(e[s],t,n,o));return i}}function qn(e,t,n,o=!0){const i=t?t.vnode:null,{errorHandler:s,throwUnhandledErrorInProduction:u}=t&&t.appContext.config||K;if(t){let r=t.parent;const c=t.proxy,a=`https://vuejs.org/error-reference/#runtime-${n}`;for(;r;){const d=r.ec;if(d){for(let m=0;m<d.length;m++)if(d[m](e,c,a)===!1)return}r=r.parent}if(s){lt(),vn(s,null,10,[e,c,a]),at();return}}la(e,n,i,o,u)}function la(e,t,n,o=!0,i=!1){if(i)throw e;console.error(e)}let ln=!1,$o=!1;const ve=[];let je=0;const kt=[];let ot=null,Ot=0;const rs=Promise.resolve();let oi=null;function ss(e){const t=oi||rs;return e?t.then(this?e.bind(this):e):t}function aa(e){let t=ln?je+1:0,n=ve.length;for(;t<n;){const o=t+n>>>1,i=ve[o],s=an(i);s<e||s===e&&i.flags&2?t=o+1:n=o}return t}function ii(e){if(!(e.flags&1)){const t=an(e),n=ve[ve.length-1];!n||!(e.flags&2)&&t>=an(n)?ve.push(e):ve.splice(aa(t),0,e),e.flags|=1,ls()}}function ls(){!ln&&!$o&&($o=!0,oi=rs.then(us))}function ua(e){P(e)?kt.push(...e):ot&&e.id===-1?ot.splice(Ot+1,0,e):e.flags&1||(kt.push(e),e.flags|=1),ls()}function Di(e,t,n=ln?je+1:0){for(;n<ve.length;n++){const o=ve[n];if(o&&o.flags&2){if(e&&o.id!==e.uid)continue;ve.splice(n,1),n--,o.flags&4&&(o.flags&=-2),o(),o.flags&4||(o.flags&=-2)}}}function as(e){if(kt.length){const t=[...new Set(kt)].sort((n,o)=>an(n)-an(o));if(kt.length=0,ot){ot.push(...t);return}for(ot=t,Ot=0;Ot<ot.length;Ot++){const n=ot[Ot];n.flags&4&&(n.flags&=-2),n.flags&8||n(),n.flags&=-2}ot=null,Ot=0}}const an=e=>e.id==null?e.flags&2?-1:1/0:e.id;function us(e){$o=!1,ln=!0;try{for(je=0;je<ve.length;je++){const t=ve[je];t&&!(t.flags&8)&&(t.flags&4&&(t.flags&=-2),vn(t,t.i,t.i?15:14),t.flags&4||(t.flags&=-2))}}finally{for(;je<ve.length;je++){const t=ve[je];t&&(t.flags&=-2)}je=0,ve.length=0,as(),ln=!1,oi=null,(ve.length||kt.length)&&us()}}let Ce=null,ds=null;function Un(e){const t=Ce;return Ce=e,ds=e&&e.type.__scopeId||null,t}function cs(e,t=Ce,n){if(!t||e._n)return e;const o=(...i)=>{o._d&&zi(-1);const s=Un(t);let u;try{u=e(...i)}finally{Un(s),o._d&&zi(1)}return u};return o._n=!0,o._c=!0,o._d=!0,o}function y(e,t){if(Ce===null)return e;const n=Zn(Ce),o=e.dirs||(e.dirs=[]);for(let i=0;i<t.length;i++){let[s,u,r,c=K]=t[i];s&&(D(s)&&(s={mounted:s,updated:s}),s.deep&&qe(u),o.push({dir:s,instance:n,value:u,oldValue:void 0,arg:r,modifiers:c}))}return e}function pt(e,t,n,o){const i=e.dirs,s=t&&t.dirs;for(let u=0;u<i.length;u++){const r=i[u];s&&(r.oldValue=s[u].value);let c=r.dir[o];c&&(lt(),Ne(c,n,8,[e.el,r,e,t]),at())}}const da=Symbol("_vte"),ca=e=>e.__isTeleport;function ri(e,t){e.shapeFlag&6&&e.component?(e.transition=t,ri(e.component.subTree,t)):e.shapeFlag&128?(e.ssContent.transition=t.clone(e.ssContent),e.ssFallback.transition=t.clone(e.ssFallback)):e.transition=t}/*! #__NO_SIDE_EFFECTS__ */function Xe(e,t){return D(e)?le({name:e.name},t,{setup:e}):e}function fs(e){e.ids=[e.ids[0]+e.ids[2]+++"-",0,0]}function So(e,t,n,o,i=!1){if(P(e)){e.forEach((R,T)=>So(R,t&&(P(t)?t[T]:t),n,o,i));return}if(Zt(o)&&!i)return;const s=o.shapeFlag&4?Zn(o.component):o.el,u=i?null:s,{i:r,r:c}=e,a=t&&t.r,d=r.refs===K?r.refs={}:r.refs,m=r.setupState,v=H(m),E=m===K?()=>!1:R=>V(v,R);if(a!=null&&a!==c&&(te(a)?(d[a]=null,E(a)&&(m[a]=null)):ce(a)&&(a.value=null)),D(c))vn(c,r,12,[u,d]);else{const R=te(c),T=ce(c);if(R||T){const j=()=>{if(e.f){const k=R?E(c)?m[c]:d[c]:c.value;i?P(k)&&No(k,s):P(k)?k.includes(s)||k.push(s):R?(d[c]=[s],E(c)&&(m[c]=d[c])):(c.value=[s],e.k&&(d[e.k]=c.value))}else R?(d[c]=u,E(c)&&(m[c]=u)):T&&(c.value=u,e.k&&(d[e.k]=u))};u?(j.id=-1,we(j,n)):j()}}}const Zt=e=>!!e.type.__asyncLoader,ps=e=>e.type.__isKeepAlive;function fa(e,t){ms(e,"a",t)}function pa(e,t){ms(e,"da",t)}function ms(e,t,n=de){const o=e.__wdc||(e.__wdc=()=>{let i=n;for(;i;){if(i.isDeactivated)return;i=i.parent}return e()});if(Yn(t,o,n),n){let i=n.parent;for(;i&&i.parent;)ps(i.parent.vnode)&&ma(o,t,n,i),i=i.parent}}function ma(e,t,n,o){const i=Yn(t,e,o,!0);vs(()=>{No(o[t],i)},n)}function Yn(e,t,n=de,o=!1){if(n){const i=n[e]||(n[e]=[]),s=t.__weh||(t.__weh=(...u)=>{lt();const r=hn(n),c=Ne(t,n,e,u);return r(),at(),c});return o?i.unshift(s):i.push(s),s}}const Qe=e=>(t,n=de)=>{(!Qn||e==="sp")&&Yn(e,(...o)=>t(...o),n)},ga=Qe("bm"),gs=Qe("m"),va=Qe("bu"),ha=Qe("u"),ba=Qe("bum"),vs=Qe("um"),ya=Qe("sp"),xa=Qe("rtg"),wa=Qe("rtc");function Ta(e,t=de){Yn("ec",e,t)}const Ca="components",hs=Symbol.for("v-ndc");function $a(e){return te(e)?Sa(Ca,e,!1)||e:e||hs}function Sa(e,t,n=!0,o=!1){const i=Ce||de;if(i){const s=i.type;{const r=cu(s,!1);if(r&&(r===t||r===Pe(t)||r===Wn(Pe(t))))return s}const u=Ri(i[e]||s[e],t)||Ri(i.appContext[e],t);return!u&&o?s:u}}function Ri(e,t){return e&&(e[t]||e[Pe(t)]||e[Wn(Pe(t))])}function Eo(e,t,n,o){let i;const s=n,u=P(e);if(u||te(e)){const r=u&&Ft(e);let c=!1;r&&(c=!Oe(e),e=Kn(e)),i=new Array(e.length);for(let a=0,d=e.length;a<d;a++)i[a]=t(c?ue(e[a]):e[a],a,void 0,s)}else if(typeof e=="number"){i=new Array(e);for(let r=0;r<e;r++)i[r]=t(r+1,r,void 0,s)}else if(Q(e))if(e[Symbol.iterator])i=Array.from(e,(r,c)=>t(r,c,void 0,s));else{const r=Object.keys(e);i=new Array(r.length);for(let c=0,a=r.length;c<a;c++){const d=r[c];i[c]=t(e[d],d,c,s)}}else i=[];return i}const Ao=e=>e?Us(e)?Zn(e):Ao(e.parent):null,en=le(Object.create(null),{$:e=>e,$el:e=>e.vnode.el,$data:e=>e.data,$props:e=>e.props,$attrs:e=>e.attrs,$slots:e=>e.slots,$refs:e=>e.refs,$parent:e=>Ao(e.parent),$root:e=>Ao(e.root),$host:e=>e.ce,$emit:e=>e.emit,$options:e=>si(e),$forceUpdate:e=>e.f||(e.f=()=>{ii(e.update)}),$nextTick:e=>e.n||(e.n=ss.bind(e.proxy)),$watch:e=>Ka.bind(e)}),fo=(e,t)=>e!==K&&!e.__isScriptSetup&&V(e,t),Ea={get({_:e},t){if(t==="__v_skip")return!0;const{ctx:n,setupState:o,data:i,props:s,accessCache:u,type:r,appContext:c}=e;let a;if(t[0]!=="$"){const E=u[t];if(E!==void 0)switch(E){case 1:return o[t];case 2:return i[t];case 4:return n[t];case 3:return s[t]}else{if(fo(o,t))return u[t]=1,o[t];if(i!==K&&V(i,t))return u[t]=2,i[t];if((a=e.propsOptions[0])&&V(a,t))return u[t]=3,s[t];if(n!==K&&V(n,t))return u[t]=4,n[t];_o&&(u[t]=0)}}const d=en[t];let m,v;if(d)return t==="$attrs"&&fe(e.attrs,"get",""),d(e);if((m=r.__cssModules)&&(m=m[t]))return m;if(n!==K&&V(n,t))return u[t]=4,n[t];if(v=c.config.globalProperties,V(v,t))return v[t]},set({_:e},t,n){const{data:o,setupState:i,ctx:s}=e;return fo(i,t)?(i[t]=n,!0):o!==K&&V(o,t)?(o[t]=n,!0):V(e.props,t)||t[0]==="$"&&t.slice(1)in e?!1:(s[t]=n,!0)},has({_:{data:e,setupState:t,accessCache:n,ctx:o,appContext:i,propsOptions:s}},u){let r;return!!n[u]||e!==K&&V(e,u)||fo(t,u)||(r=s[0])&&V(r,u)||V(o,u)||V(en,u)||V(i.config.globalProperties,u)},defineProperty(e,t,n){return n.get!=null?e._.accessCache[t]=0:V(n,"value")&&this.set(e,t,n.value,null),Reflect.defineProperty(e,t,n)}};function ji(e){return P(e)?e.reduce((t,n)=>(t[n]=null,t),{}):e}let _o=!0;function Aa(e){const t=si(e),n=e.proxy,o=e.ctx;_o=!1,t.beforeCreate&&Ui(t.beforeCreate,e,"bc");const{data:i,computed:s,methods:u,watch:r,provide:c,inject:a,created:d,beforeMount:m,mounted:v,beforeUpdate:E,updated:R,activated:T,deactivated:j,beforeDestroy:k,beforeUnmount:L,destroyed:G,unmounted:M,render:oe,renderTracked:et,renderTriggered:Fe,errorCaptured:tt,serverPrefetch:xn,expose:dt,inheritAttrs:Ht,components:wn,directives:Tn,filters:io}=t;if(a&&_a(a,o,null),u)for(const ee in u){const q=u[ee];D(q)&&(o[ee]=q.bind(n))}if(i){const ee=i.call(n,n);Q(ee)&&(e.data=Zo(ee))}if(_o=!0,s)for(const ee in s){const q=s[ee],ct=D(q)?q.bind(n,n):D(q.get)?q.get.bind(n,n):Be,Cn=!D(q)&&D(q.set)?q.set.bind(n):Be,ft=N({get:ct,set:Cn});Object.defineProperty(o,ee,{enumerable:!0,configurable:!0,get:()=>ft.value,set:ke=>ft.value=ke})}if(r)for(const ee in r)bs(r[ee],o,n,ee);if(c){const ee=D(c)?c.call(n):c;Reflect.ownKeys(ee).forEach(q=>{xs(q,ee[q])})}d&&Ui(d,e,"c");function pe(ee,q){P(q)?q.forEach(ct=>ee(ct.bind(n))):q&&ee(q.bind(n))}if(pe(ga,m),pe(gs,v),pe(va,E),pe(ha,R),pe(fa,T),pe(pa,j),pe(Ta,tt),pe(wa,et),pe(xa,Fe),pe(ba,L),pe(vs,M),pe(ya,xn),P(dt))if(dt.length){const ee=e.exposed||(e.exposed={});dt.forEach(q=>{Object.defineProperty(ee,q,{get:()=>n[q],set:ct=>n[q]=ct})})}else e.exposed||(e.exposed={});oe&&e.render===Be&&(e.render=oe),Ht!=null&&(e.inheritAttrs=Ht),wn&&(e.components=wn),Tn&&(e.directives=Tn),xn&&fs(e)}function _a(e,t,n=Be){P(e)&&(e=Oo(e));for(const o in e){const i=e[o];let s;Q(i)?"default"in i?s=tn(i.from||o,i.default,!0):s=tn(i.from||o):s=tn(i),ce(s)?Object.defineProperty(t,o,{enumerable:!0,configurable:!0,get:()=>s.value,set:u=>s.value=u}):t[o]=s}}function Ui(e,t,n){Ne(P(e)?e.map(o=>o.bind(t.proxy)):e.bind(t.proxy),t,n)}function bs(e,t,n,o){let i=o.includes(".")?Fs(n,o):()=>n[o];if(te(e)){const s=t[e];D(s)&&Le(i,s)}else if(D(e))Le(i,e.bind(n));else if(Q(e))if(P(e))e.forEach(s=>bs(s,t,n,o));else{const s=D(e.handler)?e.handler.bind(n):t[e.handler];D(s)&&Le(i,s,e)}}function si(e){const t=e.type,{mixins:n,extends:o}=t,{mixins:i,optionsCache:s,config:{optionMergeStrategies:u}}=e.appContext,r=s.get(t);let c;return r?c=r:!i.length&&!n&&!o?c=t:(c={},i.length&&i.forEach(a=>Bn(c,a,u,!0)),Bn(c,t,u)),Q(t)&&s.set(t,c),c}function Bn(e,t,n,o=!1){const{mixins:i,extends:s}=t;s&&Bn(e,s,n,!0),i&&i.forEach(u=>Bn(e,u,n,!0));for(const u in t)if(!(o&&u==="expose")){const r=Oa[u]||n&&n[u];e[u]=r?r(e[u],t[u]):t[u]}return e}const Oa={data:Bi,props:Li,emits:Li,methods:Xt,computed:Xt,beforeCreate:me,created:me,beforeMount:me,mounted:me,beforeUpdate:me,updated:me,beforeDestroy:me,beforeUnmount:me,destroyed:me,unmounted:me,activated:me,deactivated:me,errorCaptured:me,serverPrefetch:me,components:Xt,directives:Xt,watch:Ia,provide:Bi,inject:Pa};function Bi(e,t){return t?e?function(){return le(D(e)?e.call(this,this):e,D(t)?t.call(this,this):t)}:t:e}function Pa(e,t){return Xt(Oo(e),Oo(t))}function Oo(e){if(P(e)){const t={};for(let n=0;n<e.length;n++)t[e[n]]=e[n];return t}return e}function me(e,t){return e?[...new Set([].concat(e,t))]:t}function Xt(e,t){return e?le(Object.create(null),e,t):t}function Li(e,t){return e?P(e)&&P(t)?[...new Set([...e,...t])]:le(Object.create(null),ji(e),ji(t??{})):t}function Ia(e,t){if(!e)return t;if(!t)return e;const n=le(Object.create(null),e);for(const o in t)n[o]=me(e[o],t[o]);return n}function ys(){return{app:null,config:{isNativeTag:bl,performance:!1,globalProperties:{},optionMergeStrategies:{},errorHandler:void 0,warnHandler:void 0,compilerOptions:{}},mixins:[],components:{},directives:{},provides:Object.create(null),optionsCache:new WeakMap,propsCache:new WeakMap,emitsCache:new WeakMap}}let Ma=0;function Fa(e,t){return function(o,i=null){D(o)||(o=le({},o)),i!=null&&!Q(i)&&(i=null);const s=ys(),u=new WeakSet,r=[];let c=!1;const a=s.app={_uid:Ma++,_component:o,_props:i,_container:null,_context:s,_instance:null,version:mu,get config(){return s.config},set config(d){},use(d,...m){return u.has(d)||(d&&D(d.install)?(u.add(d),d.install(a,...m)):D(d)&&(u.add(d),d(a,...m))),a},mixin(d){return s.mixins.includes(d)||s.mixins.push(d),a},component(d,m){return m?(s.components[d]=m,a):s.components[d]},directive(d,m){return m?(s.directives[d]=m,a):s.directives[d]},mount(d,m,v){if(!c){const E=a._ceVNode||he(o,i);return E.appContext=s,v===!0?v="svg":v===!1&&(v=void 0),m&&t?t(E,d):e(E,d,v),c=!0,a._container=d,d.__vue_app__=a,Zn(E.component)}},onUnmount(d){r.push(d)},unmount(){c&&(Ne(r,a._instance,16),e(null,a._container),delete a._container.__vue_app__)},provide(d,m){return s.provides[d]=m,a},runWithContext(d){const m=Dt;Dt=a;try{return d()}finally{Dt=m}}};return a}}let Dt=null;function xs(e,t){if(de){let n=de.provides;const o=de.parent&&de.parent.provides;o===n&&(n=de.provides=Object.create(o)),n[e]=t}}function tn(e,t,n=!1){const o=de||Ce;if(o||Dt){const i=Dt?Dt._context.provides:o?o.parent==null?o.vnode.appContext&&o.vnode.appContext.provides:o.parent.provides:void 0;if(i&&e in i)return i[e];if(arguments.length>1)return n&&D(t)?t.call(o&&o.proxy):t}}const ws={},Ts=()=>Object.create(ws),Cs=e=>Object.getPrototypeOf(e)===ws;function ka(e,t,n,o=!1){const i={},s=Ts();e.propsDefaults=Object.create(null),$s(e,t,i,s);for(const u in e.propsOptions[0])u in i||(i[u]=void 0);n?e.props=o?i:Zl(i):e.type.props?e.props=i:e.props=s,e.attrs=s}function Da(e,t,n,o){const{props:i,attrs:s,vnode:{patchFlag:u}}=e,r=H(i),[c]=e.propsOptions;let a=!1;if((o||u>0)&&!(u&16)){if(u&8){const d=e.vnode.dynamicProps;for(let m=0;m<d.length;m++){let v=d[m];if(Jn(e.emitsOptions,v))continue;const E=t[v];if(c)if(V(s,v))E!==s[v]&&(s[v]=E,a=!0);else{const R=Pe(v);i[R]=Po(c,r,R,E,e,!1)}else E!==s[v]&&(s[v]=E,a=!0)}}}else{$s(e,t,i,s)&&(a=!0);let d;for(const m in r)(!t||!V(t,m)&&((d=Tt(m))===m||!V(t,d)))&&(c?n&&(n[m]!==void 0||n[d]!==void 0)&&(i[m]=Po(c,r,m,void 0,e,!0)):delete i[m]);if(s!==r)for(const m in s)(!t||!V(t,m))&&(delete s[m],a=!0)}a&&Ye(e.attrs,"set","")}function $s(e,t,n,o){const[i,s]=e.propsOptions;let u=!1,r;if(t)for(let c in t){if(Qt(c))continue;const a=t[c];let d;i&&V(i,d=Pe(c))?!s||!s.includes(d)?n[d]=a:(r||(r={}))[d]=a:Jn(e.emitsOptions,c)||(!(c in o)||a!==o[c])&&(o[c]=a,u=!0)}if(s){const c=H(n),a=r||K;for(let d=0;d<s.length;d++){const m=s[d];n[m]=Po(i,c,m,a[m],e,!V(a,m))}}return u}function Po(e,t,n,o,i,s){const u=e[n];if(u!=null){const r=V(u,"default");if(r&&o===void 0){const c=u.default;if(u.type!==Function&&!u.skipFactory&&D(c)){const{propsDefaults:a}=i;if(n in a)o=a[n];else{const d=hn(i);o=a[n]=c.call(null,t),d()}}else o=c;i.ce&&i.ce._setProp(n,o)}u[0]&&(s&&!r?o=!1:u[1]&&(o===""||o===Tt(n))&&(o=!0))}return o}const Ra=new WeakMap;function Ss(e,t,n=!1){const o=n?Ra:t.propsCache,i=o.get(e);if(i)return i;const s=e.props,u={},r=[];let c=!1;if(!D(e)){const d=m=>{c=!0;const[v,E]=Ss(m,t,!0);le(u,v),E&&r.push(...E)};!n&&t.mixins.length&&t.mixins.forEach(d),e.extends&&d(e.extends),e.mixins&&e.mixins.forEach(d)}if(!s&&!c)return Q(e)&&o.set(e,It),It;if(P(s))for(let d=0;d<s.length;d++){const m=Pe(s[d]);Vi(m)&&(u[m]=K)}else if(s)for(const d in s){const m=Pe(d);if(Vi(m)){const v=s[d],E=u[m]=P(v)||D(v)?{type:v}:le({},v),R=E.type;let T=!1,j=!0;if(P(R))for(let k=0;k<R.length;++k){const L=R[k],G=D(L)&&L.name;if(G==="Boolean"){T=!0;break}else G==="String"&&(j=!1)}else T=D(R)&&R.name==="Boolean";E[0]=T,E[1]=j,(T||V(E,"default"))&&r.push(m)}}const a=[u,r];return Q(e)&&o.set(e,a),a}function Vi(e){return e[0]!=="$"&&!Qt(e)}const Es=e=>e[0]==="_"||e==="$stable",li=e=>P(e)?e.map(Ue):[Ue(e)],ja=(e,t,n)=>{if(t._n)return t;const o=cs((...i)=>li(t(...i)),n);return o._c=!1,o},As=(e,t,n)=>{const o=e._ctx;for(const i in e){if(Es(i))continue;const s=e[i];if(D(s))t[i]=ja(i,s,o);else if(s!=null){const u=li(s);t[i]=()=>u}}},_s=(e,t)=>{const n=li(t);e.slots.default=()=>n},Os=(e,t,n)=>{for(const o in t)(n||o!=="_")&&(e[o]=t[o])},Ua=(e,t,n)=>{const o=e.slots=Ts();if(e.vnode.shapeFlag&32){const i=t._;i?(Os(o,t,n),n&&Ur(o,"_",i,!0)):As(t,o)}else t&&_s(e,t)},Ba=(e,t,n)=>{const{vnode:o,slots:i}=e;let s=!0,u=K;if(o.shapeFlag&32){const r=t._;r?n&&r===1?s=!1:Os(i,t,n):(s=!t.$stable,As(t,i)),u=t}else t&&(_s(e,t),u={default:1});if(s)for(const r in i)!Es(r)&&u[r]==null&&delete i[r]},we=Za;function La(e){return Va(e)}function Va(e,t){const n=Br();n.__VUE__=!0;const{insert:o,remove:i,patchProp:s,createElement:u,createText:r,createComment:c,setText:a,setElementText:d,parentNode:m,nextSibling:v,setScopeId:E=Be,insertStaticContent:R}=e,T=(f,p,g,x=null,h=null,b=null,S=void 0,$=null,C=!!p.dynamicChildren)=>{if(f===p)return;f&&!qt(f,p)&&(x=$n(f),ke(f,h,b,!0),f=null),p.patchFlag===-2&&(C=!1,p.dynamicChildren=null);const{type:w,ref:I,shapeFlag:A}=p;switch(w){case Xn:j(f,p,g,x);break;case bt:k(f,p,g,x);break;case Mn:f==null&&L(p,g,x,S);break;case _e:wn(f,p,g,x,h,b,S,$,C);break;default:A&1?oe(f,p,g,x,h,b,S,$,C):A&6?Tn(f,p,g,x,h,b,S,$,C):(A&64||A&128)&&w.process(f,p,g,x,h,b,S,$,C,Wt)}I!=null&&h&&So(I,f&&f.ref,b,p||f,!p)},j=(f,p,g,x)=>{if(f==null)o(p.el=r(p.children),g,x);else{const h=p.el=f.el;p.children!==f.children&&a(h,p.children)}},k=(f,p,g,x)=>{f==null?o(p.el=c(p.children||""),g,x):p.el=f.el},L=(f,p,g,x)=>{[f.el,f.anchor]=R(f.children,p,g,x,f.el,f.anchor)},G=({el:f,anchor:p},g,x)=>{let h;for(;f&&f!==p;)h=v(f),o(f,g,x),f=h;o(p,g,x)},M=({el:f,anchor:p})=>{let g;for(;f&&f!==p;)g=v(f),i(f),f=g;i(p)},oe=(f,p,g,x,h,b,S,$,C)=>{p.type==="svg"?S="svg":p.type==="math"&&(S="mathml"),f==null?et(p,g,x,h,b,S,$,C):xn(f,p,h,b,S,$,C)},et=(f,p,g,x,h,b,S,$)=>{let C,w;const{props:I,shapeFlag:A,transition:O,dirs:F}=f;if(C=f.el=u(f.type,b,I&&I.is,I),A&8?d(C,f.children):A&16&&tt(f.children,C,null,x,h,po(f,b),S,$),F&&pt(f,null,x,"created"),Fe(C,f,f.scopeId,S,x),I){for(const Y in I)Y!=="value"&&!Qt(Y)&&s(C,Y,null,I[Y],b,x);"value"in I&&s(C,"value",null,I.value,b),(w=I.onVnodeBeforeMount)&&Re(w,x,f)}F&&pt(f,null,x,"beforeMount");const U=Na(h,O);U&&O.beforeEnter(C),o(C,p,g),((w=I&&I.onVnodeMounted)||U||F)&&we(()=>{w&&Re(w,x,f),U&&O.enter(C),F&&pt(f,null,x,"mounted")},h)},Fe=(f,p,g,x,h)=>{if(g&&E(f,g),x)for(let b=0;b<x.length;b++)E(f,x[b]);if(h){let b=h.subTree;if(p===b||Ds(b.type)&&(b.ssContent===p||b.ssFallback===p)){const S=h.vnode;Fe(f,S,S.scopeId,S.slotScopeIds,h.parent)}}},tt=(f,p,g,x,h,b,S,$,C=0)=>{for(let w=C;w<f.length;w++){const I=f[w]=$?it(f[w]):Ue(f[w]);T(null,I,p,g,x,h,b,S,$)}},xn=(f,p,g,x,h,b,S)=>{const $=p.el=f.el;let{patchFlag:C,dynamicChildren:w,dirs:I}=p;C|=f.patchFlag&16;const A=f.props||K,O=p.props||K;let F;if(g&&mt(g,!1),(F=O.onVnodeBeforeUpdate)&&Re(F,g,p,f),I&&pt(p,f,g,"beforeUpdate"),g&&mt(g,!0),(A.innerHTML&&O.innerHTML==null||A.textContent&&O.textContent==null)&&d($,""),w?dt(f.dynamicChildren,w,$,g,x,po(p,h),b):S||q(f,p,$,null,g,x,po(p,h),b,!1),C>0){if(C&16)Ht($,A,O,g,h);else if(C&2&&A.class!==O.class&&s($,"class",null,O.class,h),C&4&&s($,"style",A.style,O.style,h),C&8){const U=p.dynamicProps;for(let Y=0;Y<U.length;Y++){const z=U[Y],be=A[z],ae=O[z];(ae!==be||z==="value")&&s($,z,be,ae,h,g)}}C&1&&f.children!==p.children&&d($,p.children)}else!S&&w==null&&Ht($,A,O,g,h);((F=O.onVnodeUpdated)||I)&&we(()=>{F&&Re(F,g,p,f),I&&pt(p,f,g,"updated")},x)},dt=(f,p,g,x,h,b,S)=>{for(let $=0;$<p.length;$++){const C=f[$],w=p[$],I=C.el&&(C.type===_e||!qt(C,w)||C.shapeFlag&70)?m(C.el):g;T(C,w,I,null,x,h,b,S,!0)}},Ht=(f,p,g,x,h)=>{if(p!==g){if(p!==K)for(const b in p)!Qt(b)&&!(b in g)&&s(f,b,p[b],null,h,x);for(const b in g){if(Qt(b))continue;const S=g[b],$=p[b];S!==$&&b!=="value"&&s(f,b,$,S,h,x)}"value"in g&&s(f,"value",p.value,g.value,h)}},wn=(f,p,g,x,h,b,S,$,C)=>{const w=p.el=f?f.el:r(""),I=p.anchor=f?f.anchor:r("");let{patchFlag:A,dynamicChildren:O,slotScopeIds:F}=p;F&&($=$?$.concat(F):F),f==null?(o(w,g,x),o(I,g,x),tt(p.children||[],g,I,h,b,S,$,C)):A>0&&A&64&&O&&f.dynamicChildren?(dt(f.dynamicChildren,O,g,h,b,S,$),(p.key!=null||h&&p===h.subTree)&&Ps(f,p,!0)):q(f,p,g,I,h,b,S,$,C)},Tn=(f,p,g,x,h,b,S,$,C)=>{p.slotScopeIds=$,f==null?p.shapeFlag&512?h.ctx.activate(p,g,x,S,C):io(p,g,x,h,b,S,C):xi(f,p,C)},io=(f,p,g,x,h,b,S)=>{const $=f.component=su(f,x,h);if(ps(f)&&($.ctx.renderer=Wt),lu($,!1,S),$.asyncDep){if(h&&h.registerDep($,pe,S),!f.el){const C=$.subTree=he(bt);k(null,C,p,g)}}else pe($,f,p,g,h,b,S)},xi=(f,p,g)=>{const x=p.component=f.component;if(Xa(f,p,g))if(x.asyncDep&&!x.asyncResolved){ee(x,p,g);return}else x.next=p,x.update();else p.el=f.el,x.vnode=p},pe=(f,p,g,x,h,b,S)=>{const $=()=>{if(f.isMounted){let{next:A,bu:O,u:F,parent:U,vnode:Y}=f;{const ye=Is(f);if(ye){A&&(A.el=Y.el,ee(f,A,S)),ye.asyncDep.then(()=>{f.isUnmounted||$()});return}}let z=A,be;mt(f,!1),A?(A.el=Y.el,ee(f,A,S)):A=Y,O&&In(O),(be=A.props&&A.props.onVnodeBeforeUpdate)&&Re(be,U,A,Y),mt(f,!0);const ae=mo(f),Ie=f.subTree;f.subTree=ae,T(Ie,ae,m(Ie.el),$n(Ie),f,h,b),A.el=ae.el,z===null&&Qa(f,ae.el),F&&we(F,h),(be=A.props&&A.props.onVnodeUpdated)&&we(()=>Re(be,U,A,Y),h)}else{let A;const{el:O,props:F}=p,{bm:U,m:Y,parent:z,root:be,type:ae}=f,Ie=Zt(p);if(mt(f,!1),U&&In(U),!Ie&&(A=F&&F.onVnodeBeforeMount)&&Re(A,z,p),mt(f,!0),O&&$i){const ye=()=>{f.subTree=mo(f),$i(O,f.subTree,f,h,null)};Ie&&ae.__asyncHydrate?ae.__asyncHydrate(O,f,ye):ye()}else{be.ce&&be.ce._injectChildStyle(ae);const ye=f.subTree=mo(f);T(null,ye,g,x,f,h,b),p.el=ye.el}if(Y&&we(Y,h),!Ie&&(A=F&&F.onVnodeMounted)){const ye=p;we(()=>Re(A,z,ye),h)}(p.shapeFlag&256||z&&Zt(z.vnode)&&z.vnode.shapeFlag&256)&&f.a&&we(f.a,h),f.isMounted=!0,p=g=x=null}};f.scope.on();const C=f.effect=new Hr($);f.scope.off();const w=f.update=C.run.bind(C),I=f.job=C.runIfDirty.bind(C);I.i=f,I.id=f.uid,C.scheduler=()=>ii(I),mt(f,!0),w()},ee=(f,p,g)=>{p.component=f;const x=f.vnode.props;f.vnode=p,f.next=null,Da(f,p.props,x,g),Ba(f,p.children,g),lt(),Di(f),at()},q=(f,p,g,x,h,b,S,$,C=!1)=>{const w=f&&f.children,I=f?f.shapeFlag:0,A=p.children,{patchFlag:O,shapeFlag:F}=p;if(O>0){if(O&128){Cn(w,A,g,x,h,b,S,$,C);return}else if(O&256){ct(w,A,g,x,h,b,S,$,C);return}}F&8?(I&16&&zt(w,h,b),A!==w&&d(g,A)):I&16?F&16?Cn(w,A,g,x,h,b,S,$,C):zt(w,h,b,!0):(I&8&&d(g,""),F&16&&tt(A,g,x,h,b,S,$,C))},ct=(f,p,g,x,h,b,S,$,C)=>{f=f||It,p=p||It;const w=f.length,I=p.length,A=Math.min(w,I);let O;for(O=0;O<A;O++){const F=p[O]=C?it(p[O]):Ue(p[O]);T(f[O],F,g,null,h,b,S,$,C)}w>I?zt(f,h,b,!0,!1,A):tt(p,g,x,h,b,S,$,C,A)},Cn=(f,p,g,x,h,b,S,$,C)=>{let w=0;const I=p.length;let A=f.length-1,O=I-1;for(;w<=A&&w<=O;){const F=f[w],U=p[w]=C?it(p[w]):Ue(p[w]);if(qt(F,U))T(F,U,g,null,h,b,S,$,C);else break;w++}for(;w<=A&&w<=O;){const F=f[A],U=p[O]=C?it(p[O]):Ue(p[O]);if(qt(F,U))T(F,U,g,null,h,b,S,$,C);else break;A--,O--}if(w>A){if(w<=O){const F=O+1,U=F<I?p[F].el:x;for(;w<=O;)T(null,p[w]=C?it(p[w]):Ue(p[w]),g,U,h,b,S,$,C),w++}}else if(w>O)for(;w<=A;)ke(f[w],h,b,!0),w++;else{const F=w,U=w,Y=new Map;for(w=U;w<=O;w++){const xe=p[w]=C?it(p[w]):Ue(p[w]);xe.key!=null&&Y.set(xe.key,w)}let z,be=0;const ae=O-U+1;let Ie=!1,ye=0;const Kt=new Array(ae);for(w=0;w<ae;w++)Kt[w]=0;for(w=F;w<=A;w++){const xe=f[w];if(be>=ae){ke(xe,h,b,!0);continue}let De;if(xe.key!=null)De=Y.get(xe.key);else for(z=U;z<=O;z++)if(Kt[z-U]===0&&qt(xe,p[z])){De=z;break}De===void 0?ke(xe,h,b,!0):(Kt[De-U]=w+1,De>=ye?ye=De:Ie=!0,T(xe,p[De],g,null,h,b,S,$,C),be++)}const Si=Ie?Ha(Kt):It;for(z=Si.length-1,w=ae-1;w>=0;w--){const xe=U+w,De=p[xe],Ei=xe+1<I?p[xe+1].el:x;Kt[w]===0?T(null,De,g,Ei,h,b,S,$,C):Ie&&(z<0||w!==Si[z]?ft(De,g,Ei,2):z--)}}},ft=(f,p,g,x,h=null)=>{const{el:b,type:S,transition:$,children:C,shapeFlag:w}=f;if(w&6){ft(f.component.subTree,p,g,x);return}if(w&128){f.suspense.move(p,g,x);return}if(w&64){S.move(f,p,g,Wt);return}if(S===_e){o(b,p,g);for(let A=0;A<C.length;A++)ft(C[A],p,g,x);o(f.anchor,p,g);return}if(S===Mn){G(f,p,g);return}if(x!==2&&w&1&&$)if(x===0)$.beforeEnter(b),o(b,p,g),we(()=>$.enter(b),h);else{const{leave:A,delayLeave:O,afterLeave:F}=$,U=()=>o(b,p,g),Y=()=>{A(b,()=>{U(),F&&F()})};O?O(b,U,Y):Y()}else o(b,p,g)},ke=(f,p,g,x=!1,h=!1)=>{const{type:b,props:S,ref:$,children:C,dynamicChildren:w,shapeFlag:I,patchFlag:A,dirs:O,cacheIndex:F}=f;if(A===-2&&(h=!1),$!=null&&So($,null,g,f,!0),F!=null&&(p.renderCache[F]=void 0),I&256){p.ctx.deactivate(f);return}const U=I&1&&O,Y=!Zt(f);let z;if(Y&&(z=S&&S.onVnodeBeforeUnmount)&&Re(z,p,f),I&6)vl(f.component,g,x);else{if(I&128){f.suspense.unmount(g,x);return}U&&pt(f,null,p,"beforeUnmount"),I&64?f.type.remove(f,p,g,Wt,x):w&&!w.hasOnce&&(b!==_e||A>0&&A&64)?zt(w,p,g,!1,!0):(b===_e&&A&384||!h&&I&16)&&zt(C,p,g),x&&wi(f)}(Y&&(z=S&&S.onVnodeUnmounted)||U)&&we(()=>{z&&Re(z,p,f),U&&pt(f,null,p,"unmounted")},g)},wi=f=>{const{type:p,el:g,anchor:x,transition:h}=f;if(p===_e){gl(g,x);return}if(p===Mn){M(f);return}const b=()=>{i(g),h&&!h.persisted&&h.afterLeave&&h.afterLeave()};if(f.shapeFlag&1&&h&&!h.persisted){const{leave:S,delayLeave:$}=h,C=()=>S(g,b);$?$(f.el,b,C):C()}else b()},gl=(f,p)=>{let g;for(;f!==p;)g=v(f),i(f),f=g;i(p)},vl=(f,p,g)=>{const{bum:x,scope:h,job:b,subTree:S,um:$,m:C,a:w}=f;Ni(C),Ni(w),x&&In(x),h.stop(),b&&(b.flags|=8,ke(S,f,p,g)),$&&we($,p),we(()=>{f.isUnmounted=!0},p),p&&p.pendingBranch&&!p.isUnmounted&&f.asyncDep&&!f.asyncResolved&&f.suspenseId===p.pendingId&&(p.deps--,p.deps===0&&p.resolve())},zt=(f,p,g,x=!1,h=!1,b=0)=>{for(let S=b;S<f.length;S++)ke(f[S],p,g,x,h)},$n=f=>{if(f.shapeFlag&6)return $n(f.component.subTree);if(f.shapeFlag&128)return f.suspense.next();const p=v(f.anchor||f.el),g=p&&p[da];return g?v(g):p};let ro=!1;const Ti=(f,p,g)=>{f==null?p._vnode&&ke(p._vnode,null,null,!0):T(p._vnode||null,f,p,null,null,null,g),p._vnode=f,ro||(ro=!0,Di(),as(),ro=!1)},Wt={p:T,um:ke,m:ft,r:wi,mt:io,mc:tt,pc:q,pbc:dt,n:$n,o:e};let Ci,$i;return{render:Ti,hydrate:Ci,createApp:Fa(Ti,Ci)}}function po({type:e,props:t},n){return n==="svg"&&e==="foreignObject"||n==="mathml"&&e==="annotation-xml"&&t&&t.encoding&&t.encoding.includes("html")?void 0:n}function mt({effect:e,job:t},n){n?(e.flags|=32,t.flags|=4):(e.flags&=-33,t.flags&=-5)}function Na(e,t){return(!e||e&&!e.pendingBranch)&&t&&!t.persisted}function Ps(e,t,n=!1){const o=e.children,i=t.children;if(P(o)&&P(i))for(let s=0;s<o.length;s++){const u=o[s];let r=i[s];r.shapeFlag&1&&!r.dynamicChildren&&((r.patchFlag<=0||r.patchFlag===32)&&(r=i[s]=it(i[s]),r.el=u.el),!n&&r.patchFlag!==-2&&Ps(u,r)),r.type===Xn&&(r.el=u.el)}}function Ha(e){const t=e.slice(),n=[0];let o,i,s,u,r;const c=e.length;for(o=0;o<c;o++){const a=e[o];if(a!==0){if(i=n[n.length-1],e[i]<a){t[o]=i,n.push(o);continue}for(s=0,u=n.length-1;s<u;)r=s+u>>1,e[n[r]]<a?s=r+1:u=r;a<e[n[s]]&&(s>0&&(t[o]=n[s-1]),n[s]=o)}}for(s=n.length,u=n[s-1];s-- >0;)n[s]=u,u=t[u];return n}function Is(e){const t=e.subTree.component;if(t)return t.asyncDep&&!t.asyncResolved?t:Is(t)}function Ni(e){if(e)for(let t=0;t<e.length;t++)e[t].flags|=8}const za=Symbol.for("v-scx"),Wa=()=>tn(za);function Le(e,t,n){return Ms(e,t,n)}function Ms(e,t,n=K){const{immediate:o,deep:i,flush:s,once:u}=n,r=le({},n);let c;if(Qn)if(s==="sync"){const v=Wa();c=v.__watcherHandles||(v.__watcherHandles=[])}else if(!t||o)r.once=!0;else{const v=()=>{};return v.stop=Be,v.resume=Be,v.pause=Be,v}const a=de;r.call=(v,E,R)=>Ne(v,a,E,R);let d=!1;s==="post"?r.scheduler=v=>{we(v,a&&a.suspense)}:s!=="sync"&&(d=!0,r.scheduler=(v,E)=>{E?v():ii(v)}),r.augmentJob=v=>{t&&(v.flags|=4),d&&(v.flags|=2,a&&(v.id=a.uid,v.i=a))};const m=sa(e,t,r);return c&&c.push(m),m}function Ka(e,t,n){const o=this.proxy,i=te(e)?e.includes(".")?Fs(o,e):()=>o[e]:e.bind(o,o);let s;D(t)?s=t:(s=t.handler,n=t);const u=hn(this),r=Ms(i,s.bind(o),n);return u(),r}function Fs(e,t){const n=t.split(".");return()=>{let o=e;for(let i=0;i<n.length&&o;i++)o=o[n[i]];return o}}const Ga=(e,t)=>t==="modelValue"||t==="model-value"?e.modelModifiers:e[`${t}Modifiers`]||e[`${Pe(t)}Modifiers`]||e[`${Tt(t)}Modifiers`];function qa(e,t,...n){if(e.isUnmounted)return;const o=e.vnode.props||K;let i=n;const s=t.startsWith("update:"),u=s&&Ga(o,t.slice(7));u&&(u.trim&&(i=n.map(d=>te(d)?d.trim():d)),u.number&&(i=n.map(Rn)));let r,c=o[r=so(t)]||o[r=so(Pe(t))];!c&&s&&(c=o[r=so(Tt(t))]),c&&Ne(c,e,6,i);const a=o[r+"Once"];if(a){if(!e.emitted)e.emitted={};else if(e.emitted[r])return;e.emitted[r]=!0,Ne(a,e,6,i)}}function ks(e,t,n=!1){const o=t.emitsCache,i=o.get(e);if(i!==void 0)return i;const s=e.emits;let u={},r=!1;if(!D(e)){const c=a=>{const d=ks(a,t,!0);d&&(r=!0,le(u,d))};!n&&t.mixins.length&&t.mixins.forEach(c),e.extends&&c(e.extends),e.mixins&&e.mixins.forEach(c)}return!s&&!r?(Q(e)&&o.set(e,null),null):(P(s)?s.forEach(c=>u[c]=null):le(u,s),Q(e)&&o.set(e,u),u)}function Jn(e,t){return!e||!Hn(t)?!1:(t=t.slice(2).replace(/Once$/,""),V(e,t[0].toLowerCase()+t.slice(1))||V(e,Tt(t))||V(e,t))}function mo(e){const{type:t,vnode:n,proxy:o,withProxy:i,propsOptions:[s],slots:u,attrs:r,emit:c,render:a,renderCache:d,props:m,data:v,setupState:E,ctx:R,inheritAttrs:T}=e,j=Un(e);let k,L;try{if(n.shapeFlag&4){const M=i||o,oe=M;k=Ue(a.call(oe,M,d,m,E,v,R)),L=r}else{const M=t;k=Ue(M.length>1?M(m,{attrs:r,slots:u,emit:c}):M(m,null)),L=t.props?r:Ya(r)}}catch(M){nn.length=0,qn(M,e,1),k=he(bt)}let G=k;if(L&&T!==!1){const M=Object.keys(L),{shapeFlag:oe}=G;M.length&&oe&7&&(s&&M.some(Vo)&&(L=Ja(L,s)),G=Rt(G,L,!1,!0))}return n.dirs&&(G=Rt(G,null,!1,!0),G.dirs=G.dirs?G.dirs.concat(n.dirs):n.dirs),n.transition&&ri(G,n.transition),k=G,Un(j),k}const Ya=e=>{let t;for(const n in e)(n==="class"||n==="style"||Hn(n))&&((t||(t={}))[n]=e[n]);return t},Ja=(e,t)=>{const n={};for(const o in e)(!Vo(o)||!(o.slice(9)in t))&&(n[o]=e[o]);return n};function Xa(e,t,n){const{props:o,children:i,component:s}=e,{props:u,children:r,patchFlag:c}=t,a=s.emitsOptions;if(t.dirs||t.transition)return!0;if(n&&c>=0){if(c&1024)return!0;if(c&16)return o?Hi(o,u,a):!!u;if(c&8){const d=t.dynamicProps;for(let m=0;m<d.length;m++){const v=d[m];if(u[v]!==o[v]&&!Jn(a,v))return!0}}}else return(i||r)&&(!r||!r.$stable)?!0:o===u?!1:o?u?Hi(o,u,a):!0:!!u;return!1}function Hi(e,t,n){const o=Object.keys(t);if(o.length!==Object.keys(e).length)return!0;for(let i=0;i<o.length;i++){const s=o[i];if(t[s]!==e[s]&&!Jn(n,s))return!0}return!1}function Qa({vnode:e,parent:t},n){for(;t;){const o=t.subTree;if(o.suspense&&o.suspense.activeBranch===e&&(o.el=e.el),o===e)(e=t.vnode).el=n,t=t.parent;else break}}const Ds=e=>e.__isSuspense;function Za(e,t){t&&t.pendingBranch?P(e)?t.effects.push(...e):t.effects.push(e):ua(e)}const _e=Symbol.for("v-fgt"),Xn=Symbol.for("v-txt"),bt=Symbol.for("v-cmt"),Mn=Symbol.for("v-stc"),nn=[];let $e=null;function B(e=!1){nn.push($e=e?null:[])}function eu(){nn.pop(),$e=nn[nn.length-1]||null}let un=1;function zi(e){un+=e,e<0&&$e&&($e.hasOnce=!0)}function Rs(e){return e.dynamicChildren=un>0?$e||It:null,eu(),un>0&&$e&&$e.push(e),e}function W(e,t,n,o,i,s){return Rs(l(e,t,n,o,i,s,!0))}function ai(e,t,n,o,i){return Rs(he(e,t,n,o,i,!0))}function Ln(e){return e?e.__v_isVNode===!0:!1}function qt(e,t){return e.type===t.type&&e.key===t.key}const js=({key:e})=>e??null,Fn=({ref:e,ref_key:t,ref_for:n})=>(typeof e=="number"&&(e=""+e),e!=null?te(e)||ce(e)||D(e)?{i:Ce,r:e,k:t,f:!!n}:e:null);function l(e,t=null,n=null,o=0,i=null,s=e===_e?0:1,u=!1,r=!1){const c={__v_isVNode:!0,__v_skip:!0,type:e,props:t,key:t&&js(t),ref:t&&Fn(t),scopeId:ds,slotScopeIds:null,children:n,component:null,suspense:null,ssContent:null,ssFallback:null,dirs:null,transition:null,el:null,anchor:null,target:null,targetStart:null,targetAnchor:null,staticCount:0,shapeFlag:s,patchFlag:o,dynamicProps:i,dynamicChildren:null,appContext:null,ctx:Ce};return r?(ui(c,n),s&128&&e.normalize(c)):n&&(c.shapeFlag|=te(n)?8:16),un>0&&!u&&$e&&(c.patchFlag>0||s&6)&&c.patchFlag!==32&&$e.push(c),c}const he=tu;function tu(e,t=null,n=null,o=0,i=null,s=!1){if((!e||e===hs)&&(e=bt),Ln(e)){const r=Rt(e,t,!0);return n&&ui(r,n),un>0&&!s&&$e&&(r.shapeFlag&6?$e[$e.indexOf(e)]=r:$e.push(r)),r.patchFlag=-2,r}if(fu(e)&&(e=e.__vccOpts),t){t=nu(t);let{class:r,style:c}=t;r&&!te(r)&&(t.class=Wo(r)),Q(c)&&(ti(c)&&!P(c)&&(c=le({},c)),t.style=zo(c))}const u=te(e)?1:Ds(e)?128:ca(e)?64:Q(e)?4:D(e)?2:0;return l(e,t,n,o,i,u,s,!0)}function nu(e){return e?ti(e)||Cs(e)?le({},e):e:null}function Rt(e,t,n=!1,o=!1){const{props:i,ref:s,patchFlag:u,children:r,transition:c}=e,a=t?ou(i||{},t):i,d={__v_isVNode:!0,__v_skip:!0,type:e.type,props:a,key:a&&js(a),ref:t&&t.ref?n&&s?P(s)?s.concat(Fn(t)):[s,Fn(t)]:Fn(t):s,scopeId:e.scopeId,slotScopeIds:e.slotScopeIds,children:r,target:e.target,targetStart:e.targetStart,targetAnchor:e.targetAnchor,staticCount:e.staticCount,shapeFlag:e.shapeFlag,patchFlag:t&&e.type!==_e?u===-1?16:u|16:u,dynamicProps:e.dynamicProps,dynamicChildren:e.dynamicChildren,appContext:e.appContext,dirs:e.dirs,transition:c,component:e.component,suspense:e.suspense,ssContent:e.ssContent&&Rt(e.ssContent),ssFallback:e.ssFallback&&Rt(e.ssFallback),el:e.el,anchor:e.anchor,ctx:e.ctx,ce:e.ce};return c&&o&&ri(d,c.clone(d)),d}function ne(e=" ",t=0){return he(Xn,null,e,t)}function ge(e,t){const n=he(Mn,null,e);return n.staticCount=t,n}function Se(e="",t=!1){return t?(B(),ai(bt,null,e)):he(bt,null,e)}function Ue(e){return e==null||typeof e=="boolean"?he(bt):P(e)?he(_e,null,e.slice()):Ln(e)?it(e):he(Xn,null,String(e))}function it(e){return e.el===null&&e.patchFlag!==-1||e.memo?e:Rt(e)}function ui(e,t){let n=0;const{shapeFlag:o}=e;if(t==null)t=null;else if(P(t))n=16;else if(typeof t=="object")if(o&65){const i=t.default;i&&(i._c&&(i._d=!1),ui(e,i()),i._c&&(i._d=!0));return}else{n=32;const i=t._;!i&&!Cs(t)?t._ctx=Ce:i===3&&Ce&&(Ce.slots._===1?t._=1:(t._=2,e.patchFlag|=1024))}else D(t)?(t={default:t,_ctx:Ce},n=32):(t=String(t),o&64?(n=16,t=[ne(t)]):n=8);e.children=t,e.shapeFlag|=n}function ou(...e){const t={};for(let n=0;n<e.length;n++){const o=e[n];for(const i in o)if(i==="class")t.class!==o.class&&(t.class=Wo([t.class,o.class]));else if(i==="style")t.style=zo([t.style,o.style]);else if(Hn(i)){const s=t[i],u=o[i];u&&s!==u&&!(P(s)&&s.includes(u))&&(t[i]=s?[].concat(s,u):u)}else i!==""&&(t[i]=o[i])}return t}function Re(e,t,n,o=null){Ne(e,t,7,[n,o])}const iu=ys();let ru=0;function su(e,t,n){const o=e.type,i=(t?t.appContext:e.appContext)||iu,s={uid:ru++,vnode:e,type:o,parent:t,appContext:i,root:null,next:null,subTree:null,effect:null,update:null,job:null,scope:new Pl(!0),render:null,proxy:null,exposed:null,exposeProxy:null,withProxy:null,provides:t?t.provides:Object.create(i.provides),ids:t?t.ids:["",0,0],accessCache:null,renderCache:[],components:null,directives:null,propsOptions:Ss(o,i),emitsOptions:ks(o,i),emit:null,emitted:null,propsDefaults:K,inheritAttrs:o.inheritAttrs,ctx:K,data:K,props:K,attrs:K,slots:K,refs:K,setupState:K,setupContext:null,suspense:n,suspenseId:n?n.pendingId:0,asyncDep:null,asyncResolved:!1,isMounted:!1,isUnmounted:!1,isDeactivated:!1,bc:null,c:null,bm:null,m:null,bu:null,u:null,um:null,bum:null,da:null,a:null,rtg:null,rtc:null,ec:null,sp:null};return s.ctx={_:s},s.root=t?t.root:s,s.emit=qa.bind(null,s),e.ce&&e.ce(s),s}let de=null,Vn,Io;{const e=Br(),t=(n,o)=>{let i;return(i=e[n])||(i=e[n]=[]),i.push(o),s=>{i.length>1?i.forEach(u=>u(s)):i[0](s)}};Vn=t("__VUE_INSTANCE_SETTERS__",n=>de=n),Io=t("__VUE_SSR_SETTERS__",n=>Qn=n)}const hn=e=>{const t=de;return Vn(e),e.scope.on(),()=>{e.scope.off(),Vn(t)}},Wi=()=>{de&&de.scope.off(),Vn(null)};function Us(e){return e.vnode.shapeFlag&4}let Qn=!1;function lu(e,t=!1,n=!1){t&&Io(t);const{props:o,children:i}=e.vnode,s=Us(e);ka(e,o,s,t),Ua(e,i,n);const u=s?au(e,t):void 0;return t&&Io(!1),u}function au(e,t){const n=e.type;e.accessCache=Object.create(null),e.proxy=new Proxy(e.ctx,Ea);const{setup:o}=n;if(o){const i=e.setupContext=o.length>1?du(e):null,s=hn(e);lt();const u=vn(o,e,0,[e.props,i]);if(at(),s(),Dr(u)){if(Zt(e)||fs(e),u.then(Wi,Wi),t)return u.then(r=>{Ki(e,r,t)}).catch(r=>{qn(r,e,0)});e.asyncDep=u}else Ki(e,u,t)}else Bs(e,t)}function Ki(e,t,n){D(t)?e.type.__ssrInlineRender?e.ssrRender=t:e.render=t:Q(t)&&(e.setupState=is(t)),Bs(e,n)}let Gi;function Bs(e,t,n){const o=e.type;if(!e.render){if(!t&&Gi&&!o.render){const i=o.template||si(e).template;if(i){const{isCustomElement:s,compilerOptions:u}=e.appContext.config,{delimiters:r,compilerOptions:c}=o,a=le(le({isCustomElement:s,delimiters:r},u),c);o.render=Gi(i,a)}}e.render=o.render||Be}{const i=hn(e);lt();try{Aa(e)}finally{at(),i()}}}const uu={get(e,t){return fe(e,"get",""),e[t]}};function du(e){const t=n=>{e.exposed=n||{}};return{attrs:new Proxy(e.attrs,uu),slots:e.slots,emit:e.emit,expose:t}}function Zn(e){return e.exposed?e.exposeProxy||(e.exposeProxy=new Proxy(is(To(e.exposed)),{get(t,n){if(n in t)return t[n];if(n in en)return en[n](e)},has(t,n){return n in t||n in en}})):e.proxy}function cu(e,t=!0){return D(e)?e.displayName||e.name:e.name||t&&e.__name}function fu(e){return D(e)&&"__vccOpts"in e}const N=(e,t)=>ia(e,t,Qn);function pu(e,t,n){const o=arguments.length;return o===2?Q(t)&&!P(t)?Ln(t)?he(e,null,[t]):he(e,t):he(e,null,t):(o>3?n=Array.prototype.slice.call(arguments,2):o===3&&Ln(n)&&(n=[n]),he(e,t,n))}const mu="3.5.10";/**
* @vue/runtime-dom v3.5.10
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/let Mo;const qi=typeof window<"u"&&window.trustedTypes;if(qi)try{Mo=qi.createPolicy("vue",{createHTML:e=>e})}catch{}const Ls=Mo?e=>Mo.createHTML(e):e=>e,gu="http://www.w3.org/2000/svg",vu="http://www.w3.org/1998/Math/MathML",Ke=typeof document<"u"?document:null,Yi=Ke&&Ke.createElement("template"),hu={insert:(e,t,n)=>{t.insertBefore(e,n||null)},remove:e=>{const t=e.parentNode;t&&t.removeChild(e)},createElement:(e,t,n,o)=>{const i=t==="svg"?Ke.createElementNS(gu,e):t==="mathml"?Ke.createElementNS(vu,e):n?Ke.createElement(e,{is:n}):Ke.createElement(e);return e==="select"&&o&&o.multiple!=null&&i.setAttribute("multiple",o.multiple),i},createText:e=>Ke.createTextNode(e),createComment:e=>Ke.createComment(e),setText:(e,t)=>{e.nodeValue=t},setElementText:(e,t)=>{e.textContent=t},parentNode:e=>e.parentNode,nextSibling:e=>e.nextSibling,querySelector:e=>Ke.querySelector(e),setScopeId(e,t){e.setAttribute(t,"")},insertStaticContent(e,t,n,o,i,s){const u=n?n.previousSibling:t.lastChild;if(i&&(i===s||i.nextSibling))for(;t.insertBefore(i.cloneNode(!0),n),!(i===s||!(i=i.nextSibling)););else{Yi.innerHTML=Ls(o==="svg"?`<svg>${e}</svg>`:o==="mathml"?`<math>${e}</math>`:e);const r=Yi.content;if(o==="svg"||o==="mathml"){const c=r.firstChild;for(;c.firstChild;)r.appendChild(c.firstChild);r.removeChild(c)}t.insertBefore(r,n)}return[u?u.nextSibling:t.firstChild,n?n.previousSibling:t.lastChild]}},bu=Symbol("_vtc");function yu(e,t,n){const o=e[bu];o&&(t=(t?[t,...o]:[...o]).join(" ")),t==null?e.removeAttribute("class"):n?e.setAttribute("class",t):e.className=t}const Ji=Symbol("_vod"),xu=Symbol("_vsh"),wu=Symbol(""),Tu=/(^|;)\s*display\s*:/;function Cu(e,t,n){const o=e.style,i=te(n);let s=!1;if(n&&!i){if(t)if(te(t))for(const u of t.split(";")){const r=u.slice(0,u.indexOf(":")).trim();n[r]==null&&kn(o,r,"")}else for(const u in t)n[u]==null&&kn(o,u,"");for(const u in n)u==="display"&&(s=!0),kn(o,u,n[u])}else if(i){if(t!==n){const u=o[wu];u&&(n+=";"+u),o.cssText=n,s=Tu.test(n)}}else t&&e.removeAttribute("style");Ji in e&&(e[Ji]=s?o.display:"",e[xu]&&(o.display="none"))}const Xi=/\s*!important$/;function kn(e,t,n){if(P(n))n.forEach(o=>kn(e,t,o));else if(n==null&&(n=""),t.startsWith("--"))e.setProperty(t,n);else{const o=$u(e,t);Xi.test(n)?e.setProperty(Tt(o),n.replace(Xi,""),"important"):e[o]=n}}const Qi=["Webkit","Moz","ms"],go={};function $u(e,t){const n=go[t];if(n)return n;let o=Pe(t);if(o!=="filter"&&o in e)return go[t]=o;o=Wn(o);for(let i=0;i<Qi.length;i++){const s=Qi[i]+o;if(s in e)return go[t]=s}return t}const Zi="http://www.w3.org/1999/xlink";function er(e,t,n,o,i,s=_l(t)){o&&t.startsWith("xlink:")?n==null?e.removeAttributeNS(Zi,t.slice(6,t.length)):e.setAttributeNS(Zi,t,n):n==null||s&&!Lr(n)?e.removeAttribute(t):e.setAttribute(t,s?"":Ve(n)?String(n):n)}function tr(e,t,n,o){if(t==="innerHTML"||t==="textContent"){n!=null&&(e[t]=t==="innerHTML"?Ls(n):n);return}const i=e.tagName;if(t==="value"&&i!=="PROGRESS"&&!i.includes("-")){const u=i==="OPTION"?e.getAttribute("value")||"":e.value,r=n==null?e.type==="checkbox"?"on":"":String(n);(u!==r||!("_value"in e))&&(e.value=r),n==null&&e.removeAttribute(t),e._value=n;return}let s=!1;if(n===""||n==null){const u=typeof e[t];u==="boolean"?n=Lr(n):n==null&&u==="string"?(n="",s=!0):u==="number"&&(n=0,s=!0)}try{e[t]=n}catch{}s&&e.removeAttribute(t)}function rt(e,t,n,o){e.addEventListener(t,n,o)}function Su(e,t,n,o){e.removeEventListener(t,n,o)}const nr=Symbol("_vei");function Eu(e,t,n,o,i=null){const s=e[nr]||(e[nr]={}),u=s[t];if(o&&u)u.value=o;else{const[r,c]=Au(t);if(o){const a=s[t]=Pu(o,i);rt(e,r,a,c)}else u&&(Su(e,r,u,c),s[t]=void 0)}}const or=/(?:Once|Passive|Capture)$/;function Au(e){let t;if(or.test(e)){t={};let o;for(;o=e.match(or);)e=e.slice(0,e.length-o[0].length),t[o[0].toLowerCase()]=!0}return[e[2]===":"?e.slice(3):Tt(e.slice(2)),t]}let vo=0;const _u=Promise.resolve(),Ou=()=>vo||(_u.then(()=>vo=0),vo=Date.now());function Pu(e,t){const n=o=>{if(!o._vts)o._vts=Date.now();else if(o._vts<=n.attached)return;Ne(Iu(o,n.value),t,5,[o])};return n.value=e,n.attached=Ou(),n}function Iu(e,t){if(P(t)){const n=e.stopImmediatePropagation;return e.stopImmediatePropagation=()=>{n.call(e),e._stopped=!0},t.map(o=>i=>!i._stopped&&o&&o(i))}else return t}const ir=e=>e.charCodeAt(0)===111&&e.charCodeAt(1)===110&&e.charCodeAt(2)>96&&e.charCodeAt(2)<123,Mu=(e,t,n,o,i,s)=>{const u=i==="svg";t==="class"?yu(e,o,u):t==="style"?Cu(e,n,o):Hn(t)?Vo(t)||Eu(e,t,n,o,s):(t[0]==="."?(t=t.slice(1),!0):t[0]==="^"?(t=t.slice(1),!1):Fu(e,t,o,u))?(tr(e,t,o),!e.tagName.includes("-")&&(t==="value"||t==="checked"||t==="selected")&&er(e,t,o,u,s,t!=="value")):e._isVueCE&&(/[A-Z]/.test(t)||!te(o))?tr(e,Pe(t),o):(t==="true-value"?e._trueValue=o:t==="false-value"&&(e._falseValue=o),er(e,t,o,u))};function Fu(e,t,n,o){if(o)return!!(t==="innerHTML"||t==="textContent"||t in e&&ir(t)&&D(n));if(t==="spellcheck"||t==="draggable"||t==="translate"||t==="form"||t==="list"&&e.tagName==="INPUT"||t==="type"&&e.tagName==="TEXTAREA")return!1;if(t==="width"||t==="height"){const i=e.tagName;if(i==="IMG"||i==="VIDEO"||i==="CANVAS"||i==="SOURCE")return!1}return ir(t)&&te(n)?!1:t in e}const jt=e=>{const t=e.props["onUpdate:modelValue"]||!1;return P(t)?n=>In(t,n):t};function ku(e){e.target.composing=!0}function rr(e){const t=e.target;t.composing&&(t.composing=!1,t.dispatchEvent(new Event("input")))}const Je=Symbol("_assign"),_={created(e,{modifiers:{lazy:t,trim:n,number:o}},i){e[Je]=jt(i);const s=o||i.props&&i.props.type==="number";rt(e,t?"change":"input",u=>{if(u.target.composing)return;let r=e.value;n&&(r=r.trim()),s&&(r=Rn(r)),e[Je](r)}),n&&rt(e,"change",()=>{e.value=e.value.trim()}),t||(rt(e,"compositionstart",ku),rt(e,"compositionend",rr),rt(e,"change",rr))},mounted(e,{value:t}){e.value=t??""},beforeUpdate(e,{value:t,oldValue:n,modifiers:{lazy:o,trim:i,number:s}},u){if(e[Je]=jt(u),e.composing)return;const r=(s||e.type==="number")&&!/^0\d/.test(e.value)?Rn(e.value):e.value,c=t??"";r!==c&&(document.activeElement===e&&e.type!=="range"&&(o&&t===n||i&&e.value.trim()===c)||(e.value=c))}},ie={deep:!0,created(e,t,n){e[Je]=jt(n),rt(e,"change",()=>{const o=e._modelValue,i=dn(e),s=e.checked,u=e[Je];if(P(o)){const r=Ko(o,i),c=r!==-1;if(s&&!c)u(o.concat(i));else if(!s&&c){const a=[...o];a.splice(r,1),u(a)}}else if(Lt(o)){const r=new Set(o);s?r.add(i):r.delete(i),u(r)}else u(Vs(e,s))})},mounted:sr,beforeUpdate(e,t,n){e[Je]=jt(n),sr(e,t,n)}};function sr(e,{value:t},n){e._modelValue=t;let o;P(t)?o=Ko(t,n.props.value)>-1:Lt(t)?o=t.has(n.props.value):o=gn(t,Vs(e,!0)),e.checked!==o&&(e.checked=o)}const re={deep:!0,created(e,{value:t,modifiers:{number:n}},o){const i=Lt(t);rt(e,"change",()=>{const s=Array.prototype.filter.call(e.options,u=>u.selected).map(u=>n?Rn(dn(u)):dn(u));e[Je](e.multiple?i?new Set(s):s:s[0]),e._assigning=!0,ss(()=>{e._assigning=!1})}),e[Je]=jt(o)},mounted(e,{value:t}){lr(e,t)},beforeUpdate(e,t,n){e[Je]=jt(n)},updated(e,{value:t}){e._assigning||lr(e,t)}};function lr(e,t){const n=e.multiple,o=P(t);if(!(n&&!o&&!Lt(t))){for(let i=0,s=e.options.length;i<s;i++){const u=e.options[i],r=dn(u);if(n)if(o){const c=typeof r;c==="string"||c==="number"?u.selected=t.some(a=>String(a)===String(r)):u.selected=Ko(t,r)>-1}else u.selected=t.has(r);else if(gn(dn(u),t)){e.selectedIndex!==i&&(e.selectedIndex=i);return}}!n&&e.selectedIndex!==-1&&(e.selectedIndex=-1)}}function dn(e){return"_value"in e?e._value:e.value}function Vs(e,t){const n=t?"_trueValue":"_falseValue";return n in e?e[n]:t}const Du=le({patchProp:Mu},hu);let ar;function Ru(){return ar||(ar=La(Du))}const ju=(...e)=>{const t=Ru().createApp(...e),{mount:n}=t;return t.mount=o=>{const i=Bu(o);if(!i)return;const s=t._component;!D(s)&&!s.render&&!s.template&&(s.template=i.innerHTML),i.nodeType===1&&(i.textContent="");const u=n(i,!1,Uu(i));return i instanceof Element&&(i.removeAttribute("v-cloak"),i.setAttribute("data-v-app","")),u},t};function Uu(e){if(e instanceof SVGElement)return"svg";if(typeof MathMLElement=="function"&&e instanceof MathMLElement)return"mathml"}function Bu(e){return te(e)?document.querySelector(e):e}function ur(e){for(var t=0,n,o=0,i=e.length;i>=4;++o,i-=4)n=e.charCodeAt(o)&255|(e.charCodeAt(++o)&255)<<8|(e.charCodeAt(++o)&255)<<16|(e.charCodeAt(++o)&255)<<24,n=(n&65535)*1540483477+((n>>>16)*59797<<16),n^=n>>>24,t=(n&65535)*1540483477+((n>>>16)*59797<<16)^(t&65535)*1540483477+((t>>>16)*59797<<16);switch(i){case 3:t^=(e.charCodeAt(o+2)&255)<<16;case 2:t^=(e.charCodeAt(o+1)&255)<<8;case 1:t^=e.charCodeAt(o)&255,t=(t&65535)*1540483477+((t>>>16)*59797<<16)}return t^=t>>>13,t=(t&65535)*1540483477+((t>>>16)*59797<<16),((t^t>>>15)>>>0).toString(36)}function dr(e){const t=N(e),n=He(t.value);return Le(t,o=>{n.value=o}),typeof e=="function"?n:{__v_isRef:!0,get value(){return n.value},set value(o){e.set(o)}}}function Lu(e,t){console.error(`[naive/${e}]: ${t}`)}const cr="n-config-provider",fr="n";var Ns=typeof global=="object"&&global&&global.Object===Object&&global,Vu=typeof self=="object"&&self&&self.Object===Object&&self,ze=Ns||Vu||Function("return this")(),Ut=ze.Symbol,Hs=Object.prototype,Nu=Hs.hasOwnProperty,Hu=Hs.toString,Yt=Ut?Ut.toStringTag:void 0;function zu(e){var t=Nu.call(e,Yt),n=e[Yt];try{e[Yt]=void 0;var o=!0}catch{}var i=Hu.call(e);return o&&(t?e[Yt]=n:delete e[Yt]),i}var Wu=Object.prototype,Ku=Wu.toString;function Gu(e){return Ku.call(e)}var qu="[object Null]",Yu="[object Undefined]",pr=Ut?Ut.toStringTag:void 0;function Vt(e){return e==null?e===void 0?Yu:qu:pr&&pr in Object(e)?zu(e):Gu(e)}function Ct(e){return e!=null&&typeof e=="object"}var cn=Array.isArray;function ut(e){var t=typeof e;return e!=null&&(t=="object"||t=="function")}function zs(e){return e}var Ju="[object AsyncFunction]",Xu="[object Function]",Qu="[object GeneratorFunction]",Zu="[object Proxy]";function di(e){if(!ut(e))return!1;var t=Vt(e);return t==Xu||t==Qu||t==Ju||t==Zu}var ho=ze["__core-js_shared__"],mr=function(){var e=/[^.]+$/.exec(ho&&ho.keys&&ho.keys.IE_PROTO||"");return e?"Symbol(src)_1."+e:""}();function ed(e){return!!mr&&mr in e}var td=Function.prototype,nd=td.toString;function $t(e){if(e!=null){try{return nd.call(e)}catch{}try{return e+""}catch{}}return""}var od=/[\\^$.*+?()[\]{}|]/g,id=/^\[object .+?Constructor\]$/,rd=Function.prototype,sd=Object.prototype,ld=rd.toString,ad=sd.hasOwnProperty,ud=RegExp("^"+ld.call(ad).replace(od,"\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,"$1.*?")+"$");function dd(e){if(!ut(e)||ed(e))return!1;var t=di(e)?ud:id;return t.test($t(e))}function cd(e,t){return e==null?void 0:e[t]}function St(e,t){var n=cd(e,t);return dd(n)?n:void 0}var Fo=St(ze,"WeakMap"),gr=Object.create,fd=function(){function e(){}return function(t){if(!ut(t))return{};if(gr)return gr(t);e.prototype=t;var n=new e;return e.prototype=void 0,n}}();function pd(e,t,n){switch(n.length){case 0:return e.call(t);case 1:return e.call(t,n[0]);case 2:return e.call(t,n[0],n[1]);case 3:return e.call(t,n[0],n[1],n[2])}return e.apply(t,n)}function Ws(e,t){var n=-1,o=e.length;for(t||(t=Array(o));++n<o;)t[n]=e[n];return t}var md=800,gd=16,vd=Date.now;function hd(e){var t=0,n=0;return function(){var o=vd(),i=gd-(o-n);if(n=o,i>0){if(++t>=md)return arguments[0]}else t=0;return e.apply(void 0,arguments)}}function bd(e){return function(){return e}}var Nn=function(){try{var e=St(Object,"defineProperty");return e({},"",{}),e}catch{}}(),yd=Nn?function(e,t){return Nn(e,"toString",{configurable:!0,enumerable:!1,value:bd(t),writable:!0})}:zs,xd=hd(yd);function wd(e,t){for(var n=-1,o=e==null?0:e.length;++n<o&&t(e[n],n,e)!==!1;);return e}var Td=9007199254740991,Cd=/^(?:0|[1-9]\d*)$/;function Ks(e,t){var n=typeof e;return t=t??Td,!!t&&(n=="number"||n!="symbol"&&Cd.test(e))&&e>-1&&e%1==0&&e<t}function ci(e,t,n){t=="__proto__"&&Nn?Nn(e,t,{configurable:!0,enumerable:!0,value:n,writable:!0}):e[t]=n}function eo(e,t){return e===t||e!==e&&t!==t}var $d=Object.prototype,Sd=$d.hasOwnProperty;function Gs(e,t,n){var o=e[t];(!(Sd.call(e,t)&&eo(o,n))||n===void 0&&!(t in e))&&ci(e,t,n)}function bn(e,t,n,o){var i=!n;n||(n={});for(var s=-1,u=t.length;++s<u;){var r=t[s],c=void 0;c===void 0&&(c=e[r]),i?ci(n,r,c):Gs(n,r,c)}return n}var vr=Math.max;function Ed(e,t,n){return t=vr(t===void 0?e.length-1:t,0),function(){for(var o=arguments,i=-1,s=vr(o.length-t,0),u=Array(s);++i<s;)u[i]=o[t+i];i=-1;for(var r=Array(t+1);++i<t;)r[i]=o[i];return r[t]=n(u),pd(e,this,r)}}function Ad(e,t){return xd(Ed(e,t,zs),e+"")}var _d=9007199254740991;function qs(e){return typeof e=="number"&&e>-1&&e%1==0&&e<=_d}function to(e){return e!=null&&qs(e.length)&&!di(e)}function Od(e,t,n){if(!ut(n))return!1;var o=typeof t;return(o=="number"?to(n)&&Ks(t,n.length):o=="string"&&t in n)?eo(n[t],e):!1}function Pd(e){return Ad(function(t,n){var o=-1,i=n.length,s=i>1?n[i-1]:void 0,u=i>2?n[2]:void 0;for(s=e.length>3&&typeof s=="function"?(i--,s):void 0,u&&Od(n[0],n[1],u)&&(s=i<3?void 0:s,i=1),t=Object(t);++o<i;){var r=n[o];r&&e(t,r,o,s)}return t})}var Id=Object.prototype;function fi(e){var t=e&&e.constructor,n=typeof t=="function"&&t.prototype||Id;return e===n}function Md(e,t){for(var n=-1,o=Array(e);++n<e;)o[n]=t(n);return o}var Fd="[object Arguments]";function hr(e){return Ct(e)&&Vt(e)==Fd}var Ys=Object.prototype,kd=Ys.hasOwnProperty,Dd=Ys.propertyIsEnumerable,ko=hr(function(){return arguments}())?hr:function(e){return Ct(e)&&kd.call(e,"callee")&&!Dd.call(e,"callee")};function Rd(){return!1}var Js=typeof Ee=="object"&&Ee&&!Ee.nodeType&&Ee,br=Js&&typeof Ae=="object"&&Ae&&!Ae.nodeType&&Ae,jd=br&&br.exports===Js,yr=jd?ze.Buffer:void 0,Ud=yr?yr.isBuffer:void 0,pi=Ud||Rd,Bd="[object Arguments]",Ld="[object Array]",Vd="[object Boolean]",Nd="[object Date]",Hd="[object Error]",zd="[object Function]",Wd="[object Map]",Kd="[object Number]",Gd="[object Object]",qd="[object RegExp]",Yd="[object Set]",Jd="[object String]",Xd="[object WeakMap]",Qd="[object ArrayBuffer]",Zd="[object DataView]",ec="[object Float32Array]",tc="[object Float64Array]",nc="[object Int8Array]",oc="[object Int16Array]",ic="[object Int32Array]",rc="[object Uint8Array]",sc="[object Uint8ClampedArray]",lc="[object Uint16Array]",ac="[object Uint32Array]",Z={};Z[ec]=Z[tc]=Z[nc]=Z[oc]=Z[ic]=Z[rc]=Z[sc]=Z[lc]=Z[ac]=!0;Z[Bd]=Z[Ld]=Z[Qd]=Z[Vd]=Z[Zd]=Z[Nd]=Z[Hd]=Z[zd]=Z[Wd]=Z[Kd]=Z[Gd]=Z[qd]=Z[Yd]=Z[Jd]=Z[Xd]=!1;function uc(e){return Ct(e)&&qs(e.length)&&!!Z[Vt(e)]}function mi(e){return function(t){return e(t)}}var Xs=typeof Ee=="object"&&Ee&&!Ee.nodeType&&Ee,on=Xs&&typeof Ae=="object"&&Ae&&!Ae.nodeType&&Ae,dc=on&&on.exports===Xs,bo=dc&&Ns.process,Bt=function(){try{var e=on&&on.require&&on.require("util").types;return e||bo&&bo.binding&&bo.binding("util")}catch{}}(),xr=Bt&&Bt.isTypedArray,Qs=xr?mi(xr):uc,cc=Object.prototype,fc=cc.hasOwnProperty;function Zs(e,t){var n=cn(e),o=!n&&ko(e),i=!n&&!o&&pi(e),s=!n&&!o&&!i&&Qs(e),u=n||o||i||s,r=u?Md(e.length,String):[],c=r.length;for(var a in e)(t||fc.call(e,a))&&!(u&&(a=="length"||i&&(a=="offset"||a=="parent")||s&&(a=="buffer"||a=="byteLength"||a=="byteOffset")||Ks(a,c)))&&r.push(a);return r}function el(e,t){return function(n){return e(t(n))}}var pc=el(Object.keys,Object),mc=Object.prototype,gc=mc.hasOwnProperty;function vc(e){if(!fi(e))return pc(e);var t=[];for(var n in Object(e))gc.call(e,n)&&n!="constructor"&&t.push(n);return t}function gi(e){return to(e)?Zs(e):vc(e)}function hc(e){var t=[];if(e!=null)for(var n in Object(e))t.push(n);return t}var bc=Object.prototype,yc=bc.hasOwnProperty;function xc(e){if(!ut(e))return hc(e);var t=fi(e),n=[];for(var o in e)o=="constructor"&&(t||!yc.call(e,o))||n.push(o);return n}function yn(e){return to(e)?Zs(e,!0):xc(e)}var fn=St(Object,"create");function wc(){this.__data__=fn?fn(null):{},this.size=0}function Tc(e){var t=this.has(e)&&delete this.__data__[e];return this.size-=t?1:0,t}var Cc="__lodash_hash_undefined__",$c=Object.prototype,Sc=$c.hasOwnProperty;function Ec(e){var t=this.__data__;if(fn){var n=t[e];return n===Cc?void 0:n}return Sc.call(t,e)?t[e]:void 0}var Ac=Object.prototype,_c=Ac.hasOwnProperty;function Oc(e){var t=this.__data__;return fn?t[e]!==void 0:_c.call(t,e)}var Pc="__lodash_hash_undefined__";function Ic(e,t){var n=this.__data__;return this.size+=this.has(e)?0:1,n[e]=fn&&t===void 0?Pc:t,this}function yt(e){var t=-1,n=e==null?0:e.length;for(this.clear();++t<n;){var o=e[t];this.set(o[0],o[1])}}yt.prototype.clear=wc;yt.prototype.delete=Tc;yt.prototype.get=Ec;yt.prototype.has=Oc;yt.prototype.set=Ic;function Mc(){this.__data__=[],this.size=0}function no(e,t){for(var n=e.length;n--;)if(eo(e[n][0],t))return n;return-1}var Fc=Array.prototype,kc=Fc.splice;function Dc(e){var t=this.__data__,n=no(t,e);if(n<0)return!1;var o=t.length-1;return n==o?t.pop():kc.call(t,n,1),--this.size,!0}function Rc(e){var t=this.__data__,n=no(t,e);return n<0?void 0:t[n][1]}function jc(e){return no(this.__data__,e)>-1}function Uc(e,t){var n=this.__data__,o=no(n,e);return o<0?(++this.size,n.push([e,t])):n[o][1]=t,this}function Ze(e){var t=-1,n=e==null?0:e.length;for(this.clear();++t<n;){var o=e[t];this.set(o[0],o[1])}}Ze.prototype.clear=Mc;Ze.prototype.delete=Dc;Ze.prototype.get=Rc;Ze.prototype.has=jc;Ze.prototype.set=Uc;var pn=St(ze,"Map");function Bc(){this.size=0,this.__data__={hash:new yt,map:new(pn||Ze),string:new yt}}function Lc(e){var t=typeof e;return t=="string"||t=="number"||t=="symbol"||t=="boolean"?e!=="__proto__":e===null}function oo(e,t){var n=e.__data__;return Lc(t)?n[typeof t=="string"?"string":"hash"]:n.map}function Vc(e){var t=oo(this,e).delete(e);return this.size-=t?1:0,t}function Nc(e){return oo(this,e).get(e)}function Hc(e){return oo(this,e).has(e)}function zc(e,t){var n=oo(this,e),o=n.size;return n.set(e,t),this.size+=n.size==o?0:1,this}function Nt(e){var t=-1,n=e==null?0:e.length;for(this.clear();++t<n;){var o=e[t];this.set(o[0],o[1])}}Nt.prototype.clear=Bc;Nt.prototype.delete=Vc;Nt.prototype.get=Nc;Nt.prototype.has=Hc;Nt.prototype.set=zc;function tl(e,t){for(var n=-1,o=t.length,i=e.length;++n<o;)e[i+n]=t[n];return e}var vi=el(Object.getPrototypeOf,Object),Wc="[object Object]",Kc=Function.prototype,Gc=Object.prototype,nl=Kc.toString,qc=Gc.hasOwnProperty,Yc=nl.call(Object);function Jc(e){if(!Ct(e)||Vt(e)!=Wc)return!1;var t=vi(e);if(t===null)return!0;var n=qc.call(t,"constructor")&&t.constructor;return typeof n=="function"&&n instanceof n&&nl.call(n)==Yc}function Xc(){this.__data__=new Ze,this.size=0}function Qc(e){var t=this.__data__,n=t.delete(e);return this.size=t.size,n}function Zc(e){return this.__data__.get(e)}function ef(e){return this.__data__.has(e)}var tf=200;function nf(e,t){var n=this.__data__;if(n instanceof Ze){var o=n.__data__;if(!pn||o.length<tf-1)return o.push([e,t]),this.size=++n.size,this;n=this.__data__=new Nt(o)}return n.set(e,t),this.size=n.size,this}function Et(e){var t=this.__data__=new Ze(e);this.size=t.size}Et.prototype.clear=Xc;Et.prototype.delete=Qc;Et.prototype.get=Zc;Et.prototype.has=ef;Et.prototype.set=nf;function of(e,t){return e&&bn(t,gi(t),e)}function rf(e,t){return e&&bn(t,yn(t),e)}var ol=typeof Ee=="object"&&Ee&&!Ee.nodeType&&Ee,wr=ol&&typeof Ae=="object"&&Ae&&!Ae.nodeType&&Ae,sf=wr&&wr.exports===ol,Tr=sf?ze.Buffer:void 0,Cr=Tr?Tr.allocUnsafe:void 0;function il(e,t){if(t)return e.slice();var n=e.length,o=Cr?Cr(n):new e.constructor(n);return e.copy(o),o}function lf(e,t){for(var n=-1,o=e==null?0:e.length,i=0,s=[];++n<o;){var u=e[n];t(u,n,e)&&(s[i++]=u)}return s}function rl(){return[]}var af=Object.prototype,uf=af.propertyIsEnumerable,$r=Object.getOwnPropertySymbols,hi=$r?function(e){return e==null?[]:(e=Object(e),lf($r(e),function(t){return uf.call(e,t)}))}:rl;function df(e,t){return bn(e,hi(e),t)}var cf=Object.getOwnPropertySymbols,sl=cf?function(e){for(var t=[];e;)tl(t,hi(e)),e=vi(e);return t}:rl;function ff(e,t){return bn(e,sl(e),t)}function ll(e,t,n){var o=t(e);return cn(e)?o:tl(o,n(e))}function pf(e){return ll(e,gi,hi)}function mf(e){return ll(e,yn,sl)}var Do=St(ze,"DataView"),Ro=St(ze,"Promise"),jo=St(ze,"Set"),Sr="[object Map]",gf="[object Object]",Er="[object Promise]",Ar="[object Set]",_r="[object WeakMap]",Or="[object DataView]",vf=$t(Do),hf=$t(pn),bf=$t(Ro),yf=$t(jo),xf=$t(Fo),Ge=Vt;(Do&&Ge(new Do(new ArrayBuffer(1)))!=Or||pn&&Ge(new pn)!=Sr||Ro&&Ge(Ro.resolve())!=Er||jo&&Ge(new jo)!=Ar||Fo&&Ge(new Fo)!=_r)&&(Ge=function(e){var t=Vt(e),n=t==gf?e.constructor:void 0,o=n?$t(n):"";if(o)switch(o){case vf:return Or;case hf:return Sr;case bf:return Er;case yf:return Ar;case xf:return _r}return t});var wf=Object.prototype,Tf=wf.hasOwnProperty;function Cf(e){var t=e.length,n=new e.constructor(t);return t&&typeof e[0]=="string"&&Tf.call(e,"index")&&(n.index=e.index,n.input=e.input),n}var Pr=ze.Uint8Array;function bi(e){var t=new e.constructor(e.byteLength);return new Pr(t).set(new Pr(e)),t}function $f(e,t){var n=t?bi(e.buffer):e.buffer;return new e.constructor(n,e.byteOffset,e.byteLength)}var Sf=/\w*$/;function Ef(e){var t=new e.constructor(e.source,Sf.exec(e));return t.lastIndex=e.lastIndex,t}var Ir=Ut?Ut.prototype:void 0,Mr=Ir?Ir.valueOf:void 0;function Af(e){return Mr?Object(Mr.call(e)):{}}function al(e,t){var n=t?bi(e.buffer):e.buffer;return new e.constructor(n,e.byteOffset,e.length)}var _f="[object Boolean]",Of="[object Date]",Pf="[object Map]",If="[object Number]",Mf="[object RegExp]",Ff="[object Set]",kf="[object String]",Df="[object Symbol]",Rf="[object ArrayBuffer]",jf="[object DataView]",Uf="[object Float32Array]",Bf="[object Float64Array]",Lf="[object Int8Array]",Vf="[object Int16Array]",Nf="[object Int32Array]",Hf="[object Uint8Array]",zf="[object Uint8ClampedArray]",Wf="[object Uint16Array]",Kf="[object Uint32Array]";function Gf(e,t,n){var o=e.constructor;switch(t){case Rf:return bi(e);case _f:case Of:return new o(+e);case jf:return $f(e,n);case Uf:case Bf:case Lf:case Vf:case Nf:case Hf:case zf:case Wf:case Kf:return al(e,n);case Pf:return new o;case If:case kf:return new o(e);case Mf:return Ef(e);case Ff:return new o;case Df:return Af(e)}}function ul(e){return typeof e.constructor=="function"&&!fi(e)?fd(vi(e)):{}}var qf="[object Map]";function Yf(e){return Ct(e)&&Ge(e)==qf}var Fr=Bt&&Bt.isMap,Jf=Fr?mi(Fr):Yf,Xf="[object Set]";function Qf(e){return Ct(e)&&Ge(e)==Xf}var kr=Bt&&Bt.isSet,Zf=kr?mi(kr):Qf,ep=1,tp=2,np=4,dl="[object Arguments]",op="[object Array]",ip="[object Boolean]",rp="[object Date]",sp="[object Error]",cl="[object Function]",lp="[object GeneratorFunction]",ap="[object Map]",up="[object Number]",fl="[object Object]",dp="[object RegExp]",cp="[object Set]",fp="[object String]",pp="[object Symbol]",mp="[object WeakMap]",gp="[object ArrayBuffer]",vp="[object DataView]",hp="[object Float32Array]",bp="[object Float64Array]",yp="[object Int8Array]",xp="[object Int16Array]",wp="[object Int32Array]",Tp="[object Uint8Array]",Cp="[object Uint8ClampedArray]",$p="[object Uint16Array]",Sp="[object Uint32Array]",J={};J[dl]=J[op]=J[gp]=J[vp]=J[ip]=J[rp]=J[hp]=J[bp]=J[yp]=J[xp]=J[wp]=J[ap]=J[up]=J[fl]=J[dp]=J[cp]=J[fp]=J[pp]=J[Tp]=J[Cp]=J[$p]=J[Sp]=!0;J[sp]=J[cl]=J[mp]=!1;function Dn(e,t,n,o,i,s){var u,r=t&ep,c=t&tp,a=t&np;if(u!==void 0)return u;if(!ut(e))return e;var d=cn(e);if(d){if(u=Cf(e),!r)return Ws(e,u)}else{var m=Ge(e),v=m==cl||m==lp;if(pi(e))return il(e,r);if(m==fl||m==dl||v&&!i){if(u=c||v?{}:ul(e),!r)return c?ff(e,rf(u,e)):df(e,of(u,e))}else{if(!J[m])return i?e:{};u=Gf(e,m,r)}}s||(s=new Et);var E=s.get(e);if(E)return E;s.set(e,u),Zf(e)?e.forEach(function(j){u.add(Dn(j,t,n,j,e,s))}):Jf(e)&&e.forEach(function(j,k){u.set(k,Dn(j,t,n,k,e,s))});var R=a?c?mf:pf:c?yn:gi,T=d?void 0:R(e);return wd(T||e,function(j,k){T&&(k=j,j=e[k]),Gs(u,k,Dn(j,t,n,k,e,s))}),u}var Ep=1,Ap=4;function _p(e){return Dn(e,Ep|Ap)}function Op(e){return function(t,n,o){for(var i=-1,s=Object(t),u=o(t),r=u.length;r--;){var c=u[++i];if(n(s[c],c,s)===!1)break}return t}}var Pp=Op();function Uo(e,t,n){(n!==void 0&&!eo(e[t],n)||n===void 0&&!(t in e))&&ci(e,t,n)}function Ip(e){return Ct(e)&&to(e)}function Bo(e,t){if(!(t==="constructor"&&typeof e[t]=="function")&&t!="__proto__")return e[t]}function Mp(e){return bn(e,yn(e))}function Fp(e,t,n,o,i,s,u){var r=Bo(e,n),c=Bo(t,n),a=u.get(c);if(a){Uo(e,n,a);return}var d=s?s(r,c,n+"",e,t,u):void 0,m=d===void 0;if(m){var v=cn(c),E=!v&&pi(c),R=!v&&!E&&Qs(c);d=c,v||E||R?cn(r)?d=r:Ip(r)?d=Ws(r):E?(m=!1,d=il(c,!0)):R?(m=!1,d=al(c,!0)):d=[]:Jc(c)||ko(c)?(d=r,ko(r)?d=Mp(r):(!ut(r)||di(r))&&(d=ul(c))):m=!1}m&&(u.set(c,d),i(d,c,o,s,u),u.delete(c)),Uo(e,n,d)}function pl(e,t,n,o,i){e!==t&&Pp(t,function(s,u){if(i||(i=new Et),ut(s))Fp(e,t,u,n,pl,o,i);else{var r=o?o(Bo(e,u),s,u+"",e,t,i):void 0;r===void 0&&(r=s),Uo(e,u,r)}},yn)}var kp=Pd(function(e,t,n){pl(e,t,n)});const Dp={abstract:Boolean,bordered:{type:Boolean,default:void 0},clsPrefix:String,locale:Object,dateLocale:Object,namespace:String,rtl:Array,tag:{type:String,default:"div"},hljs:Object,katex:Object,theme:Object,themeOverrides:Object,componentOptions:Object,icons:Object,breakpoints:Object,preflightStyleDisabled:Boolean,styleMountTarget:Object,inlineThemeDisabled:{type:Boolean,default:void 0},as:{type:String,validator:()=>(Lu("config-provider","`as` is deprecated, please use `tag` instead."),!0),default:void 0}},Rp=Xe({name:"ConfigProvider",alias:["App"],props:Dp,setup(e){const t=tn(cr,null),n=N(()=>{const{theme:T}=e;if(T===null)return;const j=t==null?void 0:t.mergedThemeRef.value;return T===void 0?j:j===void 0?T:Object.assign({},j,T)}),o=N(()=>{const{themeOverrides:T}=e;if(T!==null){if(T===void 0)return t==null?void 0:t.mergedThemeOverridesRef.value;{const j=t==null?void 0:t.mergedThemeOverridesRef.value;return j===void 0?T:kp({},j,T)}}}),i=dr(()=>{const{namespace:T}=e;return T===void 0?t==null?void 0:t.mergedNamespaceRef.value:T}),s=dr(()=>{const{bordered:T}=e;return T===void 0?t==null?void 0:t.mergedBorderedRef.value:T}),u=N(()=>{const{icons:T}=e;return T===void 0?t==null?void 0:t.mergedIconsRef.value:T}),r=N(()=>{const{componentOptions:T}=e;return T!==void 0?T:t==null?void 0:t.mergedComponentPropsRef.value}),c=N(()=>{const{clsPrefix:T}=e;return T!==void 0?T:t?t.mergedClsPrefixRef.value:fr}),a=N(()=>{var T;const{rtl:j}=e;if(j===void 0)return t==null?void 0:t.mergedRtlRef.value;const k={};for(const L of j)k[L.name]=To(L),(T=L.peers)===null||T===void 0||T.forEach(G=>{G.name in k||(k[G.name]=To(G))});return k}),d=N(()=>e.breakpoints||(t==null?void 0:t.mergedBreakpointsRef.value)),m=e.inlineThemeDisabled||(t==null?void 0:t.inlineThemeDisabled),v=e.preflightStyleDisabled||(t==null?void 0:t.preflightStyleDisabled),E=e.styleMountTarget||(t==null?void 0:t.styleMountTarget),R=N(()=>{const{value:T}=n,{value:j}=o,k=j&&Object.keys(j).length!==0,L=T==null?void 0:T.name;return L?k?`${L}-${ur(JSON.stringify(o.value))}`:L:k?ur(JSON.stringify(o.value)):""});return xs(cr,{mergedThemeHashRef:R,mergedBreakpointsRef:d,mergedRtlRef:a,mergedIconsRef:u,mergedComponentPropsRef:r,mergedBorderedRef:s,mergedNamespaceRef:i,mergedClsPrefixRef:c,mergedLocaleRef:N(()=>{const{locale:T}=e;if(T!==null)return T===void 0?t==null?void 0:t.mergedLocaleRef.value:T}),mergedDateLocaleRef:N(()=>{const{dateLocale:T}=e;if(T!==null)return T===void 0?t==null?void 0:t.mergedDateLocaleRef.value:T}),mergedHljsRef:N(()=>{const{hljs:T}=e;return T===void 0?t==null?void 0:t.mergedHljsRef.value:T}),mergedKatexRef:N(()=>{const{katex:T}=e;return T===void 0?t==null?void 0:t.mergedKatexRef.value:T}),mergedThemeRef:n,mergedThemeOverridesRef:o,inlineThemeDisabled:m||!1,preflightStyleDisabled:v||!1,styleMountTarget:E}),{mergedClsPrefix:c,mergedBordered:s,mergedNamespace:i,mergedTheme:n,mergedThemeOverrides:o}},render(){var e,t,n,o;return this.abstract?(o=(n=this.$slots).default)===null||o===void 0?void 0:o.call(n):pu(this.as||this.tag,{class:`${this.mergedClsPrefix||fr}-config-provider`},(t=(e=this.$slots).default)===null||t===void 0?void 0:t.call(e))}}),jp={class:"countdown-widget-container"},Up={class:"countdown-settings"},Bp={class:"settings-section"},Lp={class:"form-group"},Vp={class:"form-group"},Np={class:"form-group"},Hp={class:"form-group"},zp={class:"form-group"},Wp={class:"settings-section"},Kp={class:"checkbox-group"},Gp={class:"settings-section"},qp={class:"form-group"},Yp={key:0,class:"form-group"},Jp={key:1,class:"form-group"},Xp={class:"settings-section"},Qp={class:"form-group"},Zp={class:"form-group"},em={class:"form-group"},tm={class:"form-group"},nm={class:"form-group"},om={class:"form-group"},im={class:"preview-section"},rm=["innerHTML"],sm=Xe({__name:"CountdownWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"countdown-1",type:"countdown",name:"Countdown Timer",endDate:new Date(Date.now()+6048e5).toISOString().split("T")[0],endTime:"23:59",timezone:"UTC",title:"Limited Time Offer!",subtitle:"Hurry! This deal expires soon",expiredMessage:"This offer has expired",showDays:!0,showHours:!0,showMinutes:!0,showSeconds:!0,onExpire:"message",styles:{backgroundColor:"#1f2937",textColor:"#ffffff",numberColor:"#f59e0b",labelColor:"#d1d5db",borderColor:"#374151",borderRadius:"8px",fontSize:"16px",fontFamily:"Inter",padding:"20px",margin:"10px"}}),o=N(()=>(`${n.value.endDate}${n.value.endTime}`,`
    <style>
      @import url('https://fonts.googleapis.com/css2?family=${n.value.styles.fontFamily}:wght@400;600;700&display=swap');
      
      .countdown-container {
        background-color: ${n.value.styles.backgroundColor};
        color: ${n.value.styles.textColor};
        padding: ${n.value.styles.padding};
        margin: ${n.value.styles.margin};
        border-radius: ${n.value.styles.borderRadius};
        text-align: center;
        font-family: '${n.value.styles.fontFamily}', sans-serif;
        max-width: 600px;
        margin: 0 auto;
      }
      
      .countdown-title {
        font-size: calc(${n.value.styles.fontSize} * 1.5);
        font-weight: 700;
        margin-bottom: 8px;
      }
      
      .countdown-subtitle {
        font-size: ${n.value.styles.fontSize};
        margin-bottom: 20px;
        opacity: 0.9;
      }
      
      .countdown-timer {
        display: flex;
        justify-content: center;
        gap: 20px;
        flex-wrap: wrap;
      }
      
      .countdown-unit {
        text-align: center;
        min-width: 60px;
      }
      
      .countdown-number {
        display: block;
        font-size: calc(${n.value.styles.fontSize} * 2);
        font-weight: 700;
        color: ${n.value.styles.numberColor};
        line-height: 1;
      }
      
      .countdown-label {
        display: block;
        font-size: calc(${n.value.styles.fontSize} * 0.8);
        color: ${n.value.styles.labelColor};
        margin-top: 4px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      }
      
      .countdown-expired {
        font-size: calc(${n.value.styles.fontSize} * 1.2);
        font-weight: 600;
        padding: 20px;
      }
      
      @media (max-width: 768px) {
        .countdown-timer {
          gap: 15px;
        }
        .countdown-unit {
          min-width: 50px;
        }
        .countdown-number {
          font-size: calc(${n.value.styles.fontSize} * 1.5);
        }
      }
      
      .--mobile .countdown-timer {
        gap: 10px;
      }
      
      .--mobile .countdown-unit {
        min-width: 45px;
      }
    </style>
    
    <div class="countdown-container">
      <div class="countdown-title">${n.value.title}</div>
      <div class="countdown-subtitle">${n.value.subtitle}</div>
      <div class="countdown-timer" id="countdown-timer">
        ${n.value.showDays?'<div class="countdown-unit"><span class="countdown-number" id="days">00</span><span class="countdown-label">Days</span></div>':""}
        ${n.value.showHours?'<div class="countdown-unit"><span class="countdown-number" id="hours">00</span><span class="countdown-label">Hours</span></div>':""}
        ${n.value.showMinutes?'<div class="countdown-unit"><span class="countdown-number" id="minutes">00</span><span class="countdown-label">Minutes</span></div>':""}
        ${n.value.showSeconds?'<div class="countdown-unit"><span class="countdown-number" id="seconds">00</span><span class="countdown-label">Seconds</span></div>':""}
      </div>
      <div class="countdown-expired" id="countdown-expired" style="display: none;">${n.value.expiredMessage}</div>
    </div>
  `)),i=N(()=>`
    (function() {
      const endDate = new Date('${`${n.value.endDate}T${n.value.endTime}`}').getTime();
      const timer = document.getElementById('countdown-timer');
      const expiredDiv = document.getElementById('countdown-expired');
      
      function updateCountdown() {
        const now = new Date().getTime();
        const distance = endDate - now;
        
        if (distance < 0) {
          // Timer expired
          ${n.value.onExpire==="hide"?'timer.parentElement.style.display = "none";':""}
          ${n.value.onExpire==="message"?'timer.style.display = "none"; expiredDiv.style.display = "block";':""}
          ${n.value.onExpire==="redirect"&&n.value.redirectUrl?`window.location.href = "${n.value.redirectUrl}";`:""}
          ${n.value.onExpire==="popup"?'var event = new Event("customWidgetOpenPopup"); window.dispatchEvent(event);':""}
          return;
        }
        
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);
        
        ${n.value.showDays?'const daysEl = document.getElementById("days"); if (daysEl) daysEl.textContent = days.toString().padStart(2, "0");':""}
        ${n.value.showHours?'const hoursEl = document.getElementById("hours"); if (hoursEl) hoursEl.textContent = hours.toString().padStart(2, "0");':""}
        ${n.value.showMinutes?'const minutesEl = document.getElementById("minutes"); if (minutesEl) minutesEl.textContent = minutes.toString().padStart(2, "0");':""}
        ${n.value.showSeconds?'const secondsEl = document.getElementById("seconds"); if (secondsEl) secondsEl.textContent = seconds.toString().padStart(2, "0");':""}
      }
      
      updateCountdown();
      const interval = setInterval(updateCountdown, 1000);
      
      // Clean up interval when widget is removed
      window.addEventListener('beforeunload', () => clearInterval(interval));
    })();
  `),s=t;return Le([n],()=>{s("codeChange",{html:o.value,js:i.value,elementStore:n.value})},{deep:!0,immediate:!0}),(u,r)=>(B(),W("div",jp,[l("div",Up,[r[43]||(r[43]=l("h2",null,"Countdown Timer Settings",-1)),l("div",Bp,[r[24]||(r[24]=l("h3",null,"Timer Configuration",-1)),l("div",Lp,[r[18]||(r[18]=l("label",null,"Title:",-1)),y(l("input",{"onUpdate:modelValue":r[0]||(r[0]=c=>n.value.title=c),type:"text",placeholder:"Limited Time Offer!"},null,512),[[_,n.value.title]])]),l("div",Vp,[r[19]||(r[19]=l("label",null,"Subtitle:",-1)),y(l("input",{"onUpdate:modelValue":r[1]||(r[1]=c=>n.value.subtitle=c),type:"text",placeholder:"Hurry! This deal expires soon"},null,512),[[_,n.value.subtitle]])]),l("div",Np,[r[20]||(r[20]=l("label",null,"End Date:",-1)),y(l("input",{"onUpdate:modelValue":r[2]||(r[2]=c=>n.value.endDate=c),type:"date"},null,512),[[_,n.value.endDate]])]),l("div",Hp,[r[21]||(r[21]=l("label",null,"End Time:",-1)),y(l("input",{"onUpdate:modelValue":r[3]||(r[3]=c=>n.value.endTime=c),type:"time"},null,512),[[_,n.value.endTime]])]),l("div",zp,[r[23]||(r[23]=l("label",null,"Timezone:",-1)),y(l("select",{"onUpdate:modelValue":r[4]||(r[4]=c=>n.value.timezone=c)},r[22]||(r[22]=[ge('<option value="UTC" data-v-c850d610>UTC</option><option value="America/New_York" data-v-c850d610>Eastern Time</option><option value="America/Chicago" data-v-c850d610>Central Time</option><option value="America/Denver" data-v-c850d610>Mountain Time</option><option value="America/Los_Angeles" data-v-c850d610>Pacific Time</option>',5)]),512),[[re,n.value.timezone]])])]),l("div",Wp,[r[29]||(r[29]=l("h3",null,"Display Options",-1)),l("div",Kp,[l("label",null,[y(l("input",{"onUpdate:modelValue":r[5]||(r[5]=c=>n.value.showDays=c),type:"checkbox"},null,512),[[ie,n.value.showDays]]),r[25]||(r[25]=ne(" Show Days"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":r[6]||(r[6]=c=>n.value.showHours=c),type:"checkbox"},null,512),[[ie,n.value.showHours]]),r[26]||(r[26]=ne(" Show Hours"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":r[7]||(r[7]=c=>n.value.showMinutes=c),type:"checkbox"},null,512),[[ie,n.value.showMinutes]]),r[27]||(r[27]=ne(" Show Minutes"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":r[8]||(r[8]=c=>n.value.showSeconds=c),type:"checkbox"},null,512),[[ie,n.value.showSeconds]]),r[28]||(r[28]=ne(" Show Seconds"))])])]),l("div",Gp,[r[34]||(r[34]=l("h3",null,"When Timer Expires",-1)),l("div",qp,[r[31]||(r[31]=l("label",null,"Action:",-1)),y(l("select",{"onUpdate:modelValue":r[9]||(r[9]=c=>n.value.onExpire=c)},r[30]||(r[30]=[l("option",{value:"message"},"Show Message",-1),l("option",{value:"hide"},"Hide Widget",-1),l("option",{value:"redirect"},"Redirect to URL",-1),l("option",{value:"popup"},"Open Popup",-1)]),512),[[re,n.value.onExpire]])]),n.value.onExpire==="message"?(B(),W("div",Yp,[r[32]||(r[32]=l("label",null,"Expired Message:",-1)),y(l("input",{"onUpdate:modelValue":r[10]||(r[10]=c=>n.value.expiredMessage=c),type:"text",placeholder:"This offer has expired"},null,512),[[_,n.value.expiredMessage]])])):Se("",!0),n.value.onExpire==="redirect"?(B(),W("div",Jp,[r[33]||(r[33]=l("label",null,"Redirect URL:",-1)),y(l("input",{"onUpdate:modelValue":r[11]||(r[11]=c=>n.value.redirectUrl=c),type:"url",placeholder:"https://example.com"},null,512),[[_,n.value.redirectUrl]])])):Se("",!0)]),l("div",Xp,[r[42]||(r[42]=l("h3",null,"Styling",-1)),l("div",Qp,[r[35]||(r[35]=l("label",null,"Background Color:",-1)),y(l("input",{"onUpdate:modelValue":r[12]||(r[12]=c=>n.value.styles.backgroundColor=c),type:"color"},null,512),[[_,n.value.styles.backgroundColor]])]),l("div",Zp,[r[36]||(r[36]=l("label",null,"Text Color:",-1)),y(l("input",{"onUpdate:modelValue":r[13]||(r[13]=c=>n.value.styles.textColor=c),type:"color"},null,512),[[_,n.value.styles.textColor]])]),l("div",em,[r[37]||(r[37]=l("label",null,"Number Color:",-1)),y(l("input",{"onUpdate:modelValue":r[14]||(r[14]=c=>n.value.styles.numberColor=c),type:"color"},null,512),[[_,n.value.styles.numberColor]])]),l("div",tm,[r[38]||(r[38]=l("label",null,"Label Color:",-1)),y(l("input",{"onUpdate:modelValue":r[15]||(r[15]=c=>n.value.styles.labelColor=c),type:"color"},null,512),[[_,n.value.styles.labelColor]])]),l("div",nm,[r[39]||(r[39]=l("label",null,"Font Size:",-1)),y(l("input",{"onUpdate:modelValue":r[16]||(r[16]=c=>n.value.styles.fontSize=c),type:"text",placeholder:"16px"},null,512),[[_,n.value.styles.fontSize]])]),l("div",om,[r[41]||(r[41]=l("label",null,"Font Family:",-1)),y(l("select",{"onUpdate:modelValue":r[17]||(r[17]=c=>n.value.styles.fontFamily=c)},r[40]||(r[40]=[ge('<option value="Arial" data-v-c850d610>Arial</option><option value="Helvetica" data-v-c850d610>Helvetica</option><option value="Inter" data-v-c850d610>Inter</option><option value="Roboto" data-v-c850d610>Roboto</option><option value="Open Sans" data-v-c850d610>Open Sans</option>',5)]),512),[[re,n.value.styles.fontFamily]])])])]),l("div",im,[r[44]||(r[44]=l("h3",null,"Preview",-1)),l("div",{innerHTML:o.value,class:"widget-preview"},null,8,rm)])]))}}),At=(e,t)=>{const n=e.__vccOpts||e;for(const[o,i]of t)n[o]=i;return n},lm=At(sm,[["__scopeId","data-v-c850d610"]]),am={class:"social-proof-widget-container"},um={class:"social-proof-settings"},dm={class:"settings-section"},cm={class:"notifications-list"},fm={class:"notification-header"},pm=["onClick"],mm={class:"form-group"},gm=["onUpdate:modelValue"],vm={class:"form-group"},hm=["onUpdate:modelValue"],bm={class:"form-group"},ym=["onUpdate:modelValue"],xm={class:"form-group"},wm=["onUpdate:modelValue"],Tm={class:"form-group"},Cm=["onUpdate:modelValue"],$m={class:"settings-section"},Sm={class:"form-group"},Em={class:"form-group"},Am={class:"form-group"},_m={class:"form-group"},Om={class:"checkbox-group"},Pm={class:"settings-section"},Im={class:"form-group"},Mm={class:"form-group"},Fm={class:"form-group"},km={class:"form-group"},Dm={class:"form-group"},Rm={class:"form-group"},jm={class:"preview-section"},Um={class:"preview-container"},Bm=["innerHTML"],Lm=Xe({__name:"SocialProofWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"social-proof-1",type:"social-proof",name:"Social Proof Widget",notifications:[{id:"1",customerName:"Sarah M.",action:"purchased",product:"Premium Course",location:"New York, NY",timeAgo:"2 minutes ago"},{id:"2",customerName:"Mike R.",action:"signed up for",product:"Free Webinar",location:"Los Angeles, CA",timeAgo:"5 minutes ago"},{id:"3",customerName:"Jennifer L.",action:"downloaded",product:"Free Guide",location:"Chicago, IL",timeAgo:"8 minutes ago"}],displayDuration:4,intervalBetween:6,position:"bottom-left",showAvatar:!1,showLocation:!0,maxNotifications:5,styles:{backgroundColor:"#ffffff",textColor:"#374151",borderColor:"#e5e7eb",borderRadius:"8px",fontSize:"14px",fontFamily:"Inter",shadow:"0 4px 6px -1px rgba(0, 0, 0, 0.1)"}}),o=()=>{const c=(n.value.notifications.length+1).toString();n.value.notifications.push({id:c,customerName:"New Customer",action:"purchased",product:"Product Name",location:"City, State",timeAgo:"1 minute ago"})},i=c=>{n.value.notifications.splice(c,1)},s=N(()=>{const c={"bottom-left":"bottom: 20px; left: 20px;","bottom-right":"bottom: 20px; right: 20px;","top-left":"top: 20px; left: 20px;","top-right":"top: 20px; right: 20px;"};return`
    <style>
      @import url('https://fonts.googleapis.com/css2?family=${n.value.styles.fontFamily}:wght@400;500;600&display=swap');
      
      .social-proof-container {
        position: fixed;
        ${c[n.value.position]}
        z-index: 9999;
        max-width: 320px;
        font-family: '${n.value.styles.fontFamily}', sans-serif;
      }
      
      .social-proof-notification {
        background-color: ${n.value.styles.backgroundColor};
        color: ${n.value.styles.textColor};
        border: 1px solid ${n.value.styles.borderColor};
        border-radius: ${n.value.styles.borderRadius};
        padding: 12px 16px;
        margin-bottom: 8px;
        box-shadow: ${n.value.styles.shadow};
        font-size: ${n.value.styles.fontSize};
        line-height: 1.4;
        opacity: 0;
        transform: translateX(-100%);
        transition: all 0.3s ease-in-out;
        cursor: pointer;
      }
      
      .social-proof-notification.show {
        opacity: 1;
        transform: translateX(0);
      }
      
      .social-proof-notification.hide {
        opacity: 0;
        transform: translateX(-100%);
      }
      
      .notification-content {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      
      .notification-avatar {
        width: 32px;
        height: 32px;
        border-radius: 50%;
        background: linear-gradient(45deg, #3b82f6, #8b5cf6);
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-weight: 600;
        font-size: 12px;
        flex-shrink: 0;
      }
      
      .notification-text {
        flex: 1;
      }
      
      .notification-main {
        font-weight: 500;
        margin-bottom: 2px;
      }
      
      .notification-meta {
        font-size: calc(${n.value.styles.fontSize} * 0.85);
        opacity: 0.7;
      }
      
      .notification-close {
        background: none;
        border: none;
        color: ${n.value.styles.textColor};
        opacity: 0.5;
        cursor: pointer;
        padding: 0;
        margin-left: 8px;
        font-size: 16px;
        line-height: 1;
      }
      
      .notification-close:hover {
        opacity: 1;
      }
      
      @media (max-width: 768px) {
        .social-proof-container {
          max-width: 280px;
          left: 10px !important;
          right: 10px !important;
        }
        
        .social-proof-notification {
          padding: 10px 12px;
          font-size: calc(${n.value.styles.fontSize} * 0.9);
        }
      }
      
      .--mobile .social-proof-container {
        max-width: 260px;
      }
    </style>
    
    <div class="social-proof-container" id="social-proof-container">
      <!-- Notifications will be dynamically inserted here -->
    </div>
  `}),u=N(()=>{const c=n.value.notifications.slice(0,n.value.maxNotifications);return`
    (function() {
      const notifications = ${JSON.stringify(c)};
      const container = document.getElementById('social-proof-container');
      const displayDuration = ${n.value.displayDuration*1e3};
      const intervalBetween = ${n.value.intervalBetween*1e3};
      const showLocation = ${n.value.showLocation};
      
      let currentIndex = 0;
      let isShowing = false;
      
      function createNotificationElement(notification) {
        const div = document.createElement('div');
        div.className = 'social-proof-notification';
        
        const initials = notification.customerName.split(' ').map(n => n[0]).join('').toUpperCase();
        
        div.innerHTML = \`
          <div class="notification-content">
            <div class="notification-avatar">\${initials}</div>
            <div class="notification-text">
              <div class="notification-main">
                <strong>\${notification.customerName}</strong> \${notification.action} <strong>\${notification.product}</strong>
              </div>
              <div class="notification-meta">
                \${showLocation ? notification.location + ' • ' : ''}\${notification.timeAgo}
              </div>
            </div>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
          </div>
        \`;
        
        return div;
      }
      
      function showNotification() {
        if (isShowing || notifications.length === 0) return;
        
        isShowing = true;
        const notification = notifications[currentIndex];
        const element = createNotificationElement(notification);
        
        container.appendChild(element);
        
        // Trigger show animation
        setTimeout(() => {
          element.classList.add('show');
        }, 100);
        
        // Hide after display duration
        setTimeout(() => {
          element.classList.add('hide');
          setTimeout(() => {
            if (element.parentNode) {
              element.remove();
            }
            isShowing = false;
          }, 300);
        }, displayDuration);
        
        currentIndex = (currentIndex + 1) % notifications.length;
      }
      
      // Start showing notifications
      if (notifications.length > 0) {
        showNotification();
        setInterval(showNotification, intervalBetween);
      }
    })();
  `}),r=t;return Le([n],()=>{r("codeChange",{html:s.value,js:u.value,elementStore:n.value})},{deep:!0,immediate:!0}),(c,a)=>(B(),W("div",am,[l("div",um,[a[33]||(a[33]=l("h2",null,"Social Proof Widget Settings",-1)),l("div",dm,[a[17]||(a[17]=l("h3",null,"Customer Notifications",-1)),l("div",cm,[(B(!0),W(_e,null,Eo(n.value.notifications,(d,m)=>(B(),W("div",{key:d.id,class:"notification-item"},[l("div",fm,[l("h4",null,"Notification "+se(m+1),1),l("button",{onClick:v=>i(m),class:"remove-btn"},"Remove",8,pm)]),l("div",mm,[a[11]||(a[11]=l("label",null,"Customer Name:",-1)),y(l("input",{"onUpdate:modelValue":v=>d.customerName=v,type:"text",placeholder:"John D."},null,8,gm),[[_,d.customerName]])]),l("div",vm,[a[13]||(a[13]=l("label",null,"Action:",-1)),y(l("select",{"onUpdate:modelValue":v=>d.action=v},a[12]||(a[12]=[ge('<option value="purchased" data-v-6e94fd90>purchased</option><option value="signed up for" data-v-6e94fd90>signed up for</option><option value="downloaded" data-v-6e94fd90>downloaded</option><option value="joined" data-v-6e94fd90>joined</option><option value="booked" data-v-6e94fd90>booked</option>',5)]),8,hm),[[re,d.action]])]),l("div",bm,[a[14]||(a[14]=l("label",null,"Product/Service:",-1)),y(l("input",{"onUpdate:modelValue":v=>d.product=v,type:"text",placeholder:"Premium Course"},null,8,ym),[[_,d.product]])]),l("div",xm,[a[15]||(a[15]=l("label",null,"Location:",-1)),y(l("input",{"onUpdate:modelValue":v=>d.location=v,type:"text",placeholder:"New York, NY"},null,8,wm),[[_,d.location]])]),l("div",Tm,[a[16]||(a[16]=l("label",null,"Time Ago:",-1)),y(l("input",{"onUpdate:modelValue":v=>d.timeAgo=v,type:"text",placeholder:"2 minutes ago"},null,8,Cm),[[_,d.timeAgo]])])]))),128))]),l("button",{onClick:o,class:"add-btn"},"Add Notification")]),l("div",$m,[a[24]||(a[24]=l("h3",null,"Display Settings",-1)),l("div",Sm,[a[19]||(a[19]=l("label",null,"Position:",-1)),y(l("select",{"onUpdate:modelValue":a[0]||(a[0]=d=>n.value.position=d)},a[18]||(a[18]=[l("option",{value:"bottom-left"},"Bottom Left",-1),l("option",{value:"bottom-right"},"Bottom Right",-1),l("option",{value:"top-left"},"Top Left",-1),l("option",{value:"top-right"},"Top Right",-1)]),512),[[re,n.value.position]])]),l("div",Em,[a[20]||(a[20]=l("label",null,"Display Duration (seconds):",-1)),y(l("input",{"onUpdate:modelValue":a[1]||(a[1]=d=>n.value.displayDuration=d),type:"number",min:"1",max:"10"},null,512),[[_,n.value.displayDuration,void 0,{number:!0}]])]),l("div",Am,[a[21]||(a[21]=l("label",null,"Interval Between Notifications (seconds):",-1)),y(l("input",{"onUpdate:modelValue":a[2]||(a[2]=d=>n.value.intervalBetween=d),type:"number",min:"1",max:"30"},null,512),[[_,n.value.intervalBetween,void 0,{number:!0}]])]),l("div",_m,[a[22]||(a[22]=l("label",null,"Max Notifications to Show:",-1)),y(l("input",{"onUpdate:modelValue":a[3]||(a[3]=d=>n.value.maxNotifications=d),type:"number",min:"1",max:"10"},null,512),[[_,n.value.maxNotifications,void 0,{number:!0}]])]),l("div",Om,[l("label",null,[y(l("input",{"onUpdate:modelValue":a[4]||(a[4]=d=>n.value.showLocation=d),type:"checkbox"},null,512),[[ie,n.value.showLocation]]),a[23]||(a[23]=ne(" Show Location"))])])]),l("div",Pm,[a[32]||(a[32]=l("h3",null,"Styling",-1)),l("div",Im,[a[25]||(a[25]=l("label",null,"Background Color:",-1)),y(l("input",{"onUpdate:modelValue":a[5]||(a[5]=d=>n.value.styles.backgroundColor=d),type:"color"},null,512),[[_,n.value.styles.backgroundColor]])]),l("div",Mm,[a[26]||(a[26]=l("label",null,"Text Color:",-1)),y(l("input",{"onUpdate:modelValue":a[6]||(a[6]=d=>n.value.styles.textColor=d),type:"color"},null,512),[[_,n.value.styles.textColor]])]),l("div",Fm,[a[27]||(a[27]=l("label",null,"Border Color:",-1)),y(l("input",{"onUpdate:modelValue":a[7]||(a[7]=d=>n.value.styles.borderColor=d),type:"color"},null,512),[[_,n.value.styles.borderColor]])]),l("div",km,[a[28]||(a[28]=l("label",null,"Border Radius:",-1)),y(l("input",{"onUpdate:modelValue":a[8]||(a[8]=d=>n.value.styles.borderRadius=d),type:"text",placeholder:"8px"},null,512),[[_,n.value.styles.borderRadius]])]),l("div",Dm,[a[29]||(a[29]=l("label",null,"Font Size:",-1)),y(l("input",{"onUpdate:modelValue":a[9]||(a[9]=d=>n.value.styles.fontSize=d),type:"text",placeholder:"14px"},null,512),[[_,n.value.styles.fontSize]])]),l("div",Rm,[a[31]||(a[31]=l("label",null,"Font Family:",-1)),y(l("select",{"onUpdate:modelValue":a[10]||(a[10]=d=>n.value.styles.fontFamily=d)},a[30]||(a[30]=[ge('<option value="Arial" data-v-6e94fd90>Arial</option><option value="Helvetica" data-v-6e94fd90>Helvetica</option><option value="Inter" data-v-6e94fd90>Inter</option><option value="Roboto" data-v-6e94fd90>Roboto</option><option value="Open Sans" data-v-6e94fd90>Open Sans</option>',5)]),512),[[re,n.value.styles.fontFamily]])])])]),l("div",jm,[a[35]||(a[35]=l("h3",null,"Preview",-1)),l("div",Um,[l("div",{innerHTML:s.value,class:"widget-preview"},null,8,Bm),a[34]||(a[34]=l("p",{class:"preview-note"},"Note: In the actual funnel, notifications will appear one at a time in the selected position.",-1))])])]))}}),Vm=At(Lm,[["__scopeId","data-v-6e94fd90"]]),Nm={class:"cta-banner-widget-container"},Hm={class:"cta-banner-settings"},zm={class:"settings-section"},Wm={class:"form-group"},Km={class:"form-group"},Gm={class:"form-group"},qm={class:"form-group"},Ym={key:0,class:"form-group"},Jm={class:"settings-section"},Xm={class:"form-group"},Qm={class:"checkbox-group"},Zm={class:"settings-section"},eg={class:"form-group"},tg={class:"form-group"},ng={class:"form-group"},og={class:"form-group"},ig={class:"form-group"},rg={class:"form-group"},sg={class:"form-group"},lg={class:"form-group"},ag={class:"form-group"},ug={class:"preview-section"},dg={class:"preview-container"},cg=["innerHTML"],fg=Xe({__name:"CTABannerWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"cta-banner-1",type:"cta-banner",name:"CTA Banner Widget",headline:"Don't Miss Out! Limited Time Offer",subheadline:"Get 50% off our premium course - expires in 24 hours!",buttonText:"Claim Your Discount",buttonAction:"https://example.com/offer",buttonType:"link",showCloseButton:!0,position:"top",styles:{backgroundColor:"#1f2937",textColor:"#ffffff",buttonBgColor:"#f59e0b",buttonTextColor:"#000000",borderColor:"#374151",borderRadius:"0px",fontSize:"16px",fontFamily:"Inter",padding:"16px"}}),o=N(()=>{const u={top:"position: fixed; top: 0; left: 0; right: 0; z-index: 9999;",bottom:"position: fixed; bottom: 0; left: 0; right: 0; z-index: 9999;",floating:"position: fixed; bottom: 20px; right: 20px; z-index: 9999; max-width: 400px;"};return`
    <style>
      @import url('https://fonts.googleapis.com/css2?family=${n.value.styles.fontFamily}:wght@400;500;600;700&display=swap');
      
      .cta-banner-container {
        ${u[n.value.position]}
        background-color: ${n.value.styles.backgroundColor};
        color: ${n.value.styles.textColor};
        padding: ${n.value.styles.padding};
        border-radius: ${n.value.styles.borderRadius};
        font-family: '${n.value.styles.fontFamily}', sans-serif;
        font-size: ${n.value.styles.fontSize};
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        ${n.value.position==="floating"?"border: 1px solid "+n.value.styles.borderColor+";":""}
      }
      
      .cta-banner-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        max-width: 1200px;
        margin: 0 auto;
        flex-wrap: wrap;
      }
      
      .cta-banner-text {
        flex: 1;
        min-width: 300px;
      }
      
      .cta-banner-headline {
        font-size: calc(${n.value.styles.fontSize} * 1.25);
        font-weight: 700;
        margin: 0 0 4px 0;
        line-height: 1.2;
      }
      
      .cta-banner-subheadline {
        font-size: ${n.value.styles.fontSize};
        margin: 0;
        opacity: 0.9;
        line-height: 1.4;
      }
      
      .cta-banner-actions {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-shrink: 0;
      }
      
      .cta-banner-button {
        background-color: ${n.value.styles.buttonBgColor};
        color: ${n.value.styles.buttonTextColor};
        border: none;
        padding: 12px 24px;
        border-radius: calc(${n.value.styles.borderRadius} / 2);
        font-size: ${n.value.styles.fontSize};
        font-weight: 600;
        font-family: '${n.value.styles.fontFamily}', sans-serif;
        cursor: pointer;
        transition: all 0.2s ease;
        text-decoration: none;
        display: inline-block;
        text-align: center;
        white-space: nowrap;
      }
      
      .cta-banner-button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      }
      
      .cta-banner-close {
        background: none;
        border: none;
        color: ${n.value.styles.textColor};
        font-size: 20px;
        cursor: pointer;
        padding: 4px;
        opacity: 0.7;
        transition: opacity 0.2s ease;
        line-height: 1;
      }
      
      .cta-banner-close:hover {
        opacity: 1;
      }
      
      @media (max-width: 768px) {
        .cta-banner-content {
          flex-direction: column;
          text-align: center;
          gap: 16px;
        }
        
        .cta-banner-text {
          min-width: auto;
        }
        
        .cta-banner-headline {
          font-size: calc(${n.value.styles.fontSize} * 1.1);
        }
        
        .cta-banner-button {
          padding: 10px 20px;
          font-size: calc(${n.value.styles.fontSize} * 0.9);
        }
        
        .cta-banner-container {
          padding: calc(${n.value.styles.padding} * 0.75);
        }
      }
      
      .--mobile .cta-banner-content {
        flex-direction: column;
        gap: 12px;
      }
      
      .--mobile .cta-banner-button {
        width: 100%;
        max-width: 280px;
      }
    </style>
    
    <div class="cta-banner-container" id="cta-banner">
      <div class="cta-banner-content">
        <div class="cta-banner-text">
          <div class="cta-banner-headline">${n.value.headline}</div>
          <div class="cta-banner-subheadline">${n.value.subheadline}</div>
        </div>
        <div class="cta-banner-actions">
          <button class="cta-banner-button" id="cta-banner-button">${n.value.buttonText}</button>
          ${n.value.showCloseButton?'<button class="cta-banner-close" id="cta-banner-close">×</button>':""}
        </div>
      </div>
    </div>
  `}),i=N(()=>`
    (function() {
      const banner = document.getElementById('cta-banner');
      const button = document.getElementById('cta-banner-button');
      const closeButton = document.getElementById('cta-banner-close');
      
      // Button click handler
      if (button) {
        button.addEventListener('click', function() {
          ${n.value.buttonType==="link"&&n.value.buttonAction?`window.open('${n.value.buttonAction}', '_blank');`:n.value.buttonType==="popup"?'var event = new Event("customWidgetOpenPopup"); window.dispatchEvent(event);':n.value.buttonType==="next-step"?'var event = new Event("customWidgetGoToNextStep"); window.dispatchEvent(event);':""}
        });
      }
      
      // Close button handler
      if (closeButton) {
        closeButton.addEventListener('click', function() {
          banner.style.display = 'none';
          // Store in localStorage to remember user closed it
          localStorage.setItem('cta-banner-closed-${n.value.id}', 'true');
        });
      }
      
      // Check if user previously closed the banner
      if (localStorage.getItem('cta-banner-closed-${n.value.id}') === 'true') {
        banner.style.display = 'none';
      }
      
      // Add body padding to prevent content overlap for fixed positioned banners
      if (banner && (banner.style.position === 'fixed')) {
        const bannerHeight = banner.offsetHeight;
        const position = '${n.value.position}';
        
        if (position === 'top') {
          document.body.style.paddingTop = bannerHeight + 'px';
        } else if (position === 'bottom') {
          document.body.style.paddingBottom = bannerHeight + 'px';
        }
        
        // Remove padding when banner is closed
        if (closeButton) {
          closeButton.addEventListener('click', function() {
            if (position === 'top') {
              document.body.style.paddingTop = '0px';
            } else if (position === 'bottom') {
              document.body.style.paddingBottom = '0px';
            }
          });
        }
      }
    })();
  `),s=t;return Le([n],()=>{s("codeChange",{html:o.value,js:i.value,elementStore:n.value})},{deep:!0,immediate:!0}),(u,r)=>(B(),W("div",Nm,[l("div",Hm,[r[38]||(r[38]=l("h2",null,"CTA Banner Widget Settings",-1)),l("div",zm,[r[22]||(r[22]=l("h3",null,"Content",-1)),l("div",Wm,[r[16]||(r[16]=l("label",null,"Headline:",-1)),y(l("input",{"onUpdate:modelValue":r[0]||(r[0]=c=>n.value.headline=c),type:"text",placeholder:"Don't Miss Out! Limited Time Offer"},null,512),[[_,n.value.headline]])]),l("div",Km,[r[17]||(r[17]=l("label",null,"Subheadline:",-1)),y(l("input",{"onUpdate:modelValue":r[1]||(r[1]=c=>n.value.subheadline=c),type:"text",placeholder:"Get 50% off our premium course - expires in 24 hours!"},null,512),[[_,n.value.subheadline]])]),l("div",Gm,[r[18]||(r[18]=l("label",null,"Button Text:",-1)),y(l("input",{"onUpdate:modelValue":r[2]||(r[2]=c=>n.value.buttonText=c),type:"text",placeholder:"Claim Your Discount"},null,512),[[_,n.value.buttonText]])]),l("div",qm,[r[20]||(r[20]=l("label",null,"Button Action:",-1)),y(l("select",{"onUpdate:modelValue":r[3]||(r[3]=c=>n.value.buttonType=c)},r[19]||(r[19]=[l("option",{value:"link"},"Open Link",-1),l("option",{value:"popup"},"Open Popup",-1),l("option",{value:"next-step"},"Go to Next Step",-1)]),512),[[re,n.value.buttonType]])]),n.value.buttonType==="link"?(B(),W("div",Ym,[r[21]||(r[21]=l("label",null,"Button URL:",-1)),y(l("input",{"onUpdate:modelValue":r[4]||(r[4]=c=>n.value.buttonAction=c),type:"url",placeholder:"https://example.com/offer"},null,512),[[_,n.value.buttonAction]])])):Se("",!0)]),l("div",Jm,[r[26]||(r[26]=l("h3",null,"Position & Behavior",-1)),l("div",Xm,[r[24]||(r[24]=l("label",null,"Position:",-1)),y(l("select",{"onUpdate:modelValue":r[5]||(r[5]=c=>n.value.position=c)},r[23]||(r[23]=[l("option",{value:"top"},"Top of Page",-1),l("option",{value:"bottom"},"Bottom of Page",-1),l("option",{value:"floating"},"Floating",-1)]),512),[[re,n.value.position]])]),l("div",Qm,[l("label",null,[y(l("input",{"onUpdate:modelValue":r[6]||(r[6]=c=>n.value.showCloseButton=c),type:"checkbox"},null,512),[[ie,n.value.showCloseButton]]),r[25]||(r[25]=ne(" Show Close Button"))])])]),l("div",Zm,[r[37]||(r[37]=l("h3",null,"Styling",-1)),l("div",eg,[r[27]||(r[27]=l("label",null,"Background Color:",-1)),y(l("input",{"onUpdate:modelValue":r[7]||(r[7]=c=>n.value.styles.backgroundColor=c),type:"color"},null,512),[[_,n.value.styles.backgroundColor]])]),l("div",tg,[r[28]||(r[28]=l("label",null,"Text Color:",-1)),y(l("input",{"onUpdate:modelValue":r[8]||(r[8]=c=>n.value.styles.textColor=c),type:"color"},null,512),[[_,n.value.styles.textColor]])]),l("div",ng,[r[29]||(r[29]=l("label",null,"Button Background Color:",-1)),y(l("input",{"onUpdate:modelValue":r[9]||(r[9]=c=>n.value.styles.buttonBgColor=c),type:"color"},null,512),[[_,n.value.styles.buttonBgColor]])]),l("div",og,[r[30]||(r[30]=l("label",null,"Button Text Color:",-1)),y(l("input",{"onUpdate:modelValue":r[10]||(r[10]=c=>n.value.styles.buttonTextColor=c),type:"color"},null,512),[[_,n.value.styles.buttonTextColor]])]),l("div",ig,[r[31]||(r[31]=l("label",null,"Border Color:",-1)),y(l("input",{"onUpdate:modelValue":r[11]||(r[11]=c=>n.value.styles.borderColor=c),type:"color"},null,512),[[_,n.value.styles.borderColor]])]),l("div",rg,[r[32]||(r[32]=l("label",null,"Border Radius:",-1)),y(l("input",{"onUpdate:modelValue":r[12]||(r[12]=c=>n.value.styles.borderRadius=c),type:"text",placeholder:"8px"},null,512),[[_,n.value.styles.borderRadius]])]),l("div",sg,[r[33]||(r[33]=l("label",null,"Font Size:",-1)),y(l("input",{"onUpdate:modelValue":r[13]||(r[13]=c=>n.value.styles.fontSize=c),type:"text",placeholder:"16px"},null,512),[[_,n.value.styles.fontSize]])]),l("div",lg,[r[35]||(r[35]=l("label",null,"Font Family:",-1)),y(l("select",{"onUpdate:modelValue":r[14]||(r[14]=c=>n.value.styles.fontFamily=c)},r[34]||(r[34]=[ge('<option value="Arial" data-v-f272bd54>Arial</option><option value="Helvetica" data-v-f272bd54>Helvetica</option><option value="Inter" data-v-f272bd54>Inter</option><option value="Roboto" data-v-f272bd54>Roboto</option><option value="Open Sans" data-v-f272bd54>Open Sans</option>',5)]),512),[[re,n.value.styles.fontFamily]])]),l("div",ag,[r[36]||(r[36]=l("label",null,"Padding:",-1)),y(l("input",{"onUpdate:modelValue":r[15]||(r[15]=c=>n.value.styles.padding=c),type:"text",placeholder:"20px"},null,512),[[_,n.value.styles.padding]])])])]),l("div",ug,[r[40]||(r[40]=l("h3",null,"Preview",-1)),l("div",dg,[l("div",{innerHTML:o.value,class:"widget-preview"},null,8,cg),r[39]||(r[39]=l("p",{class:"preview-note"},"Note: The banner will appear in the selected position on the actual page.",-1))])])]))}}),pg=At(fg,[["__scopeId","data-v-f272bd54"]]),mg={class:"exit-intent-widget-container"},gg={class:"exit-intent-settings"},vg={class:"settings-section"},hg={class:"form-group"},bg={class:"form-group"},yg={class:"form-group"},xg={class:"checkbox-group"},wg={class:"settings-section"},Tg={class:"form-group"},Cg={key:0,class:"form-group"},$g={key:1,class:"form-group"},Sg={key:2,class:"form-group"},Eg={class:"settings-section"},Ag={class:"form-group"},_g={class:"form-group"},Og={class:"checkbox-group"},Pg={class:"preview-section"},Ig={class:"preview-container"},Mg={class:"preview-info"},Fg={class:"action-preview"},kg=Xe({__name:"ExitIntentWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"exit-intent-1",type:"exit-intent",name:"Exit Intent Widget",sensitivity:"medium",minTimeOnPage:30,scrollThreshold:25,onlyOnce:!0,mobileEnabled:!1,actionType:"popup",redirectUrl:"",customMessage:"Wait! Don't leave yet...",discountCode:"SAVE20",delay:500,cookieExpiry:7,debugMode:!1}),o=()=>{switch(n.value.actionType){case"popup":return"Open GoHighLevel Popup";case"redirect":return`Redirect to ${n.value.redirectUrl||"URL"}`;case"message":return`Show message: "${n.value.customMessage}"`;case"discount":return`Show discount code: ${n.value.discountCode}`;default:return"No action configured"}},i=()=>{alert("Exit intent would trigger here with action: "+o())},s=N(()=>`
    <style>
      .exit-intent-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        z-index: 99999;
        display: none;
        align-items: center;
        justify-content: center;
      }
      
      .exit-intent-modal {
        background: white;
        padding: 30px;
        border-radius: 12px;
        max-width: 400px;
        text-align: center;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        animation: exitIntentSlideIn 0.3s ease-out;
      }
      
      @keyframes exitIntentSlideIn {
        from {
          opacity: 0;
          transform: translateY(-50px) scale(0.9);
        }
        to {
          opacity: 1;
          transform: translateY(0) scale(1);
        }
      }
      
      .exit-intent-title {
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 15px;
        color: #1f2937;
      }
      
      .exit-intent-message {
        font-size: 16px;
        color: #6b7280;
        margin-bottom: 20px;
        line-height: 1.5;
      }
      
      .exit-intent-discount {
        background: #fef3c7;
        border: 2px dashed #f59e0b;
        padding: 15px;
        border-radius: 8px;
        margin: 20px 0;
      }
      
      .exit-intent-code {
        font-size: 24px;
        font-weight: 700;
        color: #92400e;
        letter-spacing: 2px;
      }
      
      .exit-intent-close {
        position: absolute;
        top: 15px;
        right: 15px;
        background: none;
        border: none;
        font-size: 24px;
        cursor: pointer;
        color: #9ca3af;
      }
      
      .exit-intent-close:hover {
        color: #374151;
      }
    </style>
    
    <div class="exit-intent-overlay" id="exit-intent-overlay">
      <div class="exit-intent-modal">
        <button class="exit-intent-close" onclick="document.getElementById('exit-intent-overlay').style.display='none'">×</button>
        <div class="exit-intent-title">Wait! Don't Leave Yet!</div>
        <div class="exit-intent-message">
          ${n.value.actionType==="message"?n.value.customMessage:n.value.actionType==="discount"?"Get an exclusive discount before you go!":"We have something special for you!"}
        </div>
        ${n.value.actionType==="discount"?`
          <div class="exit-intent-discount">
            <div>Use code:</div>
            <div class="exit-intent-code">${n.value.discountCode}</div>
          </div>
        `:""}
      </div>
    </div>
  `),u=N(()=>`
    (function() {
      const config = {
        sensitivity: ${{low:50,medium:20,high:5}[n.value.sensitivity]},
        minTimeOnPage: ${n.value.minTimeOnPage*1e3},
        scrollThreshold: ${n.value.scrollThreshold},
        onlyOnce: ${n.value.onlyOnce},
        mobileEnabled: ${n.value.mobileEnabled},
        actionType: '${n.value.actionType}',
        redirectUrl: '${n.value.redirectUrl||""}',
        delay: ${n.value.delay},
        cookieExpiry: ${n.value.cookieExpiry},
        debugMode: ${n.value.debugMode}
      };
      
      let triggered = false;
      let startTime = Date.now();
      let maxScroll = 0;
      
      // Check if already triggered in this session
      const cookieName = 'exit-intent-triggered-${n.value.id}';
      if (config.onlyOnce && getCookie(cookieName)) {
        if (config.debugMode) console.log('Exit intent already triggered in this session');
        return;
      }
      
      // Check if mobile and not enabled
      if (!config.mobileEnabled && /Mobi|Android/i.test(navigator.userAgent)) {
        if (config.debugMode) console.log('Exit intent disabled on mobile');
        return;
      }
      
      function getCookie(name) {
        const value = "; " + document.cookie;
        const parts = value.split("; " + name + "=");
        if (parts.length === 2) return parts.pop().split(";").shift();
        return null;
      }
      
      function setCookie(name, value, days) {
        const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toUTCString();
        document.cookie = name + "=" + value + "; expires=" + expires + "; path=/";
      }
      
      function getScrollPercent() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        return scrollHeight > 0 ? (scrollTop / scrollHeight) * 100 : 0;
      }
      
      function triggerExitIntent() {
        if (triggered) return;
        
        const timeOnPage = Date.now() - startTime;
        const scrollPercent = Math.max(maxScroll, getScrollPercent());
        
        if (timeOnPage < config.minTimeOnPage) {
          if (config.debugMode) console.log('Not enough time on page:', timeOnPage / 1000, 'seconds');
          return;
        }
        
        if (scrollPercent < config.scrollThreshold) {
          if (config.debugMode) console.log('Not enough scroll:', scrollPercent + '%');
          return;
        }
        
        triggered = true;
        if (config.debugMode) console.log('Exit intent triggered!');
        
        setTimeout(() => {
          switch (config.actionType) {
            case 'popup':
              var event = new Event('customWidgetOpenPopup');
              window.dispatchEvent(event);
              break;
            case 'redirect':
              if (config.redirectUrl) {
                window.location.href = config.redirectUrl;
              }
              break;
            case 'message':
            case 'discount':
              const overlay = document.getElementById('exit-intent-overlay');
              if (overlay) {
                overlay.style.display = 'flex';
              }
              break;
          }
          
          if (config.onlyOnce) {
            setCookie(cookieName, 'true', config.cookieExpiry);
          }
        }, config.delay);
      }
      
      // Track scroll progress
      window.addEventListener('scroll', () => {
        maxScroll = Math.max(maxScroll, getScrollPercent());
      });
      
      // Mouse leave detection
      document.addEventListener('mouseleave', (e) => {
        if (e.clientY <= config.sensitivity) {
          triggerExitIntent();
        }
      });
      
      // Additional mobile detection (scroll up quickly)
      if (config.mobileEnabled) {
        let lastScrollY = window.scrollY;
        window.addEventListener('scroll', () => {
          const currentScrollY = window.scrollY;
          if (lastScrollY - currentScrollY > 100) { // Quick upward scroll
            triggerExitIntent();
          }
          lastScrollY = currentScrollY;
        });
      }
      
      if (config.debugMode) {
        console.log('Exit intent widget initialized with config:', config);
      }
    })();
  `),r=t;return Le([n],()=>{r("codeChange",{html:s.value,js:u.value,elementStore:n.value})},{deep:!0,immediate:!0}),(c,a)=>(B(),W("div",mg,[l("div",gg,[a[31]||(a[31]=l("h2",null,"Exit Intent Widget Settings",-1)),l("div",vg,[a[19]||(a[19]=l("h3",null,"Trigger Configuration",-1)),l("div",hg,[a[13]||(a[13]=l("label",null,"Sensitivity:",-1)),y(l("select",{"onUpdate:modelValue":a[0]||(a[0]=d=>n.value.sensitivity=d)},a[12]||(a[12]=[l("option",{value:"low"},"Low (cursor near top edge)",-1),l("option",{value:"medium"},"Medium (cursor at top edge)",-1),l("option",{value:"high"},"High (cursor leaves viewport)",-1)]),512),[[re,n.value.sensitivity]])]),l("div",bg,[a[14]||(a[14]=l("label",null,"Minimum Time on Page (seconds):",-1)),y(l("input",{"onUpdate:modelValue":a[1]||(a[1]=d=>n.value.minTimeOnPage=d),type:"number",min:"0",max:"300"},null,512),[[_,n.value.minTimeOnPage,void 0,{number:!0}]])]),l("div",yg,[a[15]||(a[15]=l("label",null,"Scroll Threshold (%):",-1)),y(l("input",{"onUpdate:modelValue":a[2]||(a[2]=d=>n.value.scrollThreshold=d),type:"number",min:"0",max:"100"},null,512),[[_,n.value.scrollThreshold,void 0,{number:!0}]]),a[16]||(a[16]=l("small",null,"Only trigger if user has scrolled this percentage",-1))]),l("div",xg,[l("label",null,[y(l("input",{"onUpdate:modelValue":a[3]||(a[3]=d=>n.value.onlyOnce=d),type:"checkbox"},null,512),[[ie,n.value.onlyOnce]]),a[17]||(a[17]=ne(" Only trigger once per session"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":a[4]||(a[4]=d=>n.value.mobileEnabled=d),type:"checkbox"},null,512),[[ie,n.value.mobileEnabled]]),a[18]||(a[18]=ne(" Enable on mobile devices"))])])]),l("div",wg,[a[25]||(a[25]=l("h3",null,"Exit Intent Action",-1)),l("div",Tg,[a[21]||(a[21]=l("label",null,"Action Type:",-1)),y(l("select",{"onUpdate:modelValue":a[5]||(a[5]=d=>n.value.actionType=d)},a[20]||(a[20]=[l("option",{value:"popup"},"Open GHL Popup",-1),l("option",{value:"redirect"},"Redirect to URL",-1),l("option",{value:"message"},"Show Custom Message",-1),l("option",{value:"discount"},"Show Discount Code",-1)]),512),[[re,n.value.actionType]])]),n.value.actionType==="redirect"?(B(),W("div",Cg,[a[22]||(a[22]=l("label",null,"Redirect URL:",-1)),y(l("input",{"onUpdate:modelValue":a[6]||(a[6]=d=>n.value.redirectUrl=d),type:"url",placeholder:"https://example.com/special-offer"},null,512),[[_,n.value.redirectUrl]])])):Se("",!0),n.value.actionType==="message"?(B(),W("div",$g,[a[23]||(a[23]=l("label",null,"Custom Message:",-1)),y(l("textarea",{"onUpdate:modelValue":a[7]||(a[7]=d=>n.value.customMessage=d),placeholder:"Wait! Don't leave yet...",rows:"3"},null,512),[[_,n.value.customMessage]])])):Se("",!0),n.value.actionType==="discount"?(B(),W("div",Sg,[a[24]||(a[24]=l("label",null,"Discount Code:",-1)),y(l("input",{"onUpdate:modelValue":a[8]||(a[8]=d=>n.value.discountCode=d),type:"text",placeholder:"SAVE20"},null,512),[[_,n.value.discountCode]])])):Se("",!0)]),l("div",Eg,[a[30]||(a[30]=l("h3",null,"Advanced Options",-1)),l("div",Ag,[a[26]||(a[26]=l("label",null,"Delay Before Trigger (ms):",-1)),y(l("input",{"onUpdate:modelValue":a[9]||(a[9]=d=>n.value.delay=d),type:"number",min:"0",max:"5000"},null,512),[[_,n.value.delay,void 0,{number:!0}]])]),l("div",_g,[a[27]||(a[27]=l("label",null,"Cookie Expiry (days):",-1)),y(l("input",{"onUpdate:modelValue":a[10]||(a[10]=d=>n.value.cookieExpiry=d),type:"number",min:"1",max:"365"},null,512),[[_,n.value.cookieExpiry,void 0,{number:!0}]]),a[28]||(a[28]=l("small",null,"How long to remember if user already saw this",-1))]),l("div",Og,[l("label",null,[y(l("input",{"onUpdate:modelValue":a[11]||(a[11]=d=>n.value.debugMode=d),type:"checkbox"},null,512),[[ie,n.value.debugMode]]),a[29]||(a[29]=ne(" Debug Mode (console logs)"))])])])]),l("div",Pg,[a[36]||(a[36]=l("h3",null,"Preview",-1)),l("div",Ig,[l("div",Mg,[a[34]||(a[34]=l("h4",null,"Exit Intent Detection Active",-1)),a[35]||(a[35]=l("p",null,"This widget runs invisibly in the background and triggers when:",-1)),l("ul",null,[a[32]||(a[32]=l("li",null,"User moves cursor toward browser close/back button",-1)),l("li",null,"User has been on page for "+se(n.value.minTimeOnPage)+"+ seconds",1),l("li",null,"User has scrolled "+se(n.value.scrollThreshold)+"%+ of the page",1),l("li",null,"Sensitivity: "+se(n.value.sensitivity),1)]),l("div",Fg,[a[33]||(a[33]=l("strong",null,"Action:",-1)),ne(" "+se(o()),1)]),l("button",{onClick:i,class:"test-button"},"Test Trigger")])])])]))}}),Dg=At(kg,[["__scopeId","data-v-ad4024dc"]]),Rg={class:"scroll-depth-widget-container"},jg={class:"scroll-depth-settings"},Ug={class:"settings-section"},Bg={class:"form-group"},Lg={class:"milestone-inputs"},Vg=["onUpdate:modelValue"],Ng={class:"form-group"},Hg={class:"checkbox-group"},zg={class:"settings-section"},Wg={class:"trigger-header"},Kg=["onClick"],Gg={class:"form-group"},qg=["onUpdate:modelValue"],Yg={class:"form-group"},Jg=["onUpdate:modelValue"],Xg={key:0,class:"form-group"},Qg=["onUpdate:modelValue"],Zg={key:1,class:"form-group"},ev=["onUpdate:modelValue"],tv={class:"form-group"},nv=["onUpdate:modelValue"],ov={class:"checkbox-group"},iv=["onUpdate:modelValue"],rv={class:"settings-section"},sv={class:"form-group"},lv={key:0,class:"form-group"},av={class:"checkbox-group"},uv={class:"preview-section"},dv={class:"preview-container"},cv=["innerHTML"],fv={class:"analytics-preview"},pv=Xe({__name:"ScrollDepthWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"scroll-depth-1",type:"scroll-depth",name:"Scroll Depth Analytics Widget",milestones:[25,50,75,90],engagementThreshold:15,trackTimeOnPage:!0,trackReadingSpeed:!0,trackBounceRate:!0,triggers:[{scrollDepth:50,action:"popup",delay:2e3,onlyOnce:!0}],displayMode:"progress-bar",position:"top",showToAdmin:!1}),o=()=>{n.value.milestones.push(100)},i=()=>{n.value.triggers.push({scrollDepth:75,action:"popup",delay:1e3,onlyOnce:!0})},s=a=>{n.value.triggers.splice(a,1)},u=N(()=>n.value.displayMode==="hidden"?'<div style="text-align: center; padding: 20px; color: #6b7280;">Analytics running in background (no visible UI)</div>':`
    <style>
      .scroll-analytics-container {
        ${{top:"position: fixed; top: 0; left: 0; right: 0; z-index: 9998;",bottom:"position: fixed; bottom: 0; left: 0; right: 0; z-index: 9998;",floating:"position: fixed; bottom: 20px; right: 20px; z-index: 9998;"}[n.value.position]}
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
        border: 1px solid #e5e7eb;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        ${n.value.position==="floating"?"border-radius: 8px; padding: 12px; max-width: 250px;":"padding: 8px 16px;"}
      }
      
      .scroll-progress-bar {
        width: 100%;
        height: 4px;
        background: #e5e7eb;
        border-radius: 2px;
        overflow: hidden;
      }
      
      .scroll-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #3b82f6, #8b5cf6);
        width: 0%;
        transition: width 0.3s ease;
      }
      
      .scroll-reading-time {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #374151;
      }
      
      .scroll-engagement-score {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #374151;
      }
      
      .scroll-metric {
        font-weight: 600;
        color: #1f2937;
      }
      
      .scroll-admin-panel {
        background: #f9fafb;
        border: 1px solid #e5e7eb;
        border-radius: 6px;
        padding: 12px;
        margin-top: 8px;
        font-size: 12px;
      }
      
      .scroll-milestone {
        display: inline-block;
        background: #ddd6fe;
        color: #5b21b6;
        padding: 2px 6px;
        border-radius: 4px;
        margin: 2px;
        font-size: 11px;
      }
      
      .scroll-milestone.reached {
        background: #10b981;
        color: white;
      }
    </style>
    
    <div class="scroll-analytics-container" id="scroll-analytics">
      ${n.value.displayMode==="progress-bar"?`
        <div class="scroll-progress-bar">
          <div class="scroll-progress-fill" id="scroll-progress"></div>
        </div>
      `:""}
      
      ${n.value.displayMode==="reading-time"?`
        <div class="scroll-reading-time">
          📖 Reading time: <span class="scroll-metric" id="reading-time">0m 0s</span>
        </div>
      `:""}
      
      ${n.value.displayMode==="engagement-score"?`
        <div class="scroll-engagement-score">
          📊 Engagement: <span class="scroll-metric" id="engagement-score">0%</span>
        </div>
      `:""}
      
      ${n.value.showToAdmin?`
        <div class="scroll-admin-panel" id="admin-panel">
          <div>Milestones: <span id="milestone-indicators"></span></div>
          <div>Time on page: <span id="time-on-page">0s</span></div>
          <div>Reading speed: <span id="reading-speed">0 WPM</span></div>
          <div>Scroll depth: <span id="max-scroll">0%</span></div>
        </div>
      `:""}
    </div>
  `),r=N(()=>`
    (function() {
      const config = {
        milestones: ${JSON.stringify(n.value.milestones)},
        engagementThreshold: ${n.value.engagementThreshold},
        trackTimeOnPage: ${n.value.trackTimeOnPage},
        trackReadingSpeed: ${n.value.trackReadingSpeed},
        trackBounceRate: ${n.value.trackBounceRate},
        triggers: ${JSON.stringify(n.value.triggers)},
        displayMode: '${n.value.displayMode}',
        showToAdmin: ${n.value.showToAdmin}
      };
      
      let analytics = {
        startTime: Date.now(),
        maxScroll: 0,
        timeAtDepths: {},
        milestoneReached: {},
        triggersExecuted: {},
        totalReadingTime: 0,
        wordCount: 0,
        engagementScore: 0
      };
      
      // Calculate word count for reading speed
      analytics.wordCount = document.body.innerText.split(/\\s+/).length;
      
      function getScrollPercent() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        return scrollHeight > 0 ? Math.round((scrollTop / scrollHeight) * 100) : 0;
      }
      
      function updateAnalytics() {
        const currentScroll = getScrollPercent();
        const currentTime = Date.now();
        const timeOnPage = Math.round((currentTime - analytics.startTime) / 1000);
        
        // Update max scroll
        if (currentScroll > analytics.maxScroll) {
          analytics.maxScroll = currentScroll;
        }
        
        // Track time at current depth
        const depthKey = Math.floor(currentScroll / 10) * 10;
        if (!analytics.timeAtDepths[depthKey]) {
          analytics.timeAtDepths[depthKey] = 0;
        }
        analytics.timeAtDepths[depthKey] += 0.5; // Update every 500ms
        
        // Check milestones
        config.milestones.forEach(milestone => {
          if (currentScroll >= milestone && !analytics.milestoneReached[milestone]) {
            analytics.milestoneReached[milestone] = currentTime;
            console.log('Milestone reached:', milestone + '%');
          }
        });
        
        // Check triggers
        config.triggers.forEach((trigger, index) => {
          if (currentScroll >= trigger.scrollDepth && !analytics.triggersExecuted[index]) {
            if (trigger.onlyOnce) {
              analytics.triggersExecuted[index] = true;
            }
            
            setTimeout(() => {
              switch (trigger.action) {
                case 'popup':
                  var event = new Event('customWidgetOpenPopup');
                  window.dispatchEvent(event);
                  break;
                case 'next-step':
                  var event = new Event('customWidgetGoToNextStep');
                  window.dispatchEvent(event);
                  break;
                case 'show-element':
                  if (trigger.elementId) {
                    const element = document.getElementById(trigger.elementId);
                    if (element) element.style.display = 'block';
                  }
                  break;
                case 'send-event':
                  if (trigger.eventName) {
                    var customEvent = new CustomEvent(trigger.eventName, {
                      detail: { scrollDepth: currentScroll, analytics: analytics }
                    });
                    window.dispatchEvent(customEvent);
                  }
                  break;
              }
            }, trigger.delay);
          }
        });
        
        // Calculate engagement score
        const engagedTime = Object.values(analytics.timeAtDepths)
          .filter(time => time >= config.engagementThreshold).length;
        analytics.engagementScore = Math.min(100, Math.round((engagedTime / config.milestones.length) * 100));
        
        // Update UI
        updateDisplay(currentScroll, timeOnPage);
      }
      
      function updateDisplay(scrollPercent, timeOnPage) {
        if (config.displayMode === 'hidden') return;
        
        const progressBar = document.getElementById('scroll-progress');
        const readingTime = document.getElementById('reading-time');
        const engagementScore = document.getElementById('engagement-score');
        
        if (progressBar) {
          progressBar.style.width = scrollPercent + '%';
        }
        
        if (readingTime) {
          const minutes = Math.floor(timeOnPage / 60);
          const seconds = timeOnPage % 60;
          readingTime.textContent = minutes + 'm ' + seconds + 's';
        }
        
        if (engagementScore) {
          engagementScore.textContent = analytics.engagementScore + '%';
        }
        
        if (config.showToAdmin) {
          updateAdminPanel(timeOnPage);
        }
      }
      
      function updateAdminPanel(timeOnPage) {
        const milestoneIndicators = document.getElementById('milestone-indicators');
        const timeOnPageEl = document.getElementById('time-on-page');
        const readingSpeedEl = document.getElementById('reading-speed');
        const maxScrollEl = document.getElementById('max-scroll');
        
        if (milestoneIndicators) {
          milestoneIndicators.innerHTML = config.milestones.map(milestone => 
            '<span class="scroll-milestone' + 
            (analytics.milestoneReached[milestone] ? ' reached' : '') + 
            '">' + milestone + '%</span>'
          ).join('');
        }
        
        if (timeOnPageEl) timeOnPageEl.textContent = timeOnPage + 's';
        if (maxScrollEl) maxScrollEl.textContent = analytics.maxScroll + '%';
        
        if (readingSpeedEl && timeOnPage > 0) {
          const wordsRead = Math.round((analytics.wordCount * analytics.maxScroll) / 100);
          const wpm = Math.round(wordsRead / (timeOnPage / 60));
          readingSpeedEl.textContent = wpm + ' WPM';
        }
      }
      
      // Start tracking
      setInterval(updateAnalytics, 500);
      
      // Track scroll events
      window.addEventListener('scroll', updateAnalytics);
      
      // Send analytics on page unload
      window.addEventListener('beforeunload', () => {
        if (config.trackBounceRate) {
          const finalAnalytics = {
            ...analytics,
            finalTime: Date.now(),
            bounced: analytics.maxScroll < 25 && (Date.now() - analytics.startTime) < 30000
          };
          
          // You could send this data to your analytics service
          console.log('Final analytics:', finalAnalytics);
        }
      });
      
      console.log('Scroll depth analytics initialized');
    })();
  `),c=t;return Le([n],()=>{c("codeChange",{html:u.value,js:r.value,elementStore:n.value})},{deep:!0,immediate:!0}),(a,d)=>(B(),W("div",Rg,[l("div",jg,[d[28]||(d[28]=l("h2",null,"Scroll Depth Analytics Widget",-1)),l("div",Ug,[d[13]||(d[13]=l("h3",null,"Scroll Tracking Configuration",-1)),l("div",Bg,[d[7]||(d[7]=l("label",null,"Tracking Milestones (%):",-1)),l("div",Lg,[(B(!0),W(_e,null,Eo(n.value.milestones,(m,v)=>y((B(),W("input",{key:v,"onUpdate:modelValue":E=>n.value.milestones[v]=E,type:"number",min:"0",max:"100",class:"milestone-input"},null,8,Vg)),[[_,n.value.milestones[v],void 0,{number:!0}]])),128))]),l("button",{onClick:o,class:"add-milestone-btn"},"Add Milestone")]),l("div",Ng,[d[8]||(d[8]=l("label",null,"Engagement Threshold (seconds):",-1)),y(l("input",{"onUpdate:modelValue":d[0]||(d[0]=m=>n.value.engagementThreshold=m),type:"number",min:"1",max:"300"},null,512),[[_,n.value.engagementThreshold,void 0,{number:!0}]]),d[9]||(d[9]=l("small",null,"Time spent reading at each milestone",-1))]),l("div",Hg,[l("label",null,[y(l("input",{"onUpdate:modelValue":d[1]||(d[1]=m=>n.value.trackTimeOnPage=m),type:"checkbox"},null,512),[[ie,n.value.trackTimeOnPage]]),d[10]||(d[10]=ne(" Track total time on page"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":d[2]||(d[2]=m=>n.value.trackReadingSpeed=m),type:"checkbox"},null,512),[[ie,n.value.trackReadingSpeed]]),d[11]||(d[11]=ne(" Calculate reading speed"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":d[3]||(d[3]=m=>n.value.trackBounceRate=m),type:"checkbox"},null,512),[[ie,n.value.trackBounceRate]]),d[12]||(d[12]=ne(" Track bounce indicators"))])])]),l("div",zg,[d[21]||(d[21]=l("h3",null,"Action Triggers",-1)),(B(!0),W(_e,null,Eo(n.value.triggers,(m,v)=>(B(),W("div",{key:v,class:"trigger-item"},[l("div",Wg,[l("h4",null,"Trigger "+se(v+1),1),l("button",{onClick:E=>s(v),class:"remove-btn"},"Remove",8,Kg)]),l("div",Gg,[d[14]||(d[14]=l("label",null,"Trigger at scroll depth (%):",-1)),y(l("input",{"onUpdate:modelValue":E=>m.scrollDepth=E,type:"number",min:"0",max:"100"},null,8,qg),[[_,m.scrollDepth,void 0,{number:!0}]])]),l("div",Yg,[d[16]||(d[16]=l("label",null,"Action:",-1)),y(l("select",{"onUpdate:modelValue":E=>m.action=E},d[15]||(d[15]=[l("option",{value:"popup"},"Open Popup",-1),l("option",{value:"next-step"},"Go to Next Step",-1),l("option",{value:"show-element"},"Show Hidden Element",-1),l("option",{value:"send-event"},"Send Custom Event",-1)]),8,Jg),[[re,m.action]])]),m.action==="show-element"?(B(),W("div",Xg,[d[17]||(d[17]=l("label",null,"Element ID to Show:",-1)),y(l("input",{"onUpdate:modelValue":E=>m.elementId=E,type:"text",placeholder:"my-hidden-element"},null,8,Qg),[[_,m.elementId]])])):Se("",!0),m.action==="send-event"?(B(),W("div",Zg,[d[18]||(d[18]=l("label",null,"Event Name:",-1)),y(l("input",{"onUpdate:modelValue":E=>m.eventName=E,type:"text",placeholder:"scroll-milestone-reached"},null,8,ev),[[_,m.eventName]])])):Se("",!0),l("div",tv,[d[19]||(d[19]=l("label",null,"Delay (ms):",-1)),y(l("input",{"onUpdate:modelValue":E=>m.delay=E,type:"number",min:"0",max:"10000"},null,8,nv),[[_,m.delay,void 0,{number:!0}]])]),l("div",ov,[l("label",null,[y(l("input",{"onUpdate:modelValue":E=>m.onlyOnce=E,type:"checkbox"},null,8,iv),[[ie,m.onlyOnce]]),d[20]||(d[20]=ne(" Only trigger once"))])])]))),128)),l("button",{onClick:i,class:"add-btn"},"Add Trigger")]),l("div",rv,[d[27]||(d[27]=l("h3",null,"Analytics Display",-1)),l("div",sv,[d[23]||(d[23]=l("label",null,"Display Mode:",-1)),y(l("select",{"onUpdate:modelValue":d[4]||(d[4]=m=>n.value.displayMode=m)},d[22]||(d[22]=[l("option",{value:"hidden"},"Hidden (background only)",-1),l("option",{value:"progress-bar"},"Progress Bar",-1),l("option",{value:"reading-time"},"Reading Time Indicator",-1),l("option",{value:"engagement-score"},"Engagement Score",-1)]),512),[[re,n.value.displayMode]])]),n.value.displayMode!=="hidden"?(B(),W("div",lv,[d[25]||(d[25]=l("label",null,"Position:",-1)),y(l("select",{"onUpdate:modelValue":d[5]||(d[5]=m=>n.value.position=m)},d[24]||(d[24]=[l("option",{value:"top"},"Top of Page",-1),l("option",{value:"bottom"},"Bottom of Page",-1),l("option",{value:"floating"},"Floating",-1)]),512),[[re,n.value.position]])])):Se("",!0),l("div",av,[l("label",null,[y(l("input",{"onUpdate:modelValue":d[6]||(d[6]=m=>n.value.showToAdmin=m),type:"checkbox"},null,512),[[ie,n.value.showToAdmin]]),d[26]||(d[26]=ne(" Show detailed analytics to admin"))])])])]),l("div",uv,[d[30]||(d[30]=l("h3",null,"Preview",-1)),l("div",dv,[l("div",{innerHTML:u.value,class:"widget-preview"},null,8,cv),l("div",fv,[d[29]||(d[29]=l("h4",null,"Analytics Tracking:",-1)),l("ul",null,[l("li",null,"Milestones: "+se(n.value.milestones.join("%, "))+"%",1),l("li",null,"Engagement threshold: "+se(n.value.engagementThreshold)+"s",1),l("li",null,"Triggers: "+se(n.value.triggers.length)+" configured",1),l("li",null,"Display: "+se(n.value.displayMode),1)])])])])]))}}),mv=At(pv,[["__scopeId","data-v-1b02a663"]]),gv={class:"form-abandonment-widget-container"},vv={class:"form-abandonment-settings"},hv={class:"settings-section"},bv={class:"form-group"},yv={key:0,class:"form-group"},xv={key:1,class:"form-group"},wv={class:"form-group"},Tv={class:"form-group"},Cv={class:"settings-section"},$v={class:"form-group"},Sv={class:"form-group"},Ev={key:0,class:"form-group"},Av={key:1,class:"form-group"},_v={class:"settings-section"},Ov={class:"form-group"},Pv={class:"form-group"},Iv={class:"checkbox-group"},Mv={class:"settings-section"},Fv={class:"form-group"},kv={class:"form-group"},Dv={class:"form-group"},Rv={class:"preview-section"},jv={class:"preview-container"},Uv=["innerHTML"],Bv={class:"recovery-preview"},Lv=Xe({__name:"FormAbandonmentWidget",emits:["codeChange"],setup(e,{emit:t}){const n=He({id:"form-abandonment-1",type:"form-abandonment",name:"Form Abandonment Recovery Widget",targetMode:"all",formIds:"",formClass:"",minFieldsFilled:2,abandonmentDelay:30,primaryAction:"popup",recoveryMessage:"Don't lose your progress! Complete your form to get started.",discountOffer:"Get 20% off if you complete now!",emailCaptureText:"Save your progress - enter your email",maxRecoveryAttempts:2,retryDelay:5,saveFormData:!0,trackFieldFocus:!0,enableExitIntent:!0,mobileOptimized:!0,theme:"modern",primaryColor:"#3b82f6",animationStyle:"slide"}),o=()=>{switch(n.value.targetMode){case"all":return"All forms on page";case"specific":return`Forms: ${n.value.formIds||"none specified"}`;case"class":return`Class: ${n.value.formClass||"none specified"}`;default:return"Not configured"}},i=()=>{alert(`Recovery action would trigger: ${n.value.primaryAction}
Message: ${n.value.recoveryMessage}`)},s=N(()=>{const a={modern:{bg:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",text:"#ffffff",border:"none",shadow:"0 20px 40px rgba(0,0,0,0.1)"},minimal:{bg:"#ffffff",text:"#374151",border:"1px solid #e5e7eb",shadow:"0 4px 6px rgba(0,0,0,0.05)"},urgent:{bg:"linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)",text:"#ffffff",border:"none",shadow:"0 8px 25px rgba(255,107,107,0.3)"},friendly:{bg:"linear-gradient(135deg, #74b9ff 0%, #0984e3 100%)",text:"#ffffff",border:"none",shadow:"0 8px 25px rgba(116,185,255,0.3)"}}[n.value.theme];return`
    <style>
      .form-recovery-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.6);
        z-index: 99999;
        display: none;
        align-items: center;
        justify-content: center;
        backdrop-filter: blur(4px);
      }
      
      .form-recovery-modal {
        background: ${a.bg};
        color: ${a.text};
        padding: 30px;
        border-radius: 16px;
        max-width: 400px;
        width: 90%;
        text-align: center;
        border: ${a.border};
        box-shadow: ${a.shadow};
        position: relative;
        animation: recoverySlideIn 0.4s ease-out;
      }
      
      @keyframes recoverySlideIn {
        from {
          opacity: 0;
          transform: translateY(-30px) scale(0.95);
        }
        to {
          opacity: 1;
          transform: translateY(0) scale(1);
        }
      }
      
      @keyframes recoveryShake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-5px); }
        75% { transform: translateX(5px); }
      }
      
      .form-recovery-title {
        font-size: 22px;
        font-weight: 700;
        margin-bottom: 15px;
        line-height: 1.3;
      }
      
      .form-recovery-message {
        font-size: 16px;
        margin-bottom: 25px;
        line-height: 1.5;
        opacity: 0.9;
      }
      
      .form-recovery-actions {
        display: flex;
        gap: 12px;
        justify-content: center;
        flex-wrap: wrap;
      }
      
      .form-recovery-btn {
        background: ${n.value.primaryColor};
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        font-size: 14px;
      }
      
      .form-recovery-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
      }
      
      .form-recovery-btn.secondary {
        background: transparent;
        color: ${a.text};
        border: 2px solid ${a.text==="#ffffff"?"rgba(255,255,255,0.3)":"#e5e7eb"};
      }
      
      .form-recovery-close {
        position: absolute;
        top: 15px;
        right: 15px;
        background: none;
        border: none;
        color: ${a.text};
        font-size: 24px;
        cursor: pointer;
        opacity: 0.7;
        transition: opacity 0.2s ease;
      }
      
      .form-recovery-close:hover {
        opacity: 1;
      }
      
      .form-recovery-banner {
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        background: ${a.bg};
        color: ${a.text};
        padding: 16px;
        text-align: center;
        border-top: ${a.border};
        box-shadow: 0 -4px 12px rgba(0,0,0,0.1);
        z-index: 99998;
        display: none;
        animation: recoverySlideUp 0.3s ease-out;
      }
      
      @keyframes recoverySlideUp {
        from {
          transform: translateY(100%);
        }
        to {
          transform: translateY(0);
        }
      }
      
      .form-recovery-email-capture {
        display: flex;
        gap: 8px;
        max-width: 300px;
        margin: 15px auto 0;
      }
      
      .form-recovery-email-input {
        flex: 1;
        padding: 10px 12px;
        border: 1px solid rgba(255,255,255,0.3);
        border-radius: 6px;
        background: rgba(255,255,255,0.1);
        color: ${a.text};
        font-size: 14px;
      }
      
      .form-recovery-email-input::placeholder {
        color: rgba(255,255,255,0.7);
      }
      
      .form-recovery-progress {
        background: rgba(255,255,255,0.2);
        height: 4px;
        border-radius: 2px;
        margin: 15px 0;
        overflow: hidden;
      }
      
      .form-recovery-progress-fill {
        background: ${n.value.primaryColor};
        height: 100%;
        width: 60%;
        border-radius: 2px;
      }
      
      @media (max-width: 768px) {
        .form-recovery-modal {
          margin: 20px;
          padding: 25px 20px;
        }
        
        .form-recovery-actions {
          flex-direction: column;
        }
        
        .form-recovery-btn {
          width: 100%;
        }
      }
    </style>
    
    <div class="form-recovery-overlay" id="form-recovery-overlay">
      <div class="form-recovery-modal">
        <button class="form-recovery-close" onclick="document.getElementById('form-recovery-overlay').style.display='none'">×</button>
        <div class="form-recovery-title">
          ${n.value.primaryAction==="discount"?"🎉 Special Offer!":n.value.primaryAction==="callback"?"📞 We Can Help!":n.value.primaryAction==="email-capture"?"💾 Save Your Progress":"⚠️ Don't Lose Your Progress!"}
        </div>
        <div class="form-recovery-message">${n.value.recoveryMessage}</div>
        
        ${n.value.primaryAction==="discount"?`
          <div style="background: rgba(255,255,255,0.1); padding: 15px; border-radius: 8px; margin: 15px 0;">
            <strong>${n.value.discountOffer}</strong>
          </div>
        `:""}
        
        ${n.value.primaryAction==="email-capture"?`
          <div class="form-recovery-email-capture">
            <input type="email" class="form-recovery-email-input" placeholder="Enter your email">
            <button class="form-recovery-btn">Save</button>
          </div>
        `:""}
        
        <div class="form-recovery-progress">
          <div class="form-recovery-progress-fill"></div>
        </div>
        
        <div class="form-recovery-actions">
          <button class="form-recovery-btn">
            ${n.value.primaryAction==="callback"?"Request Callback":n.value.primaryAction==="email-capture"?"Continue Form":"Complete Form"}
          </button>
          <button class="form-recovery-btn secondary">Maybe Later</button>
        </div>
      </div>
    </div>
    
    <div class="form-recovery-banner" id="form-recovery-banner">
      <div>${n.value.recoveryMessage}</div>
      <button class="form-recovery-btn" style="margin-top: 8px;">Complete Now</button>
    </div>
  `}),u=N(()=>`
    (function() {
      const config = {
        targetMode: '${n.value.targetMode}',
        formIds: '${n.value.formIds}'.split(',').map(id => id.trim()).filter(Boolean),
        formClass: '${n.value.formClass}',
        minFieldsFilled: ${n.value.minFieldsFilled},
        abandonmentDelay: ${n.value.abandonmentDelay*1e3},
        primaryAction: '${n.value.primaryAction}',
        maxRecoveryAttempts: ${n.value.maxRecoveryAttempts},
        retryDelay: ${n.value.retryDelay*60*1e3},
        saveFormData: ${n.value.saveFormData},
        trackFieldFocus: ${n.value.trackFieldFocus},
        enableExitIntent: ${n.value.enableExitIntent},
        mobileOptimized: ${n.value.mobileOptimized}
      };
      
      let formTracker = {
        forms: [],
        abandonmentTimers: new Map(),
        recoveryAttempts: 0,
        lastActivity: Date.now(),
        fieldsFilled: new Map(),
        formData: new Map(),
        focusPatterns: []
      };
      
      function initializeFormTracking() {
        let targetForms = [];
        
        switch (config.targetMode) {
          case 'all':
            targetForms = Array.from(document.querySelectorAll('form'));
            break;
          case 'specific':
            config.formIds.forEach(id => {
              const form = document.getElementById(id);
              if (form) targetForms.push(form);
            });
            break;
          case 'class':
            if (config.formClass) {
              targetForms = Array.from(document.querySelectorAll('.' + config.formClass));
            }
            break;
        }
        
        targetForms.forEach(form => {
          if (form.tagName === 'FORM') {
            setupFormTracking(form);
          }
        });
        
        console.log('Form abandonment tracking initialized for', targetForms.length, 'forms');
      }
      
      function setupFormTracking(form) {
        const formId = form.id || 'form-' + Math.random().toString(36).substr(2, 9);
        formTracker.fieldsFilled.set(formId, 0);
        formTracker.formData.set(formId, {});
        
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
          // Track field changes
          input.addEventListener('input', (e) => {
            handleFieldChange(formId, input, e.target.value);
          });
          
          input.addEventListener('change', (e) => {
            handleFieldChange(formId, input, e.target.value);
          });
          
          // Track focus patterns
          if (config.trackFieldFocus) {
            input.addEventListener('focus', () => {
              formTracker.focusPatterns.push({
                formId,
                field: input.name || input.type,
                timestamp: Date.now(),
                action: 'focus'
              });
            });
            
            input.addEventListener('blur', () => {
              formTracker.focusPatterns.push({
                formId,
                field: input.name || input.type,
                timestamp: Date.now(),
                action: 'blur'
              });
            });
          }
        });
        
        // Track form submission
        form.addEventListener('submit', () => {
          clearAbandonmentTimer(formId);
          console.log('Form submitted successfully:', formId);
        });
      }
      
      function handleFieldChange(formId, input, value) {
        formTracker.lastActivity = Date.now();
        
        // Update form data
        const formData = formTracker.formData.get(formId) || {};
        const fieldName = input.name || input.type || 'field-' + Math.random().toString(36).substr(2, 5);
        
        const hadValue = formData[fieldName] && formData[fieldName].length > 0;
        const hasValue = value && value.length > 0;
        
        formData[fieldName] = value;
        formTracker.formData.set(formId, formData);
        
        // Update filled fields count
        if (!hadValue && hasValue) {
          const currentCount = formTracker.fieldsFilled.get(formId) || 0;
          formTracker.fieldsFilled.set(formId, currentCount + 1);
        } else if (hadValue && !hasValue) {
          const currentCount = formTracker.fieldsFilled.get(formId) || 0;
          formTracker.fieldsFilled.set(formId, Math.max(0, currentCount - 1));
        }
        
        // Save form data locally
        if (config.saveFormData) {
          localStorage.setItem('form-data-' + formId, JSON.stringify(formData));
        }
        
        // Reset abandonment timer
        clearAbandonmentTimer(formId);
        setAbandonmentTimer(formId);
        
        console.log('Field changed in form', formId, '- Fields filled:', formTracker.fieldsFilled.get(formId));
      }
      
      function setAbandonmentTimer(formId) {
        const timer = setTimeout(() => {
          const fieldsFilled = formTracker.fieldsFilled.get(formId) || 0;
          
          if (fieldsFilled >= config.minFieldsFilled && 
              formTracker.recoveryAttempts < config.maxRecoveryAttempts) {
            triggerRecoveryAction(formId);
          }
        }, config.abandonmentDelay);
        
        formTracker.abandonmentTimers.set(formId, timer);
      }
      
      function clearAbandonmentTimer(formId) {
        const timer = formTracker.abandonmentTimers.get(formId);
        if (timer) {
          clearTimeout(timer);
          formTracker.abandonmentTimers.delete(formId);
        }
      }
      
      function triggerRecoveryAction(formId) {
        if (formTracker.recoveryAttempts >= config.maxRecoveryAttempts) {
          console.log('Max recovery attempts reached');
          return;
        }
        
        formTracker.recoveryAttempts++;
        console.log('Triggering recovery action:', config.primaryAction, 'for form:', formId);
        
        switch (config.primaryAction) {
          case 'popup':
            showRecoveryModal();
            break;
          case 'banner':
            showRecoveryBanner();
            break;
          case 'email-capture':
            showEmailCapture();
            break;
          case 'discount':
            showDiscountOffer();
            break;
          case 'callback':
            showCallbackRequest();
            break;
        }
        
        // Schedule retry if configured
        if (formTracker.recoveryAttempts < config.maxRecoveryAttempts) {
          setTimeout(() => {
            setAbandonmentTimer(formId);
          }, config.retryDelay);
        }
      }
      
      function showRecoveryModal() {
        const overlay = document.getElementById('form-recovery-overlay');
        if (overlay) {
          overlay.style.display = 'flex';
          
          // Add click handlers
          const completeBtn = overlay.querySelector('.form-recovery-btn:not(.secondary)');
          const laterBtn = overlay.querySelector('.form-recovery-btn.secondary');
          
          if (completeBtn) {
            completeBtn.addEventListener('click', () => {
              overlay.style.display = 'none';
              // Focus on first empty field
              focusFirstEmptyField();
            });
          }
          
          if (laterBtn) {
            laterBtn.addEventListener('click', () => {
              overlay.style.display = 'none';
            });
          }
        }
      }
      
      function showRecoveryBanner() {
        const banner = document.getElementById('form-recovery-banner');
        if (banner) {
          banner.style.display = 'block';
          
          const btn = banner.querySelector('.form-recovery-btn');
          if (btn) {
            btn.addEventListener('click', () => {
              banner.style.display = 'none';
              focusFirstEmptyField();
            });
          }
        }
      }
      
      function showEmailCapture() {
        showRecoveryModal();
        // Additional email capture logic would go here
      }
      
      function showDiscountOffer() {
        showRecoveryModal();
        // Additional discount logic would go here
      }
      
      function showCallbackRequest() {
        // Could trigger GHL popup or custom callback form
        var event = new Event('customWidgetOpenPopup');
        window.dispatchEvent(event);
      }
      
      function focusFirstEmptyField() {
        const forms = document.querySelectorAll('form');
        for (let form of forms) {
          const inputs = form.querySelectorAll('input, textarea, select');
          for (let input of inputs) {
            if (!input.value || input.value.trim() === '') {
              input.focus();
              return;
            }
          }
        }
      }
      
      // Exit intent integration
      if (config.enableExitIntent) {
        document.addEventListener('mouseleave', (e) => {
          if (e.clientY <= 5 && formTracker.recoveryAttempts < config.maxRecoveryAttempts) {
            // Check if any form has enough fields filled
            for (let [formId, fieldCount] of formTracker.fieldsFilled) {
              if (fieldCount >= config.minFieldsFilled) {
                triggerRecoveryAction(formId);
                break;
              }
            }
          }
        });
      }
      
      // Initialize tracking when DOM is ready
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeFormTracking);
      } else {
        initializeFormTracking();
      }
      
      // Re-initialize if new forms are added dynamically
      const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1) { // Element node
              const forms = node.tagName === 'FORM' ? [node] : node.querySelectorAll('form');
              forms.forEach(setupFormTracking);
            }
          });
        });
      });
      
      observer.observe(document.body, { childList: true, subtree: true });
      
      console.log('Form abandonment recovery widget initialized');
    })();
  `),r=t;return Le([n],()=>{r("codeChange",{html:s.value,js:u.value,elementStore:n.value})},{deep:!0,immediate:!0}),(c,a)=>(B(),W("div",gv,[l("div",vv,[a[47]||(a[47]=l("h2",null,"Form Abandonment Recovery Widget",-1)),l("div",hv,[a[26]||(a[26]=l("h3",null,"Form Tracking Configuration",-1)),l("div",bv,[a[19]||(a[19]=l("label",null,"Target Forms:",-1)),y(l("select",{"onUpdate:modelValue":a[0]||(a[0]=d=>n.value.targetMode=d)},a[18]||(a[18]=[l("option",{value:"all"},"All forms on page",-1),l("option",{value:"specific"},"Specific form IDs",-1),l("option",{value:"class"},"Forms with specific class",-1)]),512),[[re,n.value.targetMode]])]),n.value.targetMode==="specific"?(B(),W("div",yv,[a[20]||(a[20]=l("label",null,"Form IDs (comma separated):",-1)),y(l("input",{"onUpdate:modelValue":a[1]||(a[1]=d=>n.value.formIds=d),type:"text",placeholder:"contact-form, signup-form"},null,512),[[_,n.value.formIds]])])):Se("",!0),n.value.targetMode==="class"?(B(),W("div",xv,[a[21]||(a[21]=l("label",null,"CSS Class:",-1)),y(l("input",{"onUpdate:modelValue":a[2]||(a[2]=d=>n.value.formClass=d),type:"text",placeholder:"tracked-form"},null,512),[[_,n.value.formClass]])])):Se("",!0),l("div",wv,[a[22]||(a[22]=l("label",null,"Minimum Fields Filled:",-1)),y(l("input",{"onUpdate:modelValue":a[3]||(a[3]=d=>n.value.minFieldsFilled=d),type:"number",min:"1",max:"10"},null,512),[[_,n.value.minFieldsFilled,void 0,{number:!0}]]),a[23]||(a[23]=l("small",null,"Trigger only after this many fields are filled",-1))]),l("div",Tv,[a[24]||(a[24]=l("label",null,"Abandonment Delay (seconds):",-1)),y(l("input",{"onUpdate:modelValue":a[4]||(a[4]=d=>n.value.abandonmentDelay=d),type:"number",min:"5",max:"300"},null,512),[[_,n.value.abandonmentDelay,void 0,{number:!0}]]),a[25]||(a[25]=l("small",null,"Time of inactivity before considering form abandoned",-1))])]),l("div",Cv,[a[32]||(a[32]=l("h3",null,"Recovery Actions",-1)),l("div",$v,[a[28]||(a[28]=l("label",null,"Primary Recovery Action:",-1)),y(l("select",{"onUpdate:modelValue":a[5]||(a[5]=d=>n.value.primaryAction=d)},a[27]||(a[27]=[ge('<option value="popup" data-v-e4c4135b>Show Recovery Popup</option><option value="banner" data-v-e4c4135b>Show Sticky Banner</option><option value="email-capture" data-v-e4c4135b>Quick Email Capture</option><option value="discount" data-v-e4c4135b>Offer Discount</option><option value="callback" data-v-e4c4135b>Request Callback</option>',5)]),512),[[re,n.value.primaryAction]])]),l("div",Sv,[a[29]||(a[29]=l("label",null,"Recovery Message:",-1)),y(l("textarea",{"onUpdate:modelValue":a[6]||(a[6]=d=>n.value.recoveryMessage=d),rows:"3",placeholder:"Don't lose your progress! Complete your form to get started."},null,512),[[_,n.value.recoveryMessage]])]),n.value.primaryAction==="discount"?(B(),W("div",Ev,[a[30]||(a[30]=l("label",null,"Discount Offer:",-1)),y(l("input",{"onUpdate:modelValue":a[7]||(a[7]=d=>n.value.discountOffer=d),type:"text",placeholder:"Get 20% off if you complete now!"},null,512),[[_,n.value.discountOffer]])])):Se("",!0),n.value.primaryAction==="email-capture"?(B(),W("div",Av,[a[31]||(a[31]=l("label",null,"Email Capture Text:",-1)),y(l("input",{"onUpdate:modelValue":a[8]||(a[8]=d=>n.value.emailCaptureText=d),type:"text",placeholder:"Save your progress - enter your email"},null,512),[[_,n.value.emailCaptureText]])])):Se("",!0)]),l("div",_v,[a[40]||(a[40]=l("h3",null,"Advanced Options",-1)),l("div",Ov,[a[33]||(a[33]=l("label",null,"Recovery Attempts:",-1)),y(l("input",{"onUpdate:modelValue":a[9]||(a[9]=d=>n.value.maxRecoveryAttempts=d),type:"number",min:"1",max:"5"},null,512),[[_,n.value.maxRecoveryAttempts,void 0,{number:!0}]]),a[34]||(a[34]=l("small",null,"Maximum recovery attempts per session",-1))]),l("div",Pv,[a[35]||(a[35]=l("label",null,"Retry Delay (minutes):",-1)),y(l("input",{"onUpdate:modelValue":a[10]||(a[10]=d=>n.value.retryDelay=d),type:"number",min:"1",max:"60"},null,512),[[_,n.value.retryDelay,void 0,{number:!0}]])]),l("div",Iv,[l("label",null,[y(l("input",{"onUpdate:modelValue":a[11]||(a[11]=d=>n.value.saveFormData=d),type:"checkbox"},null,512),[[ie,n.value.saveFormData]]),a[36]||(a[36]=ne(" Save form data locally"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":a[12]||(a[12]=d=>n.value.trackFieldFocus=d),type:"checkbox"},null,512),[[ie,n.value.trackFieldFocus]]),a[37]||(a[37]=ne(" Track field focus patterns"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":a[13]||(a[13]=d=>n.value.enableExitIntent=d),type:"checkbox"},null,512),[[ie,n.value.enableExitIntent]]),a[38]||(a[38]=ne(" Combine with exit intent"))]),l("label",null,[y(l("input",{"onUpdate:modelValue":a[14]||(a[14]=d=>n.value.mobileOptimized=d),type:"checkbox"},null,512),[[ie,n.value.mobileOptimized]]),a[39]||(a[39]=ne(" Mobile-optimized recovery"))])])]),l("div",Mv,[a[46]||(a[46]=l("h3",null,"Recovery UI Styling",-1)),l("div",Fv,[a[42]||(a[42]=l("label",null,"Theme:",-1)),y(l("select",{"onUpdate:modelValue":a[15]||(a[15]=d=>n.value.theme=d)},a[41]||(a[41]=[l("option",{value:"modern"},"Modern",-1),l("option",{value:"minimal"},"Minimal",-1),l("option",{value:"urgent"},"Urgent",-1),l("option",{value:"friendly"},"Friendly",-1)]),512),[[re,n.value.theme]])]),l("div",kv,[a[43]||(a[43]=l("label",null,"Primary Color:",-1)),y(l("input",{"onUpdate:modelValue":a[16]||(a[16]=d=>n.value.primaryColor=d),type:"color"},null,512),[[_,n.value.primaryColor]])]),l("div",Dv,[a[45]||(a[45]=l("label",null,"Animation Style:",-1)),y(l("select",{"onUpdate:modelValue":a[17]||(a[17]=d=>n.value.animationStyle=d)},a[44]||(a[44]=[l("option",{value:"slide"},"Slide In",-1),l("option",{value:"fade"},"Fade In",-1),l("option",{value:"bounce"},"Bounce",-1),l("option",{value:"shake"},"Shake",-1)]),512),[[re,n.value.animationStyle]])])])]),l("div",Rv,[a[49]||(a[49]=l("h3",null,"Preview",-1)),l("div",jv,[l("div",{innerHTML:s.value,class:"widget-preview"},null,8,Uv),l("div",Bv,[a[48]||(a[48]=l("h4",null,"Form Abandonment Recovery Active",-1)),l("ul",null,[l("li",null,"Tracking: "+se(o()),1),l("li",null,"Trigger: "+se(n.value.minFieldsFilled)+" fields + "+se(n.value.abandonmentDelay)+"s delay",1),l("li",null,"Action: "+se(n.value.primaryAction),1),l("li",null,"Max attempts: "+se(n.value.maxRecoveryAttempts),1)]),l("button",{onClick:i,class:"test-button"},"Test Recovery Action")])])])]))}}),Vv=At(Lv,[["__scopeId","data-v-e4c4135b"]]),Nv={class:"widget-selector-container"},Hv={key:0,class:"widget-gallery"},zv={class:"widget-grid"},Wv={key:1,class:"widget-configuration"},Kv={class:"widget-header"},Gv=Xe({__name:"WidgetSelector",emits:["codeChange"],setup(e,{emit:t}){const n=He(null),o=a=>{n.value=a},i=()=>{n.value=null},s=a=>({pricing:"Pricing Table Widget",countdown:"Countdown Timer Widget","social-proof":"Social Proof Widget","cta-banner":"CTA Banner Widget","progress-bar":"Progress Bar Widget",faq:"FAQ Accordion Widget","exit-intent":"Exit Intent Trigger Widget","scroll-depth":"Scroll Depth Analytics Widget","form-abandonment":"Form Abandonment Recovery Widget"})[a]||"Widget Configuration",u=a=>({countdown:lm,"social-proof":Vm,"cta-banner":pg,"exit-intent":Dg,"scroll-depth":mv,"form-abandonment":Vv})[a],r=t,c=a=>{r("codeChange",a)};return(a,d)=>(B(),W("div",Nv,[n.value?(B(),W("div",Wv,[l("div",Kv,[l("button",{onClick:i,class:"back-button"},"← Back to Widgets"),l("h2",null,se(s(n.value)),1)]),(B(),ai($a(u(n.value)),{onCodeChange:c},null,32))])):(B(),W("div",Hv,[d[18]||(d[18]=l("h1",null,"Choose Your Widget",-1)),d[19]||(d[19]=l("p",{class:"subtitle"},"Select a widget type to customize for your GoHighLevel funnel",-1)),l("div",zv,[l("div",{class:"widget-card",onClick:d[0]||(d[0]=m=>o("pricing"))},d[9]||(d[9]=[ge('<div class="widget-icon" data-v-202684b2>💰</div><h3 data-v-202684b2>Pricing Table</h3><p data-v-202684b2>Display pricing plans with features comparison to drive conversions</p><div class="widget-preview-img" data-v-202684b2><div class="mini-pricing-preview" data-v-202684b2><div class="mini-plan" data-v-202684b2><div class="mini-plan-name" data-v-202684b2>Basic</div><div class="mini-plan-price" data-v-202684b2>$29</div><div class="mini-plan-features" data-v-202684b2><div class="mini-feature" data-v-202684b2>✓ Feature 1</div><div class="mini-feature" data-v-202684b2>✓ Feature 2</div></div></div><div class="mini-plan popular" data-v-202684b2><div class="mini-plan-name" data-v-202684b2>Pro</div><div class="mini-plan-price" data-v-202684b2>$99</div><div class="mini-plan-features" data-v-202684b2><div class="mini-feature" data-v-202684b2>✓ Feature 1</div><div class="mini-feature" data-v-202684b2>✓ Feature 2</div></div></div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[1]||(d[1]=m=>o("countdown"))},d[10]||(d[10]=[ge('<div class="widget-icon" data-v-202684b2>⏰</div><h3 data-v-202684b2>Countdown Timer</h3><p data-v-202684b2>Create urgency with customizable countdown timers for limited-time offers</p><div class="widget-preview-img" data-v-202684b2><div class="mini-countdown-preview" data-v-202684b2><div class="mini-countdown-title" data-v-202684b2>Limited Time Offer!</div><div class="mini-countdown-timer" data-v-202684b2><div class="mini-time-unit" data-v-202684b2><div class="mini-time-number" data-v-202684b2>05</div><div class="mini-time-label" data-v-202684b2>Days</div></div><div class="mini-time-unit" data-v-202684b2><div class="mini-time-number" data-v-202684b2>12</div><div class="mini-time-label" data-v-202684b2>Hours</div></div></div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[2]||(d[2]=m=>o("social-proof"))},d[11]||(d[11]=[ge('<div class="widget-icon" data-v-202684b2>👥</div><h3 data-v-202684b2>Social Proof</h3><p data-v-202684b2>Show recent customer activity to build trust and encourage conversions</p><div class="widget-preview-img" data-v-202684b2><div class="mini-social-proof-preview" data-v-202684b2><div class="mini-notification" data-v-202684b2><div class="mini-avatar" data-v-202684b2>JD</div><div class="mini-notification-text" data-v-202684b2><div data-v-202684b2><strong data-v-202684b2>John D.</strong> purchased Premium Course</div><div class="mini-meta" data-v-202684b2>2 minutes ago</div></div></div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[3]||(d[3]=m=>o("cta-banner"))},d[12]||(d[12]=[ge('<div class="widget-icon" data-v-202684b2>📢</div><h3 data-v-202684b2>CTA Banner</h3><p data-v-202684b2>Eye-catching banners to promote offers and drive immediate action</p><div class="widget-preview-img" data-v-202684b2><div class="mini-cta-preview" data-v-202684b2><div class="mini-cta-text" data-v-202684b2><div class="mini-cta-headline" data-v-202684b2>Don&#39;t Miss Out!</div><div class="mini-cta-sub" data-v-202684b2>Limited time offer</div></div><div class="mini-cta-button" data-v-202684b2>Get Started</div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[4]||(d[4]=m=>o("progress-bar"))},d[13]||(d[13]=[ge('<div class="widget-icon" data-v-202684b2>📊</div><h3 data-v-202684b2>Progress Bar</h3><p data-v-202684b2>Show progress towards goals, fundraising targets, or course completion</p><div class="widget-preview-img" data-v-202684b2><div class="mini-progress-preview" data-v-202684b2><div class="mini-progress-title" data-v-202684b2>Goal Progress</div><div class="mini-progress-bar" data-v-202684b2><div class="mini-progress-fill" style="width:75%;" data-v-202684b2></div></div><div class="mini-progress-text" data-v-202684b2>75% Complete</div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[5]||(d[5]=m=>o("faq"))},d[14]||(d[14]=[ge('<div class="widget-icon" data-v-202684b2>❓</div><h3 data-v-202684b2>FAQ Accordion</h3><p data-v-202684b2>Collapsible FAQ sections to address common questions and concerns</p><div class="widget-preview-img" data-v-202684b2><div class="mini-faq-preview" data-v-202684b2><div class="mini-faq-item" data-v-202684b2><div class="mini-faq-question" data-v-202684b2>What&#39;s included? ▼</div></div><div class="mini-faq-item" data-v-202684b2><div class="mini-faq-question" data-v-202684b2>How does it work? ▼</div></div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[6]||(d[6]=m=>o("exit-intent"))},d[15]||(d[15]=[ge('<div class="widget-icon" data-v-202684b2>🚪</div><h3 data-v-202684b2>Exit Intent Trigger</h3><p data-v-202684b2>Detect when users are about to leave and trigger recovery actions</p><div class="widget-preview-img" data-v-202684b2><div class="mini-exit-intent-preview" data-v-202684b2><div class="mini-cursor" data-v-202684b2>🖱️</div><div class="mini-exit-text" data-v-202684b2>Exit detected!</div><div class="mini-exit-action" data-v-202684b2>→ Trigger Action</div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[7]||(d[7]=m=>o("scroll-depth"))},d[16]||(d[16]=[ge('<div class="widget-icon" data-v-202684b2>📊</div><h3 data-v-202684b2>Scroll Analytics</h3><p data-v-202684b2>Track user engagement and trigger actions based on scroll behavior</p><div class="widget-preview-img" data-v-202684b2><div class="mini-scroll-analytics-preview" data-v-202684b2><div class="mini-scroll-bar" data-v-202684b2><div class="mini-scroll-fill" style="width:60%;" data-v-202684b2></div></div><div class="mini-scroll-stats" data-v-202684b2>60% • 2m 15s</div></div></div>',4)])),l("div",{class:"widget-card",onClick:d[8]||(d[8]=m=>o("form-abandonment"))},d[17]||(d[17]=[ge('<div class="widget-icon" data-v-202684b2>📝</div><h3 data-v-202684b2>Form Recovery</h3><p data-v-202684b2>Detect form abandonment and trigger smart recovery actions</p><div class="widget-preview-img" data-v-202684b2><div class="mini-form-recovery-preview" data-v-202684b2><div class="mini-form" data-v-202684b2><div class="mini-form-field filled" data-v-202684b2></div><div class="mini-form-field filled" data-v-202684b2></div><div class="mini-form-field empty" data-v-202684b2></div></div><div class="mini-recovery-popup" data-v-202684b2>💾 Save progress?</div></div></div>',4)]))])]))]))}}),qv=At(Gv,[["__scopeId","data-v-202684b2"]]);/**
  postmate - A powerful, simple, promise-based postMessage library
  @version v1.5.2
  @link https://github.com/dollarshaveclub/postmate
  @author Jacob Kelley <jakie8@gmail.com>
  @license MIT
**/var xt="application/x-postmate-v1+json",Yv=5,Jv=0,Xv=function(){return++Jv},Qv=function(t){var n=document.createElement("a");n.href=t;var o=n.protocol.length>4?n.protocol:window.location.protocol,i=n.host.length?n.port==="80"||n.port==="443"?n.hostname:n.host:window.location.host;return n.origin||o+"//"+i},Zv={handshake:1,"handshake-reply":1,call:1,emit:1,reply:1,request:1},yi=function(t,n){return!(typeof n=="string"&&t.origin!==n||!t.data||typeof t.data=="object"&&!("postmate"in t.data)||t.data.type!==xt||!Zv[t.data.postmate])},eh=function(t,n){var o=typeof t[n]=="function"?t[n]():t[n];return wt.Promise.resolve(o)},th=function(){function e(n){var o=this;this.parent=n.parent,this.frame=n.frame,this.child=n.child,this.childOrigin=n.childOrigin,this.events={},this.listener=function(i){if(!yi(i,o.childOrigin))return!1;var s=((i||{}).data||{}).value||{},u=s.data,r=s.name;i.data.postmate==="emit"&&r in o.events&&o.events[r].call(o,u)},this.parent.addEventListener("message",this.listener,!1)}var t=e.prototype;return t.get=function(o){var i=this;return new wt.Promise(function(s){var u=Xv(),r=function c(a){a.data.uid===u&&a.data.postmate==="reply"&&(i.parent.removeEventListener("message",c,!1),s(a.data.value))};i.parent.addEventListener("message",r,!1),i.child.postMessage({postmate:"request",type:xt,property:o,uid:u},i.childOrigin)})},t.call=function(o,i){this.child.postMessage({postmate:"call",type:xt,property:o,data:i},this.childOrigin)},t.on=function(o,i){this.events[o]=i},t.destroy=function(){window.removeEventListener("message",this.listener,!1),this.frame.parentNode.removeChild(this.frame)},e}(),nh=function(){function e(n){var o=this;this.model=n.model,this.parent=n.parent,this.parentOrigin=n.parentOrigin,this.child=n.child,this.child.addEventListener("message",function(i){if(yi(i,o.parentOrigin)){var s=i.data,u=s.property,r=s.uid,c=s.data;if(i.data.postmate==="call"){u in o.model&&typeof o.model[u]=="function"&&o.model[u](c);return}eh(o.model,u).then(function(a){return i.source.postMessage({property:u,postmate:"reply",type:xt,uid:r,value:a},i.origin)})}})}var t=e.prototype;return t.emit=function(o,i){this.parent.postMessage({postmate:"emit",type:xt,value:{name:o,data:i}},this.parentOrigin)},e}(),wt=function(){function e(n){var o=n.container,i=o===void 0?typeof i<"u"?i:document.body:o,s=n.model,u=n.url,r=n.name,c=n.classListArray,a=c===void 0?[]:c;return this.parent=window,this.frame=document.createElement("iframe"),this.frame.name=r||"",this.frame.classList.add.apply(this.frame.classList,a),i.appendChild(this.frame),this.child=this.frame.contentWindow||this.frame.contentDocument.parentWindow,this.model=s||{},this.sendHandshake(u)}var t=e.prototype;return t.sendHandshake=function(o){var i=this,s=Qv(o),u=0,r;return new e.Promise(function(c,a){var d=function E(R){return yi(R,s)?R.data.postmate==="handshake-reply"?(clearInterval(r),i.parent.removeEventListener("message",E,!1),i.childOrigin=R.origin,c(new th(i))):a("Failed handshake"):!1};i.parent.addEventListener("message",d,!1);var m=function(){u++,i.child.postMessage({postmate:"handshake",type:xt,model:i.model},s),u===Yv&&clearInterval(r)},v=function(){m(),r=setInterval(m,500)};i.frame.attachEvent?i.frame.attachEvent("onload",v):i.frame.onload=v,i.frame.src=o})},e}();wt.debug=!1;wt.Promise=function(){try{return window?window.Promise:Promise}catch{return null}}();wt.Model=function(){function e(n){return this.child=window,this.model=n,this.parent=this.child.parent,this.sendHandshakeReply()}var t=e.prototype;return t.sendHandshakeReply=function(){var o=this;return new wt.Promise(function(i,s){var u=function r(c){if(c.data.postmate){if(c.data.postmate==="handshake"){o.child.removeEventListener("message",r,!1),c.source.postMessage({postmate:"handshake-reply",type:xt},c.origin),o.parentOrigin=c.origin;var a=c.data.model;return a&&Object.keys(a).forEach(function(d){o.model[d]=a[d]}),i(new nh(o))}return s("Handshake Reply Failed")}};o.child.addEventListener("message",u,!1)})},e}();const oh=He([{name:"Starter",price:"$29",annualPrice:"$19 USD per month, paid annually",buttonAction:"https://stripe.com",buttonText:"Get started",features:[{text:"All tools you need to manage payments",available:!0},{text:"No setup, monthly, or hidden fees",available:!0},{text:"Comprehensive security",available:!0},{text:"Get hundreds of feature updates",available:!1},{text:"Payouts to your bank account",available:!1},{text:"Financial reconciliation and reporting",available:!1},{text:"24x7 phone, chat, and email support",available:!1},{text:"Robust developer platform",available:!1}]},{name:"Premium",price:"$199",annualPrice:"$159 USD per month, paid annually",buttonAction:"https://stripe.com",buttonText:"Get started",mostPopular:!0,features:[{text:"All tools you need to manage payments",available:!0},{text:"No setup, monthly, or hidden fees",available:!0},{text:"Comprehensive security",available:!0},{text:"Get hundreds of feature updates",available:!0},{text:"Payouts to your bank account",available:!0},{text:"Financial reconciliation and reporting",available:!1},{text:"24x7 phone, chat, and email support",available:!1},{text:"Robust developer platform",available:!1},{text:"Robust developer platform",available:!1}]},{name:"Enterprise",price:"$599",annualPrice:"$499 USD per month, paid annually",buttonAction:"https://stripe.com",buttonText:"Get started",features:[{text:"All tools you need to manage payments",available:!0},{text:"No setup, monthly, or hidden fees",available:!0},{text:"Comprehensive security",available:!0},{text:"Get hundreds of feature updates",available:!0},{text:"Payouts to your bank account",available:!0},{text:"Financial reconciliation and reporting",available:!0},{text:"24x7 phone, chat, and email support",available:!0},{text:"Robust developer platform",available:!0}]}]),ih=He({headlineFont:"Inter",contentFont:"Inter",headlineWeight:"700",contentWeight:"400",borderColor:"#e5e7eb",contentFontSize:"16px",headlineFontSize:"24px",mostPopularBorderColor:"#2563eb",mostPopularBgColor:"#eff6ff",mostPopularLabelColor:"#2563eb",annualPriceColor:"#6b7280",buttonBgColor:"black",mostPopularButtonBgColor:"#2563eb",featureUnavailableColor:"#9ca3af",textColor:"#111827"}),ml=()=>({plans:oh,defaultStyles:ih}),rh=()=>{const{plans:e,defaultStyles:t}=ml(),n=N(()=>`
        <div style="display: flex; justify-content: center; padding-top: 2.5rem; padding-bottom: 2.5rem;">
          <div class="plan-grid">
            ${e.value.map(u=>`
                <div style="padding: 1.5rem; text-align: center; border-radius: 0.5rem; border: 1px solid ${t.value.borderColor}; color: ${t.value.textColor}; ${u.mostPopular?`border: 2px solid ${t.value.mostPopularBorderColor}; background-color: ${t.value.mostPopularBgColor};`:""}">
                  ${u.mostPopular?`<div style="margin-bottom: 0.5rem; font-size: 0.875rem; color: ${t.value.mostPopularLabelColor};font-family: '${t.value.headlineFont}', sans-serif;">Most popular</div>`:""}
                  <h2 style="margin-bottom: 1rem; font-size: ${t.value.headlineFontSize}; font-weight: ${t.value.headlineWeight}; font-family: '${t.value.headlineFont}', sans-serif;">${u.name}</h2>
                  <p style="margin-bottom: 0.25rem; font-size: ${t.value.headlineFontSize}; font-weight: ${t.value.headlineWeight}; font-family: '${t.value.headlineFont}', sans-serif;">${u.price}</p>
                  <p style="margin-bottom: 1.5rem; font-size: ${t.value.contentFontSize}; color: ${t.value.annualPriceColor}; font-weight: ${t.value.contentWeight}; font-family: '${t.value.contentFont}', sans-serif;">${u.annualPrice}</p>
                  <button style="border:none;padding: 0.5rem 1rem; margin-bottom: 1.5rem; color: white; border-radius: 0.25rem; background-color: ${u.mostPopular?t.value.mostPopularButtonBgColor:t.value.buttonBgColor}; font-size: ${t.value.contentFontSize}; font-weight: ${t.value.headlineWeight}; font-family: '${t.value.headlineFont}', sans-serif;cursor:pointer">
                    ${u.buttonText}
                  </button>
                  <ul style="text-align: left;padding:0px; display: flex; flex-direction: column; list-style: none; gap: 0.5rem; font-size: ${t.value.contentFontSize}; font-weight: ${t.value.contentWeight}; font-family: '${t.value.contentFont}', sans-serif;">
                    ${u.features.map(r=>`
                      <li style="display: flex; align-items: center;">
                        <span style="margin-right: 0.5rem;">${r.available?"✔️":"❌"}</span>
                        <span  style="${r.available?"":`color: ${t.value.featureUnavailableColor}; text-decoration: line-through;`}">${r.text}</span>
                      </li>
                    `).join("")}
                  </ul>
                </div>
              `).join("")}
          </div>
        </div>
      `),o=N(()=>`
    <style>
      @import url('https://fonts.googleapis.com/css2?family=${t.value.headlineFont}:wght@${t.value.headlineWeight}&display=swap');
      @import url('https://fonts.googleapis.com/css2?family=${t.value.contentFont}:wght@${t.value.contentWeight}&display=swap');
    
    .plan-grid {
      display: grid;
      width: 100%;
      max-width: 56rem;
      grid-template-columns: repeat(1, minmax(0, 1fr));
      gap: 1.25rem;
    }
    
    .--mobile .plan-grid{
      grid-template-columns: repeat(1, minmax(0, 1fr));
    }
    
    @media (min-width: 768px) {
      .plan-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }
    }
    </style>
    `),i=N(()=>`
      ${n.value}
      ${o.value}
    `),s=N(()=>`
        function openLink(url) {
          window.open(url, '_blank');
        }

        document.querySelectorAll('.plan-grid button').forEach((button, index) => {
          button.addEventListener('click', () => {
            const plans = ${JSON.stringify(e.value.map(u=>({buttonAction:u.buttonAction})))};
              const plan = plans[index];
              if (plan && plan.buttonAction) {
                openLink(plan.buttonAction);
              }
          });
        });
    `);return{htmlPreview:i,js:s}},Jt=new wt.Model({}),sh=()=>{const e=ml(),{htmlPreview:t,js:n}=rh();return{handshake:Jt,emitCode:()=>{Jt&&(Jt==null||Jt.then(async i=>{console.info("Emitting code to parent",i),i==null||i.emit("code",{html:t.value,js:n.value,elementStore:_p({plans:e.plans.value,defaultStyles:e.defaultStyles.value})})}))}}},lh={name:"common",common:{name:"common",fontFamily:'Inter var, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji""',fontFamilyMono:"v-mono, SFMono-Regular, Menlo, Consolas, Courier, monospace",fontWeight:"400",fontWeightStrong:"500",cubicBezierEaseInOut:"cubic-bezier(.4, 0, .2, 1)",cubicBezierEaseOut:"cubic-bezier(0, 0, .2, 1)",cubicBezierEaseIn:"cubic-bezier(.4, 0, 1, 1)",borderRadius:"3px",borderRadiusSmall:"2px",fontSize:"14px",fontSizeMini:"12px",fontSizeTiny:"12px",fontSizeSmall:"14px",fontSizeMedium:"14px",fontSizeLarge:"15px",fontSizeHuge:"16px",lineHeight:"1.6",heightMini:"16px",heightTiny:"22px",heightSmall:"28px",heightMedium:"34px",heightLarge:"40px",heightHuge:"46px",baseColor:"#FFF",primaryColor:"#155EEF",primaryColorHover:"#004EEB",primaryColorPressed:"#155EEF",primaryColorSuppl:"#155EEF",infoColor:"#2080f0",infoColorHover:"#4098fc",infoColorPressed:"#1060c9",infoColorSuppl:"#4098fc",successColor:"#155EEF",successColorHover:"#155EEF",successColorPressed:"#004EEB",successColorSuppl:"#155EEF",warningColor:"#f0a020",warningColorHover:"#fcb040",warningColorPressed:"#c97c10",warningColorSuppl:"#fcb040",errorColor:"#D92D20",errorColorHover:"#B42318",errorColorPressed:"#D92D20",errorColorSuppl:"#D92D20",textColorBase:"#000",textColor1:"rgba(16, 24, 40, 1)",textColor2:"rgba(52, 64, 84, 1)",textColor3:"rgb(118, 124, 130)",textColorDisabled:"rgba(194, 194, 194, 1)",placeholderColor:"rgba(102, 112, 133, 1)",placeholderColorDisabled:"rgba(209, 209, 209, 1)",iconColor:"rgba(194, 194, 194, 1)",iconColorHover:"rgba(146, 146, 146, 1)",iconColorPressed:"rgba(175, 175, 175, 1)",iconColorDisabled:"rgba(209, 209, 209, 1)",opacity1:"0.82",opacity2:"0.72",opacity3:"0.38",opacity4:"0.24",opacity5:"0.18",dividerColor:"rgb(239, 239, 245)",borderColor:"rgb(224, 224, 230)",closeIconColor:"rgba(102, 102, 102, 1)",closeIconColorHover:"rgba(102, 102, 102, 1)",closeIconColorPressed:"rgba(102, 102, 102, 1)",closeColorHover:"rgba(0, 0, 0, .09)",closeColorPressed:"rgba(0, 0, 0, .13)",clearColor:"rgba(194, 194, 194, 1)",clearColorHover:"rgba(146, 146, 146, 1)",clearColorPressed:"rgba(175, 175, 175, 1)",scrollbarColor:"rgba(0, 0, 0, 0.25)",scrollbarColorHover:"rgba(0, 0, 0, 0.4)",scrollbarWidth:"5px",scrollbarHeight:"5px",scrollbarBorderRadius:"5px",progressRailColor:"rgba(235, 235, 235, 1)",railColor:"rgb(219, 219, 223)",popoverColor:"#fff",tableColor:"#fff",cardColor:"#fff",modalColor:"#fff",bodyColor:"#fff",tagColor:"#eee",avatarColor:"rgba(204, 204, 204, 1)",invertedColor:"rgb(0, 20, 40)",inputColor:"rgba(255, 255, 255, 1)",codeColor:"rgb(244, 244, 248)",tabColor:"rgb(247, 247, 250)",actionColor:"rgb(250, 250, 252)",tableHeaderColor:"rgb(250, 250, 252)",hoverColor:"rgb(243, 243, 245)",tableColorHover:"rgba(0, 0, 100, 0.03)",tableColorStriped:"rgba(0, 0, 100, 0.02)",pressedColor:"rgb(237, 237, 239)",opacityDisabled:"0.5",inputColorDisabled:"rgb(250, 250, 252)",buttonColor2:"rgba(46, 51, 56, .05)",buttonColor2Hover:"rgba(46, 51, 56, .09)",buttonColor2Pressed:"rgba(46, 51, 56, .13)",boxShadow1:"0 1px 2px -2px rgba(0, 0, 0, .08), 0 3px 6px 0 rgba(0, 0, 0, .06), 0 5px 12px 4px rgba(0, 0, 0, .04)",boxShadow2:"0 3px 6px -4px rgba(0, 0, 0, .12), 0 6px 16px 0 rgba(0, 0, 0, .08), 0 9px 28px 8px rgba(0, 0, 0, .05)",boxShadow3:"0 6px 16px -9px rgba(0, 0, 0, .08), 0 9px 28px 0 rgba(0, 0, 0, .05), 0 12px 48px 16px rgba(0, 0, 0, .03)"}},ah=Xe({__name:"App",setup(e){const{handshake:t,emitCode:n}=sh(),o=i=>{t==null||t.then(async s=>{s==null||s.emit("code",i)})};return gs(()=>{t==null||t.then(async i=>{var s,u;console.log("model",(s=i.model)==null?void 0:s.elementStore),(u=i.model)!=null&&u.elementStore||console.log("Starting with fresh widget selector")})}),(i,s)=>(B(),ai(Co(Rp),{theme:Co(lh),class:"h-screen"},{default:cs(()=>[he(qv,{onCodeChange:o})]),_:1},8,["theme"]))}});ju(ah).mount("#app")});export default uh();
